package com.blindarena

import kotlinx.coroutines.delay

// Helpers for scripted sequences (Hand Cricket balls, the tutorials): speak something and wait until the voice has finished,
// so the next sound or sentence does not cut it off.

/** The clock the menus use to ignore a double tap that comes right after a screen change. The automatic tests replace it with a virtual clock. */
object Clock {
    @JvmField
    var source: () -> Long = { System.currentTimeMillis() }

    fun now(): Long = source()
}

/** A rough guess of how long a text takes to speak, used as a safety net when the voice never reports that it is done. */
fun estimateSpeechMs(text: String): Long {
    return (text.length / (13f * MyScreenReader.speechRate) * 1000f).toLong() + 400L
}

/**
 * Speaks the text and waits until the voice is quiet again (never longer than three times the estimate plus three seconds).
 * With skippable = true a swipe or tap by the person ends the wait at once, so a long announcement can be skipped.
 */
suspend fun speakAndWait(text: String, flush: Boolean = true, pauseAfterMs: Long = 250L, skippable: Boolean = false) {
    val seq = MyScreenReader.gestureSeq
    MyScreenReader.speak(text, flush)
    val limit = estimateSpeechMs(text) * 3 + 3000L
    var waited = 0L
    delay(120)
    waited += 120L
    while (MyScreenReader.isSpeaking && waited < limit) {
        if (skippable && MyScreenReader.gestureSeq != seq) return
        delay(50)
        waited += 50L
    }
    if (pauseAfterMs > 0L) delay(pauseAfterMs)
}
