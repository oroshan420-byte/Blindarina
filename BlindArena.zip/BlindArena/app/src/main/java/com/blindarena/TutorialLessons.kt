package com.blindarena

import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// =========================================================================
// TUTORIALS: the lessons themselves. No Compose code in here.
//
// Two kinds of lesson:
//  - GESTURE lessons: the app asks you to do one gesture at a time, listens for it, and says "good" when it hears it.
//    They use the very same touch code and the very same sounds as the real games.
//  - SOUND lessons: a list of sounds. Swipe to a sound, double tap to hear it and to hear what it means.
//
// Every lesson repeats a request twice and then moves on, so nobody gets stuck. The back gesture leaves a lesson.
// =========================================================================

/** Which touch surface the tutorial screen shows. */
enum class TutorialInput { MENU, STICK, LANES, CAR, DUEL }

/** What a practice area does every 30 milliseconds (engine sound, lane tones, walking, shooting...). */
interface PracticeSim {
    fun tick(dt: Float, controls: CarControls, duel: DuelControls)
    fun stop()
}

/** Everything a lesson needs from the screen. The tutorial screen implements it. */
interface TutorialHost {
    val sound: SoundManager
    val controls: CarControls
    val duel: DuelControls

    fun setInput(mode: TutorialInput)
    fun setSim(sim: PracticeSim?)
    fun setItems(items: List<MyScreenReader.FocusItem>)
    fun setHelp(text: String)
    fun clearGestures()
    fun gestureSeen(name: String): Boolean

    /** Speaks and waits until the voice has finished. */
    suspend fun say(text: String, flush: Boolean = false)
    suspend fun pause(ms: Long)

    /** Waits until the condition is true. Returns false when the time is up first. */
    suspend fun waitFor(timeoutMs: Long, condition: () -> Boolean): Boolean
}

const val ASK_SECONDS = 15
const val ASK_TRIES = 3

/** Asks the person to do something and waits for it. Asks again twice, then moves on without it. */
suspend fun TutorialHost.ask(
    prompt: String,
    ok: String,
    before: () -> Unit = {},
    condition: () -> Boolean
): Boolean {
    before()
    var attempt = 0
    while (attempt < ASK_TRIES) {
        val text = when (attempt) {
            0 -> prompt
            1 -> "Let us try that again. $prompt"
            else -> "One more time. $prompt"
        }
        say(text)
        if (waitFor(ASK_SECONDS * 1000L, condition)) {
            sound.playSpatial("lock_tone", pan = 0f, volume = 0.8f, rate = 1.3f)
            say(ok)
            return true
        }
        attempt += 1
    }
    say("No problem. We will go on.")
    return false
}

// ---------------------------------------------------------------------------------------------
// Practice areas
// ---------------------------------------------------------------------------------------------

private fun loopSwitch(sound: SoundManager, stream: Int, tag: String, on: Boolean, pan: Float, volume: Float): Int {
    if (on) {
        if (stream == 0) return sound.playLoop(tag, pan, volume, 1.0f)
        sound.updateStream(stream, pan, volume, 1.0f)
        return stream
    }
    if (stream != 0) sound.stopStream(stream)
    return 0
}

/** One finger driving: the engine follows your finger, a beeper plays when you slide a long way down, a tick when you steer. */
class StickPractice(private val sound: SoundManager) : PracticeSim {
    private val engine = EngineSound(sound)
    private var level = 0f
    private var reverseStream = 0
    private var indicatorStream = 0

    /** The highest your finger has been above where it first touched, during this touch (0 to 1). */
    var maxY = 0f
        private set

    override fun tick(dt: Float, controls: CarControls, duel: DuelControls) {
        val wanted = if (controls.stickActive) (max(0f, controls.stickY) + 0.45f * controls.stickBoost).coerceIn(0f, 1f) else 0f
        level += (wanted - level) * min(1f, dt * 3f)
        engine.update(level)
        if (controls.stickActive) maxY = max(maxY, controls.stickY) else maxY = 0f
        val reversing = controls.stickActive && controls.stickY < -0.55f
        reverseStream = loopSwitch(sound, reverseStream, "reverse_beep_loop", reversing, 0f, 0.5f)
        val steering = controls.stickActive && abs(controls.stickX) > 0.28f
        indicatorStream = loopSwitch(sound, indicatorStream, "indicator_loop", steering, if (controls.stickX < 0f) -0.4f else 0.4f, 0.45f)
    }

    override fun stop() {
        engine.stop()
        sound.stopStream(reverseStream)
        sound.stopStream(indicatorStream)
        reverseStream = 0
        indicatorStream = 0
    }
}

/** Arcade Rush: touching the left or right half moves one lane, with the lane tone. */
class LanePractice(val steering: LaneSteering) : PracticeSim {
    override fun tick(dt: Float, controls: CarControls, duel: DuelControls) {
        steering.update(dt, controls)
    }

    override fun stop() {
    }
}

/** Highway and Jungle: tap the top edge for a higher gear, the bottom edge for a lower one, hold left or right for a lane change. */
class CarPractice(val drive: Drivetrain, val steering: LaneSteering) : PracticeSim {
    override fun tick(dt: Float, controls: CarControls, duel: DuelControls) {
        handleGears(controls, drive)
        drive.update(dt)
        steering.update(dt, controls)
    }

    override fun stop() {
        drive.stopEngine()
    }
}

/** Gun Fight: walk, turn, fire, reload and ask for the status, in an empty warehouse. */
class DuelPractice(private val sound: SoundManager) : PracticeSim {
    var steps = 0
        private set
    var backSteps = 0
        private set
    var turnedRight = 0f
        private set
    var turnedLeft = 0f
        private set
    var shots = 0
        private set
    var reloads = 0
        private set
    var statuses = 0
        private set
    var ammo = 12
        private set
    var heading = 0f
        private set

    private var holdTime = 0f
    private var stepCooldown = 0f
    private var lastStep = 0
    private var reloadLeft = 0f
    private var cooldownLeft = 0f

    override fun tick(dt: Float, controls: CarControls, duel: DuelControls) {
        stepCooldown = max(0f, stepCooldown - dt)
        cooldownLeft = max(0f, cooldownLeft - dt)
        if (reloadLeft > 0f) {
            reloadLeft -= dt
            if (reloadLeft <= 0f) ammo = 12
        }

        val queued = duel.moveQueued
        duel.moveQueued = MOVE_NONE
        if (queued != MOVE_NONE) {
            holdTime = 0f
            move(queued)
            stepCooldown = GunDuel.STEP_INTERVAL
        } else if (duel.moveHeld != MOVE_NONE) {
            holdTime += dt
            val held = duel.moveHeld
            if (held == MOVE_LEFT || held == MOVE_RIGHT) {
                if (holdTime > GunDuel.TURN_HOLD_DELAY) {
                    val rate = if (holdTime < 1.4f) 60f else 110f
                    turnBy((if (held == MOVE_LEFT) -1f else 1f) * rate * dt)
                }
            } else if (holdTime > GunDuel.STEP_HOLD_DELAY && stepCooldown <= 0f) {
                move(held)
                stepCooldown = GunDuel.STEP_INTERVAL
            }
        } else {
            holdTime = 0f
        }

        if (duel.statusQueued) {
            duel.statusQueued = false
            statuses += 1
            val reloadText = if (reloadLeft > 0f) ", reloading" else ""
            MyScreenReader.speak("Health 100. Ammo $ammo of 12$reloadText. Facing ${compassName(heading)}.")
        }
        if (duel.reloadQueued) {
            duel.reloadQueued = false
            if (reloadLeft <= 0f && ammo < 12) {
                reloads += 1
                reloadLeft = 1.2f
                sound.playSpatial("reload_pistol", pan = 0f, volume = 0.9f)
            }
        }
        if (duel.fireQueued) {
            duel.fireQueued = false
            fire()
        }
    }

    private fun move(m: Int) {
        when (m) {
            MOVE_FORWARD -> {
                steps += 1
                step(1.0f)
            }
            MOVE_BACK -> {
                backSteps += 1
                step(0.9f)
            }
            MOVE_LEFT -> turnBy(-GunDuel.SINGLE_TURN_DEG)
            MOVE_RIGHT -> turnBy(GunDuel.SINGLE_TURN_DEG)
        }
    }

    private fun step(rate: Float) {
        var index = Random.nextInt(3) + 1
        if (index == lastStep) index = index % 3 + 1
        lastStep = index
        sound.playSpatial("step_$index", pan = 0f, volume = 0.5f, rate = rate)
    }

    private fun turnBy(delta: Float) {
        val old = heading
        var h = (heading + delta) % 360f
        if (h < 0f) h += 360f
        heading = h
        if (delta > 0f) turnedRight += delta else turnedLeft += -delta
        val oldSector = Math.floor((old / 90f).toDouble()).toInt()
        val newSector = Math.floor((h / 90f).toDouble()).toInt()
        val oldCell = Math.floor((old / 15f).toDouble()).toInt()
        val newCell = Math.floor((h / 15f).toDouble()).toInt()
        if (oldSector != newSector) {
            sound.playSpatial("ui_detent", pan = 0f, volume = 0.9f)
        } else if (oldCell != newCell) {
            sound.playSpatial("ui_tick", pan = 0f, volume = 0.6f)
        }
    }

    private fun fire() {
        if (reloadLeft > 0f || cooldownLeft > 0f) return
        if (ammo <= 0) {
            sound.playSpatial("gun_empty", pan = 0f, volume = 0.9f)
            return
        }
        ammo -= 1
        shots += 1
        cooldownLeft = 0.35f
        sound.playSpatial("gun_pistol", pan = 0f, volume = 1.0f)
        sound.vibrate(40)
    }

    override fun stop() {
    }
}

// ---------------------------------------------------------------------------------------------
// Gesture lessons
// ---------------------------------------------------------------------------------------------

/** The gestures of every menu: swipe, double tap, two finger double tap, hold, back. */
suspend fun menuGesturesLesson(h: TutorialHost) {
    h.setInput(TutorialInput.MENU)
    h.setHelp("This is the menu gestures lesson. Do what the voice asks. The back gesture leaves the lesson.")
    val items = ArrayList<MyScreenReader.FocusItem>()
    items.add(MyScreenReader.FocusItem("practice_1", "Practice option one", "button", "") { })
    items.add(MyScreenReader.FocusItem("practice_2", "Practice option two", "button", "") { })
    items.add(MyScreenReader.FocusItem("practice_3", "Practice option three", "button", "") { })
    h.setItems(items)
    h.say(
        "Menu gestures. These five gestures work in every menu of the app. You use your fingers anywhere on the screen. " +
            "There are three practice options on this screen. I will ask for one gesture at a time.",
        flush = true
    )
    h.ask(
        "Swipe right with one finger, anywhere on the screen. A swipe right, or a swipe down, moves to the next option.",
        "That is it. The voice reads the option you moved to.",
        before = { h.clearGestures() }
    ) { h.gestureSeen("next") }
    h.ask(
        "Now swipe left. A swipe left, or a swipe up, goes back to the previous option.",
        "Good. Left and up go back, right and down go forward.",
        before = { h.clearGestures() }
    ) { h.gestureSeen("previous") }
    h.ask(
        "Now double tap with one finger. Tap twice, fast, anywhere. A double tap selects the option you are on.",
        "Selected. In a real menu this would start the option.",
        before = { h.clearGestures() }
    ) { h.gestureSeen("activate") }
    h.ask(
        "Now double tap with two fingers at the same time. This repeats the last thing the voice said.",
        "Good. Use it whenever you missed something.",
        before = { h.clearGestures() }
    ) { h.gestureSeen("repeat") }
    h.ask(
        "Now touch the screen with one finger and keep it still for one second. This gives help.",
        "Good. Hold one finger for one second, in any menu, to hear what to do.",
        before = { h.clearGestures() }
    ) { h.gestureSeen("help") }
    h.say(
        "The last gesture is the back gesture of your phone. It goes back one step. " +
            "During a drive or a match, do it twice to leave, so a slip does not end your game. That was the menu gestures lesson."
    )
}

/** One finger driving, as in the long drive to Kalimpong. */
suspend fun stickLesson(h: TutorialHost) {
    val c = h.controls
    val sim = StickPractice(h.sound)
    h.setInput(TutorialInput.STICK)
    h.setSim(sim)
    h.setHelp("Touch the screen and slide your finger up to speed up, down to slow down, left or right to steer. Lift to stop. A quick tap asks the GPS.")
    h.say(
        "One finger driving, as in the long drive to Kalimpong. You need only one finger. Where it first touches the screen is the centre. " +
            "Use headphones for the best sound. There is no road here, only the car, so you can learn the finger movements safely.",
        flush = true
    )
    h.ask(
        "Touch the screen and slide your finger up. Keep your finger down. You will hear the engine. A little up is slow, a lot up is fast.",
        "That is the engine speeding up. The higher your finger goes, the faster the car.",
        before = { c.stickActive = false }
    ) { c.stickActive && c.stickY > 0.5f }
    h.ask(
        "Keep your finger on the screen and slide it down a little. The engine gets slower.",
        "Good. Sliding down slows the car.",
        before = { }
    ) { c.stickActive && sim.maxY > 0.4f && c.stickY < sim.maxY - 0.3f }
    h.ask(
        "Now lift your finger off the screen. The car stops when you lift your finger.",
        "The engine falls quiet. Lifting always stops the car.",
        before = { }
    ) { !c.stickActive }
    h.ask(
        "Touch again and slide your finger a long way down. That is reverse. You will hear a beeping.",
        "That is the reverse beeper. Slide down a long way to go backwards.",
        before = { }
    ) { c.stickActive && c.stickY < -0.6f }
    h.ask(
        "Now steer. Touch the screen and slide your finger to the left. You will hear ticking on your left, like an indicator.",
        "Good. That is steering left.",
        before = { }
    ) { c.stickActive && c.stickX < -0.5f }
    h.ask(
        "Now slide your finger to the right.",
        "Good. That is steering right.",
        before = { }
    ) { c.stickActive && c.stickX > 0.5f }
    h.say(
        "On the real drive the car keeps its lane by itself and follows the bends by itself. " +
            "You only slide left or right at a sharp turn, when the GPS says turn now, or to go around something. Small slides are ignored."
    )
    h.ask(
        "Last gesture. Tap the screen once, quickly. This asks the GPS where to go.",
        "On the drive the GPS now says something like: next, turn left in 800 meters. 12 kilometres to go.",
        before = { c.gpsQueued = false }
    ) { c.gpsQueued }
    c.gpsQueued = false
    h.say(
        "Also remember: a rumble on one side means you are near the edge of the road. Beeps on one side mean the road bends that way, steer towards the beeps. " +
            "The sounds lesson explains every sound. That was the one finger driving lesson."
    )
}

/** Plays a pretend vehicle that arrives in about three and a half seconds. Returns true when you got out of its lane. */
private suspend fun pretendVehicle(h: TutorialHost, steering: LaneSteering, lane: Int, tag: String, hornTag: String): Boolean {
    val pan = (lane - 1) * 0.5f
    val stream = h.sound.playLoop(tag, pan, 0.15f, 0.9f)
    var t = 0
    var horned = false
    var warnLeft = 0
    try {
        while (t < 3500) {
            val c = t / 3500f
            h.sound.updateStream(stream, pan, 0.15f + 0.85f * c * c, 0.85f + 0.55f * c)
            if (steering.lane == lane) {
                if (!horned && t > 1200) {
                    horned = true
                    h.sound.playSpatial(hornTag, pan = 0f, volume = 1.0f)
                }
                warnLeft -= 40
                if (t > 1600 && warnLeft <= 0) {
                    h.sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.45f * c, rate = 1.0f + 0.7f * c)
                    warnLeft = 100 + (350f * (1f - c)).toInt()
                }
            }
            h.pause(40)
            t += 40
        }
    } finally {
        h.sound.stopStream(stream)
    }
    val dodged = steering.lane != lane
    if (dodged) {
        h.sound.playSpatial("car_pass", pan = pan, volume = 0.9f)
    } else {
        h.sound.playSpatial("crash", pan = 0f, volume = 1.0f)
        h.sound.vibrate(200)
    }
    return dodged
}

/** A pretend bonus bell in one lane. Returns true when you steered into it. */
private suspend fun pretendBell(h: TutorialHost, steering: LaneSteering, lane: Int): Boolean {
    val pan = (lane - 1) * 0.5f
    var t = 0
    var next = 0
    while (t < 3500) {
        val c = t / 3500f
        if (t >= next) {
            h.sound.playSpatial("bicycle_bell", pan = pan, volume = 0.4f + 0.55f * c, rate = 1.0f + 0.25f * c)
            next = t + 500 + (700f * (1f - c)).toInt()
        }
        h.pause(40)
        t += 40
    }
    val got = steering.lane == lane
    if (got) {
        h.sound.playSpatial("ui_select", pan = 0f, volume = 1.0f)
        h.sound.playSpatial("lock_tone", pan = 0f, volume = 0.8f, rate = 1.6f)
    }
    return got
}

/** Arcade Rush: touch the left or the right half of the screen to change lane. */
suspend fun rushLesson(h: TutorialHost) {
    val c = h.controls
    val steering = LaneSteering(h.sound)
    h.setInput(TutorialInput.LANES)
    h.setSim(LanePractice(steering))
    h.setHelp("Touch the left half of the screen to move one lane left. Touch the right half to move one lane right.")
    steering.forceLane(1)
    h.say(
        "Arcade Rush. In the game the car drives by itself and you only change lane. The whole screen is two buttons. " +
            "Touch the left half to move one lane left. Touch the right half to move one lane right. There are three lanes. " +
            "Use headphones. You are now in the middle lane.",
        flush = true
    )
    h.ask(
        "Touch the left half of the screen once. You move to the left lane, and you hear a low beep in your left ear.",
        "That low beep on the left means the left lane.",
        before = { c.leftPressQueued = false }
    ) { steering.lane == 0 }
    h.ask(
        "Now touch the right half of the screen two times, one touch after the other. You move to the right lane, and you hear a high beep in your right ear.",
        "That high beep on the right means the right lane. The middle lane has a middle beep.",
        before = { c.rightPressQueued = false }
    ) { steering.lane == 2 }
    h.ask(
        "Touch the left half once, to come back to the middle lane.",
        "Good. You are in the middle lane again.",
        before = { }
    ) { steering.lane == 1 }
    h.say(
        "Now a pretend car comes towards you in your lane. In the game, a car you hear on your left is in the left lane, " +
            "a car in the middle of your head is in the middle lane. Louder and higher means closer. " +
            "Fast beeps and a horn mean the car is in YOUR lane. Listen, and move away from it."
    )
    var tries = 0
    while (tries < 2) {
        val dodged = pretendVehicle(h, steering, steering.lane, "car_hum", "horn")
        if (dodged) {
            h.say("You got out of its way. Well done. The whoosh was the car passing you.")
            break
        }
        h.say("That would have been a crash. You would lose one of your three lives. Let us try once more. Move away from the car as soon as you hear it.")
        tries += 1
    }
    h.say("Now a bonus bell. A ringing bell is a bonus. Steer INTO it for points and one life back. Listen where it rings.")
    val bellLane = if (steering.lane == 2) 0 else 2
    if (pretendBell(h, steering, bellLane)) {
        h.say("You caught the bell. That is a bonus.")
    } else {
        val side = if (bellLane == 0) "left" else "right"
        h.say("You missed the bell. It was in the $side lane. In the game, steer into the bell.")
    }
    h.say(
        "Later levels add noises from the roadside, like dogs and cows, and rain. They are not cars. " +
            "The sounds lesson plays them all. That was the Arcade Rush lesson."
    )
}

/** Highway and Jungle: gears with the top and bottom edge, lanes by holding the left or right half. */
suspend fun carLesson(h: TutorialHost) {
    val c = h.controls
    val drive = Drivetrain(h.sound)
    val steering = LaneSteering(h.sound)
    h.setInput(TutorialInput.CAR)
    h.setSim(CarPractice(drive, steering))
    h.setHelp("Tap the very top of the screen for a higher gear, the very bottom for a lower gear. Hold the left or right half to change lane.")
    drive.reset()
    steering.forceLane(1)
    h.say(
        "Highway and jungle road. The car has four gears and three lanes. The car stands still until you shift up. " +
            "You use the top edge of the screen, the bottom edge, and the left and right halves of the middle.",
        flush = true
    )
    h.ask(
        "Tap the very top edge of the screen, in the top fifth. Each tap shifts up one gear and the car goes faster. You hear a gear change.",
        "That is first gear. The engine sound rises with the speed.",
        before = { c.gearUpQueued = false }
    ) { drive.gear >= 1 }
    h.ask(
        "Tap the top edge two more times to reach third gear.",
        "Third gear. You can go up to fourth.",
        before = { }
    ) { drive.gear >= 3 }
    h.ask(
        "Now tap the very bottom edge, in the bottom fifth, once. That shifts down one gear.",
        "Good. Down one gear.",
        before = { c.gearDownQueued = false }
    ) { drive.gear in 1..2 }
    h.ask(
        "Now tap the bottom edge twice, quickly. Two quick taps are an emergency brake. You hear the tyres squeal.",
        "That is the emergency brake. The car is standing still.",
        before = { }
    ) { drive.gear == 0 }
    h.ask(
        "Now change lane. Touch the left half of the middle of the screen, and keep your finger down. You move one lane left, with a low beep on the left. Holding moves you again.",
        "Good. That is the left lane.",
        before = { c.leftPressQueued = false }
    ) { steering.lane == 0 }
    h.ask(
        "Now touch the right half of the middle of the screen. Hold it until you reach the right lane. You hear a high beep on the right.",
        "Good. That is the right lane.",
        before = { c.rightPressQueued = false }
    ) { steering.lane == 2 }
    h.say(
        "On the highway, a car you hear on the left is in the left lane. Fast beeps and a horn mean it is in YOUR lane: change lane or slow down. " +
            "On the jungle road, listen to the animals, the fallen trees and the potholes: the sounds lesson explains them. " +
            "That was the highway and jungle lesson."
    )
}

/** Gun Fight: walk, turn, fire, reload, status. */
suspend fun gunLesson(h: TutorialHost) {
    val sim = DuelPractice(h.sound)
    h.setInput(TutorialInput.DUEL)
    h.setSim(sim)
    h.setHelp("Swipe left or right to turn, swipe up to walk, swipe down to step back. Tap the middle to fire, the bottom edge to reload, the top edge for status.")
    h.say(
        "Gun Fight. In the game you and a bot walk around a warehouse. You turn and walk with swipes, and you shoot with taps. " +
            "There is no enemy in this lesson, only you. Use headphones.",
        flush = true
    )
    h.ask(
        "Swipe up with one finger, and keep your finger down after the swipe. You walk forward. You hear your footsteps. Lift your finger to stop.",
        "Good. A swipe up is one step. Keeping your finger down keeps you walking.",
        before = { h.duel.clear() }
    ) { sim.steps >= 3 }
    h.ask(
        "Swipe down, and keep your finger down. You step backwards, a little slower.",
        "Good. Backwards steps are a little shorter.",
        before = { }
    ) { sim.backSteps >= 2 }
    h.ask(
        "Swipe right and keep your finger down. You turn to the right. You hear a soft tick every 15 degrees, and a clear click when you face north, east, south or west.",
        "Good. That is turning right.",
        before = { }
    ) { sim.turnedRight >= 30f }
    h.ask(
        "Now swipe left and keep your finger down, to turn to the left.",
        "Good. That is turning left. The clicks help you know which way you face.",
        before = { }
    ) { sim.turnedLeft >= 30f }
    h.ask(
        "Tap the middle of the screen once to fire your pistol.",
        "Bang. In the game, a shot only hits when the enemy is in front of you.",
        before = { h.duel.fireQueued = false }
    ) { sim.shots >= 1 }
    h.ask(
        "Tap near the bottom edge of the screen to reload. You hear the magazine go in.",
        "Reloaded. Reload before you run out of bullets. When the gun is empty you hear a click.",
        before = { h.duel.reloadQueued = false }
    ) { sim.reloads >= 1 }
    h.pause(1500)
    h.ask(
        "Tap near the top edge of the screen. The voice tells you your health, your bullets and the direction you face.",
        "Good. That is the status.",
        before = { h.duel.statusQueued = false }
    ) { sim.statuses >= 1 }
    h.say(
        "In the game, listen for the enemy's footsteps: they tell you where he is and whether he walks or runs. " +
            "When he is in front of you, a tone beeps, faster the better you are aimed. The sounds lesson plays all of them. " +
            "That was the Gun Fight lesson."
    )
}

/** Hand Cricket: one practice ball when you bat, one when you bowl, and the end of an innings. */
suspend fun cricketLesson(h: TutorialHost) {
    h.setInput(TutorialInput.MENU)
    h.setHelp("Swipe to choose a number from 1 to 6, then double tap to play it.")
    var picked = 0
    val items = ArrayList<MyScreenReader.FocusItem>()
    for (n in 1..6) {
        items.add(MyScreenReader.FocusItem("num_$n", "$n", "number", "") { picked = n })
    }
    h.setItems(items)
    h.say(
        "Hand Cricket. You and the computer both secretly pick a number from 1 to 6 on every ball. " +
            "If the numbers are the same, the batter is out. If not, the batter scores his own number. " +
            "Now you will play two practice balls.",
        flush = true
    )

    // practice ball 1: you bat
    h.say("First you bat. Before every ball you hear the computer bowl. Listen. First its footsteps as it runs in, then the ball flying at you, then a short tone.")
    CricketAudio.play(h.sound, CricketAudio.botDeliveryCues())
    picked = 0
    h.say("That tone means it is your turn. Swipe to choose a number from 1 to 6, then double tap to play it.")
    if (h.waitFor(60000L) { picked != 0 }) {
        val c = Random.nextInt(1, 7)
        val out = picked == c
        val scored = if (out) 0 else picked
        h.pause(250)
        CricketAudio.playOutcome(h.sound, out, scored, true)
        val result = if (out) "Out! You are dismissed." else "You score $scored ${if (scored == 1) "run" else "runs"}."
        h.say("You $picked. Computer $c. $result")
        h.say(
            if (out) "The stumps were hit and the crowd groans. That is what out sounds like when you bat."
            else if (scored >= 6) "A hard hit and a roaring crowd. That is a six."
            else if (scored >= 4) "A hard hit and a cheer. Four or five runs."
            else "A soft hit. One, two or three runs."
        )
    } else {
        h.say("No problem. We will go on.")
    }

    // practice ball 2: you bowl
    h.say("Now you bowl. Before every ball you hear the batsman get ready: two taps of the bat on the ground, then a short tone.")
    CricketAudio.play(h.sound, CricketAudio.batsmanReadyCues())
    picked = 0
    h.say("Pick your bowling number, from 1 to 6. If it matches the batsman's number, he is out.")
    if (h.waitFor(60000L) { picked != 0 }) {
        CricketAudio.play(h.sound, CricketAudio.playerDeliveryCues())
        h.pause(250)
        val c = Random.nextInt(1, 7)
        val out = picked == c
        val scored = if (out) 0 else c
        CricketAudio.playOutcome(h.sound, out, scored, false)
        val result = if (out) "Out! You got the computer out." else "Computer scores $scored ${if (scored == 1) "run" else "runs"}."
        h.say("You $picked. Computer $c. $result")
        h.say(
            if (out) "The stumps were hit and the crowd cheers. That is what out sounds like when you bowl."
            else "You heard your own run-up, then the ball flying away, then the hit."
        )
    } else {
        h.say("No problem. We will go on.")
    }

    // the end of an innings
    h.say("When the innings is over, you hear the umpire's whistle. Listen.")
    CricketAudio.playInningsOver(h.sound)
    h.pause(1600)
    h.say(
        "Then the voice tells you how many runs were scored, and who bats next. " +
            "It says last over, last ball and last wicket, so you know the end is near. " +
            "After the second innings you hear the whistle again, then the cheer or the groan, then the result. " +
            "At the start of Hand Cricket you choose Premier League or Quick match. Quick match is one match with the overs you choose. Premier League is a season with five league matches against five teams, then the playoffs. " +
            "Each team has a star with his own style, and your season is saved after every match. " +
            "That was the Hand Cricket lesson. The sounds lesson plays every sound again."
    )
}

// ---------------------------------------------------------------------------------------------
// Sound lessons: a list of cards. Swipe to a card, double tap to hear it.
// ---------------------------------------------------------------------------------------------

class SoundCard(val label: String, val explanation: String, val demo: suspend (SoundManager) -> Unit)

private suspend fun loopFor(s: SoundManager, tag: String, ms: Long, pan: Float, volume: Float, rate: Float) {
    val id = s.playLoop(tag, pan, volume, rate)
    try {
        delay(ms)
    } finally {
        s.stopStream(id)
    }
}

/** A looping sound that gets louder and higher (like something coming closer). */
private suspend fun comingCloser(s: SoundManager, tag: String, ms: Long, pan: Float, rate0: Float, rate1: Float) {
    val id = s.playLoop(tag, pan, 0.15f, rate0)
    try {
        var t = 0L
        while (t < ms) {
            val c = t.toFloat() / ms
            s.updateStream(id, pan, 0.15f + 0.85f * c * c, rate0 + (rate1 - rate0) * c)
            delay(60)
            t += 60
        }
    } finally {
        s.stopStream(id)
    }
}

/** A row of short sounds that come faster and higher, like a parking sensor. */
private suspend fun sensorBeeps(s: SoundManager, tag: String, count: Int, pan: Float, gap0: Long, gap1: Long, rate0: Float, rate1: Float) {
    for (i in 0 until count) {
        val c = if (count <= 1) 1f else i / (count - 1f)
        s.playSpatial(tag, pan = pan, volume = 0.45f + 0.45f * c, rate = rate0 + (rate1 - rate0) * c)
        delay((gap0 + (gap1 - gap0) * c).toLong())
    }
}

private suspend fun repeated(s: SoundManager, tag: String, count: Int, pan: Float, gap: Long, volume: Float, rate: Float) {
    for (i in 0 until count) {
        s.playSpatial(tag, pan = pan, volume = volume, rate = rate)
        delay(gap)
    }
}

private suspend fun playFor(s: SoundManager, tag: String, ms: Long, pan: Float, volume: Float) {
    val id = s.playSpatial(tag, pan = pan, volume = volume)
    try {
        delay(ms)
    } finally {
        s.stopStream(id)
    }
}

/** The two sounds of the saved records and the daily challenge, at the end of every sound list. */
fun recordSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "New record",
        "A new record. When you beat your best result, the crowd applauds and the voice says new record. Your best results stay saved in the phone."
    ) { s ->
        Records.playNewRecord(s)
        delay(3500)
    })
    cards.add(SoundCard(
        "Daily challenge done",
        "Daily challenge complete. A cheer and a bell. Every day there is one small goal, and this is the sound when you reach it. Do it many days in a row to build your streak."
    ) { s ->
        Daily.playSound(s)
        delay(3000)
    })
    return cards
}

fun kalimpongSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "Engine",
        "The engine. It is low when the car is slow and gets higher and louder the faster you go. Listen to it to know your speed."
    ) { s ->
        val e = EngineSound(s)
        try {
            for (i in 0..40) {
                e.update(i / 40f)
                delay(60)
            }
        } finally {
            e.stop()
        }
    })
    cards.add(SoundCard(
        "Road bend beeps",
        "Short beeps on one side mean the road bends that way. Steer towards the beeps. When you are lined up with the road, they stop."
    ) { s ->
        repeated(s, "beep", 4, -0.8f, 450, 0.45f, 1.3f)
        delay(500)
        repeated(s, "beep", 4, 0.8f, 450, 0.45f, 1.3f)
    })
    cards.add(SoundCard(
        "Road edge rumble",
        "A rumble on one side means you are near the edge of the road on that side. Steer away from it. If you leave the road, the car slows down and finds its way back."
    ) { s -> loopFor(s, "dirt_loop", 2600, -0.9f, 0.5f, 1.0f) })
    cards.add(SoundCard(
        "Obstacle beeps",
        "Soft beeps ahead mean something is in your way. They get faster and higher as it gets closer, and they sit on the side where it is. Slow down or steer around it."
    ) { s -> sensorBeeps(s, "warn_beep", 14, 0.4f, 500, 100, 1.0f, 1.7f) })
    cards.add(SoundCard(
        "Cow",
        "A cow on the road. It does not move. You hear it on its side. Slow down and go around."
    ) { s ->
        s.playSpatial("cow_moo", pan = -0.6f, volume = 1.0f)
        delay(2300)
    })
    cards.add(SoundCard(
        "Dog",
        "A dog on the road. Slow down and go around it."
    ) { s ->
        repeated(s, "dog_bark", 2, 0.6f, 1300, 1.0f, 1.0f)
    })
    cards.add(SoundCard(
        "Crowd of people",
        "A crowd of people on the road. Slow down or stop and go around them."
    ) { s -> loopFor(s, "crowd_town_loop", 2800, 0f, 0.8f, 1.0f) })
    cards.add(SoundCard(
        "Speed bump",
        "Low beeps straight ahead, then a thump, mean a speed bump. Slow down before it. If you cross it fast, the car bounces and loses speed."
    ) { s ->
        sensorBeeps(s, "warn_beep", 6, 0f, 450, 150, 0.6f, 1.0f)
        delay(300)
        s.playSpatial("bump_thud", pan = 0f, volume = 1.0f)
        delay(1000)
    })
    cards.add(SoundCard(
        "Auto rickshaw",
        "An auto rickshaw. A buzzing engine and a thin horn. It is slow. Do not hit it."
    ) { s ->
        val id = s.playLoop("rickshaw_loop", -0.5f, 0.8f, 1.0f)
        try {
            delay(1200)
            s.playSpatial("horn_auto", pan = -0.3f, volume = 1.0f)
            delay(1700)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Bus",
        "A bus. A deep engine and a long deep horn. A horn means it is in your way."
    ) { s ->
        val id = s.playLoop("eng_idle", 0.5f, 0.8f, 0.7f)
        try {
            delay(1200)
            s.playSpatial("horn_bus", pan = 0.3f, volume = 1.0f)
            delay(2300)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Truck",
        "A truck. An even deeper engine and the loudest horn. Give it plenty of room."
    ) { s ->
        val id = s.playLoop("eng_idle", 0.5f, 0.8f, 0.6f)
        try {
            delay(1200)
            s.playSpatial("horn_truck", pan = 0.3f, volume = 1.0f)
            delay(2700)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Motorcycle",
        "A motorcycle. A high, fast engine and a short horn. It passes quickly with a whoosh."
    ) { s ->
        val id = s.playLoop("eng_high", -0.5f, 0.6f, 1.25f)
        try {
            delay(1100)
            s.playSpatial("horn", pan = -0.3f, volume = 0.9f, rate = 1.5f)
            delay(1200)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Cyclist",
        "A cyclist ringing a bell. Slow down and pass wide."
    ) { s -> repeated(s, "bicycle_bell", 2, 0.5f, 1700, 1.0f, 1.0f) })
    cards.add(SoundCard(
        "Vehicle passing you",
        "A whoosh on one side means a vehicle has just passed you on that side."
    ) { s ->
        s.playSpatial("car_pass", pan = -0.5f, volume = 1.0f)
        delay(2300)
    })
    cards.add(SoundCard(
        "Traffic signal",
        "Fast beeping, like a pedestrian crossing, means a RED light for cars. Stop before the light. When the beeping stops, you hear a soft chime: it is green and you may go. Driving through a red light costs a life."
    ) { s ->
        repeated(s, "ped_beep", 7, 0.4f, 550, 0.9f, 1.0f)
        delay(300)
        s.playSpatial("ui_select", pan = 0.4f, volume = 0.5f)
        delay(700)
    })
    cards.add(SoundCard(
        "Whistle",
        "A police whistle: you ran a red light. You lose a life."
    ) { s ->
        s.playSpatial("police_whistle", pan = 0f, volume = 1.0f)
        delay(1600)
    })
    cards.add(SoundCard(
        "Crash",
        "A crash: you hit something. You lose one life. You start with three lives. Every ten kilometres there is a checkpoint, and it gives one life back. A soft bump at low speed costs nothing."
    ) { s ->
        s.playSpatial("collision_hit", pan = 0f, volume = 1.0f)
        delay(400)
        s.playSpatial("glass_break", pan = 0f, volume = 0.6f)
        delay(2200)
    })
    cards.add(SoundCard(
        "Reverse beeper",
        "A steady beeping means the car is going backwards."
    ) { s -> loopFor(s, "reverse_beep_loop", 2000, 0f, 0.5f, 1.0f) })
    cards.add(SoundCard(
        "Indicator",
        "A ticking on one side means you are steering to that side."
    ) { s -> loopFor(s, "indicator_loop", 2000, -0.4f, 0.45f, 1.0f) })
    cards.add(SoundCard(
        "River and bridge",
        "A river that gets louder as you come near. On a bridge the planks creak. There are two bridges on the way. Stay on the road."
    ) { s ->
        val id = s.playLoop("river_loop", 0f, 0.5f, 1.0f)
        try {
            delay(900)
            s.playSpatial("bridge_creak", pan = 0f, volume = 0.5f)
            delay(2300)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Rain and thunder",
        "Rain and thunder in the hills. They are only the weather. They do not hurt you."
    ) { s ->
        val id = s.playLoop("rain_loop", 0f, 0.45f, 1.0f)
        try {
            delay(1000)
            s.playSpatial("thunder_roll", pan = 0.4f, volume = 0.7f)
            delay(3500)
        } finally {
            s.stopStream(id)
        }
    })
    cards.add(SoundCard(
        "Village market",
        "A village market beside the road. Expect cows, dogs and people near it."
    ) { s -> loopFor(s, "market_loop", 2800, 0.7f, 0.8f, 1.0f) })
    cards.add(SoundCard(
        "School children",
        "The children of the hostel. You hear them from far away, louder and louder as you arrive. You are almost there."
    ) { s -> comingCloser(s, "school_loop", 3200, 0f, 1.0f, 1.0f) })
    cards.add(SoundCard(
        "Temple bell",
        "A bell from Kalimpong, now and then. Faint when you are far away. It comes from the direction of the destination."
    ) { s ->
        playFor(s, "temple_bell", 3500, 0.3f, 0.6f)
    })
    cards.add(SoundCard(
        "Arrival",
        "The door opens and the crowd cheers. You have arrived at the hostel."
    ) { s ->
        s.playSpatial("door_open", pan = 0f, volume = 0.9f)
        delay(700)
        s.playSpatial("cheer", pan = 0f, volume = 0.9f)
        s.playSpatial("victory", pan = 0f, volume = 0.8f)
        delay(3800)
    })
    cards.addAll(recordSoundCards())
    return cards
}

fun rushSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "Car coming",
        "A car coming. It sits in the left, middle or right of your head, like its lane. Louder and higher means closer. Move away from it."
    ) { s -> comingCloser(s, "car_hum", 3500, -0.5f, 0.85f, 1.4f) })
    cards.add(SoundCard(
        "Truck",
        "A truck is a slower, deeper hum."
    ) { s -> comingCloser(s, "car_hum", 3500, 0.5f, 0.6f, 0.95f) })
    cards.add(SoundCard(
        "Auto rickshaw",
        "An auto rickshaw buzzes."
    ) { s -> comingCloser(s, "rickshaw_loop", 3500, 0f, 0.9f, 1.3f) })
    cards.add(SoundCard(
        "Fast bike",
        "A fast bike is a high, quick hum. It reaches you sooner."
    ) { s -> comingCloser(s, "car_hum", 3000, -0.5f, 1.3f, 1.9f) })
    cards.add(SoundCard(
        "Car in your lane",
        "Fast beeps in the middle of your head, and a horn, mean a vehicle is coming in YOUR lane. Change lane now."
    ) { s ->
        s.playSpatial("horn", pan = 0f, volume = 1.0f)
        sensorBeeps(s, "warn_beep", 12, 0f, 380, 100, 1.0f, 1.7f)
    })
    cards.add(SoundCard(
        "Car passes",
        "A whoosh means a car has passed you. You get points for every car you pass."
    ) { s ->
        s.playSpatial("car_pass", pan = 0.5f, volume = 1.0f)
        delay(2300)
    })
    cards.add(SoundCard(
        "Bonus bell",
        "A ringing bell is a bonus. Steer INTO it. It gives you 300 points and one life back. The bell rings faster as it gets closer."
    ) { s ->
        sensorBeeps(s, "bicycle_bell", 4, 0.5f, 900, 500, 1.0f, 1.25f)
        delay(300)
        s.playSpatial("ui_select", pan = 0f, volume = 1.0f)
        s.playSpatial("lock_tone", pan = 0f, volume = 0.8f, rate = 1.6f)
        delay(700)
    })
    cards.add(SoundCard(
        "Crash",
        "A crash. You hit a vehicle. You lose one of your three lives."
    ) { s ->
        s.playSpatial("crash", pan = 0f, volume = 1.0f)
        delay(2600)
    })
    cards.add(SoundCard(
        "New level",
        "A high tone and the voice saying the level number. The car gets faster at every level."
    ) { s ->
        s.playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.2f)
        delay(400)
    })
    cards.add(SoundCard(
        "Lane beeps",
        "When you change lane you hear a beep: low on the left for the left lane, middle for the middle lane, high on the right for the right lane."
    ) { s ->
        s.playSpatial("beep", pan = -0.8f, volume = 0.7f, rate = 0.8f)
        delay(700)
        s.playSpatial("beep", pan = 0f, volume = 0.7f, rate = 1.0f)
        delay(700)
        s.playSpatial("beep", pan = 0.8f, volume = 0.7f, rate = 1.25f)
        delay(500)
    })
    cards.add(SoundCard(
        "Roadside noises",
        "From level four, dogs, cows, owls and cheering crowds make noises beside the road. They are NOT cars. Ignore them."
    ) { s ->
        s.playSpatial("dog_bark", pan = -0.9f, volume = 0.5f)
        delay(1500)
        s.playSpatial("cow_moo", pan = 0.8f, volume = 0.5f)
        delay(2200)
        s.playSpatial("owl_hoot", pan = -0.5f, volume = 0.5f)
        delay(1800)
    })
    cards.add(SoundCard(
        "Rain",
        "From level seven it rains. The rain makes it harder to hear. Listen carefully."
    ) { s -> loopFor(s, "rain_loop", 3000, 0f, 0.4f, 1.0f) })
    cards.add(SoundCard(
        "Game over",
        "A siren: all three lives are gone, and the game is over."
    ) { s ->
        s.playSpatial("siren", pan = 0f, volume = 0.6f)
        delay(3500)
    })
    cards.addAll(recordSoundCards())
    return cards
}

fun classicSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "Engine and gears",
        "The engine sound goes up with your gear. A tap on the top edge shifts up with a gear change sound. Four gears."
    ) { s ->
        val e = EngineSound(s)
        try {
            for (i in 0..40) {
                e.update(i / 40f)
                if (i == 10 || i == 20 || i == 30) s.playSpatial("gear_shift", pan = 0f, volume = 0.9f)
                delay(60)
            }
        } finally {
            e.stop()
        }
    })
    cards.add(SoundCard(
        "Brake",
        "Two quick taps on the bottom edge brake hard, with a squeal."
    ) { s ->
        s.playSpatial("brake_screech", pan = 0f, volume = 1.0f)
        delay(1800)
    })
    cards.add(SoundCard(
        "Lane beeps",
        "When you change lane you hear a beep: low on the left for the left lane, middle for the middle lane, high on the right for the right lane."
    ) { s ->
        s.playSpatial("beep", pan = -0.8f, volume = 0.7f, rate = 0.8f)
        delay(700)
        s.playSpatial("beep", pan = 0f, volume = 0.7f, rate = 1.0f)
        delay(700)
        s.playSpatial("beep", pan = 0.8f, volume = 0.7f, rate = 1.25f)
        delay(500)
    })
    cards.add(SoundCard(
        "Highway: car coming",
        "On the highway, cars come at you in the three lanes. The sound sits on the side of the lane, and gets louder and higher as the car comes closer."
    ) { s -> comingCloser(s, "car_hum", 3500, -0.8f, 0.85f, 1.4f) })
    cards.add(SoundCard(
        "Highway: car in your lane",
        "A horn and fast beeps mean the car is in YOUR lane. Change lane or slow down."
    ) { s ->
        s.playSpatial("horn", pan = 0f, volume = 1.0f)
        sensorBeeps(s, "warn_beep", 12, 0f, 380, 100, 1.0f, 1.7f)
    })
    cards.add(SoundCard(
        "Highway: car passes",
        "A whoosh: a car has passed you."
    ) { s ->
        s.playSpatial("car_pass", pan = 0.5f, volume = 1.0f)
        delay(2300)
    })
    cards.add(SoundCard(
        "Crash",
        "A crash. You lose one of your three lives. After the last life, a siren."
    ) { s ->
        s.playSpatial("crash", pan = 0f, volume = 1.0f)
        delay(2600)
    })
    cards.add(SoundCard(
        "Jungle: deer",
        "A deer on the road, on the side you hear it. Slow down."
    ) { s ->
        s.playSpatial("deer_call", pan = -0.6f, volume = 1.0f)
        delay(1500)
    })
    cards.add(SoundCard(
        "Jungle: elephant",
        "An elephant on the road. Keep away, steer to the other lane."
    ) { s ->
        s.playSpatial("elephant_call", pan = 0.6f, volume = 1.0f)
        delay(2800)
    })
    cards.add(SoundCard(
        "Jungle: monkey",
        "A monkey on the road, on the side you hear it."
    ) { s ->
        s.playSpatial("monkey_call", pan = -0.6f, volume = 1.0f)
        delay(2200)
    })
    cards.add(SoundCard(
        "Jungle: tiger",
        "A tiger. Do not stop. Steer away from the side you hear it."
    ) { s ->
        s.playSpatial("tiger_roar", pan = 0.6f, volume = 1.0f)
        delay(2400)
    })
    cards.add(SoundCard(
        "Jungle: owl",
        "An owl in the night. It is only a sound of the jungle."
    ) { s ->
        s.playSpatial("owl_hoot", pan = -0.4f, volume = 0.7f)
        delay(2700)
    })
    cards.add(SoundCard(
        "Jungle: fallen tree",
        "A tree falls. Beeps in a lane mean that lane is blocked. The silent lane is free. Steer into the silent lane."
    ) { s ->
        s.playSpatial("tree_fall", pan = 0f, volume = 0.9f)
        delay(3500)
        for (i in 0 until 6) {
            s.playSpatial("warn_beep", pan = -0.8f, volume = 0.7f)
            s.playSpatial("warn_beep", pan = 0.8f, volume = 0.7f)
            delay(300)
        }
    })
    cards.add(SoundCard(
        "Jungle: pothole",
        "Low beeps in your lane mean a pothole. If you go too fast over it, a tyre bursts."
    ) { s ->
        sensorBeeps(s, "warn_beep", 6, 0f, 450, 150, 0.6f, 1.0f)
        delay(300)
        s.playSpatial("pothole_thud", pan = 0f, volume = 1.0f)
        delay(1200)
    })
    cards.add(SoundCard(
        "Jungle: bridge",
        "A narrow wooden bridge: the planks creak. Stay in the middle lane and do not go too fast."
    ) { s ->
        s.playSpatial("bridge_creak", pan = 0f, volume = 0.6f)
        delay(3000)
    })
    cards.add(SoundCard(
        "Jungle: rain and thunder",
        "Rain and thunder. Only the weather."
    ) { s ->
        val id = s.playLoop("rain_loop", 0f, 0.45f, 1.0f)
        try {
            delay(1000)
            s.playSpatial("thunder_roll", pan = 0.4f, volume = 0.7f)
            delay(3500)
        } finally {
            s.stopStream(id)
        }
    })
    cards.addAll(recordSoundCards())
    return cards
}

fun cricketSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "The computer bowls",
        "When you bat, the computer bowls before every ball. First the bowler's footsteps as he runs in, quicker and louder. Then the ball flying at you, six whooshes, louder and higher. Then a short tone: now pick your number."
    ) { s -> CricketAudio.play(s, CricketAudio.botDeliveryCues()) })
    cards.add(SoundCard(
        "Batsman gets ready",
        "When you bowl, you hear the batsman tap his bat on the ground twice, then a short low tone. Then pick your bowling number."
    ) { s -> CricketAudio.play(s, CricketAudio.batsmanReadyCues()) })
    cards.add(SoundCard(
        "You bowl",
        "After you pick your number, you hear your own run-up, then the ball flying away from you, getting quieter."
    ) { s -> CricketAudio.play(s, CricketAudio.playerDeliveryCues()) })
    cards.add(SoundCard(
        "Soft hit",
        "A soft hit: one, two or three runs."
    ) { s ->
        CricketAudio.playOutcome(s, false, 2, true)
        delay(1200)
    })
    cards.add(SoundCard(
        "Hard hit",
        "A hard hit and a cheer: four or five runs."
    ) { s ->
        CricketAudio.playOutcome(s, false, 4, true)
        delay(2800)
    })
    cards.add(SoundCard(
        "Six",
        "A hard hit and a roaring crowd: six runs."
    ) { s ->
        CricketAudio.playOutcome(s, false, 6, true)
        delay(4300)
    })
    cards.add(SoundCard(
        "You are out",
        "The stumps are hit and the crowd groans. You are out when you bat."
    ) { s ->
        CricketAudio.playOutcome(s, true, 0, true)
        delay(2400)
    })
    cards.add(SoundCard(
        "You got him out",
        "The stumps are hit and the crowd cheers. The computer is out when you bowl."
    ) { s ->
        CricketAudio.playOutcome(s, true, 0, false)
        delay(2000)
    })
    cards.add(SoundCard(
        "Umpire's whistle",
        "The umpire's whistle. The innings is over. The voice then says the score and who bats next."
    ) { s ->
        CricketAudio.playInningsOver(s)
        delay(1700)
    })
    cards.add(SoundCard(
        "You win the match",
        "The whistle, then applause and a roaring crowd: you won the match."
    ) { s ->
        CricketAudio.playMatchOver(s, true, false)
        delay(6300)
    })
    cards.add(SoundCard(
        "You lose the match",
        "The whistle, then a groan: the computer won the match."
    ) { s ->
        CricketAudio.playMatchOver(s, false, false)
        delay(2400)
    })
    cards.add(SoundCard(
        "Coin toss",
        "The coin toss at the start. You call odd or even, then you and the computer show a number. If the total matches your call, you win the toss."
    ) { s ->
        s.playSpatial("coin_toss", pan = 0f, volume = 0.9f)
        delay(1800)
    })
    cards.add(SoundCard(
        "The crowd",
        "The crowd murmurs quietly all through the match."
    ) { s -> loopFor(s, "crowd_loop", 2800, 0f, 0.3f, 1.0f) })
    cards.addAll(recordSoundCards())
    return cards
}

fun gunSoundCards(): List<SoundCard> {
    val cards = ArrayList<SoundCard>()
    cards.add(SoundCard(
        "Pistol",
        "The pistol. Fast and light. Twelve bullets."
    ) { s ->
        s.playSpatial("gun_pistol", pan = 0f, volume = 1.0f)
        delay(1100)
    })
    cards.add(SoundCard(
        "Assault rifle",
        "The assault rifle. Rapid fire. Thirty bullets."
    ) { s ->
        repeated(s, "gun_rifle", 4, 0f, 160, 1.0f, 1.0f)
        delay(700)
    })
    cards.add(SoundCard(
        "Shotgun",
        "The shotgun. A heavy boom. Huge damage up close. Six shells."
    ) { s ->
        s.playSpatial("gun_shotgun", pan = 0f, volume = 1.0f)
        delay(1700)
    })
    cards.add(SoundCard(
        "Sniper rifle",
        "The sniper rifle. One loud slow shot. Two hits kill. Five bullets."
    ) { s ->
        s.playSpatial("gun_sniper", pan = 0f, volume = 1.0f)
        delay(1900)
    })
    cards.add(SoundCard(
        "Reload",
        "Reloading. The magazine goes in. Wait until it finishes before you shoot."
    ) { s ->
        s.playSpatial("reload_pistol", pan = 0f, volume = 0.9f)
        delay(1400)
    })
    cards.add(SoundCard(
        "Empty click",
        "A click when you pull the trigger means the gun is empty or still reloading. Tap the bottom edge to reload."
    ) { s ->
        s.playSpatial("gun_empty", pan = 0f, volume = 0.9f)
        delay(600)
    })
    cards.add(SoundCard(
        "Enemy walking",
        "The enemy's footsteps. They tell you where he is: on your left, on your right, in front or behind. Slow steps mean he walks. Closer means louder."
    ) { s ->
        for (i in 0 until 5) {
            s.playSpatial("step_${i % 3 + 1}", pan = -0.7f + 0.15f * i, volume = 0.5f + 0.1f * i, rate = 1.0f)
            delay(740)
        }
    })
    cards.add(SoundCard(
        "Enemy running",
        "Quick, higher steps mean the enemy is running. He is harder to hit."
    ) { s ->
        for (i in 0 until 8) {
            s.playSpatial("step_${i % 3 + 1}", pan = 0.7f - 0.15f * i, volume = 0.9f, rate = 1.25f)
            delay(360)
        }
    })
    cards.add(SoundCard(
        "Aim tone",
        "A beeping tone means the enemy is in front of you. It beeps faster and gets higher the better you are aimed. Fire when it is fastest."
    ) { s ->
        for (i in 0 until 10) {
            val c = i / 9f
            s.playSpatial("lock_tone", pan = 0f, volume = 0.7f, rate = 0.9f + 0.5f * c)
            delay((320 - 160 * c).toLong())
        }
    })
    cards.add(SoundCard(
        "Enemy shoots",
        "The enemy fires. The shot comes from his side. If you hear a thump on you, you are hit."
    ) { s ->
        s.playSpatial("gun_pistol", pan = 0.7f, volume = 0.9f, rate = 0.95f)
        delay(900)
    })
    cards.add(SoundCard(
        "Bullet flying past",
        "A bullet whizzing past on one side means he missed you."
    ) { s ->
        s.playSpatial("bullet_whiz", pan = -0.7f, volume = 1.0f)
        delay(900)
    })
    cards.add(SoundCard(
        "You are hit",
        "A thump on your body: you are hit. The phone vibrates. The voice tells you your health at two thirds and one third."
    ) { s ->
        s.playSpatial("body_hit", pan = 0f, volume = 0.9f)
        s.vibrate(150)
        delay(1100)
    })
    cards.add(SoundCard(
        "Heartbeat",
        "A heartbeat means your health is low. It gets faster and louder the lower your health."
    ) { s -> loopFor(s, "heartbeat", 3000, 0f, 0.8f, 1.2f) })
    cards.add(SoundCard(
        "Turning clicks",
        "When you turn, a soft tick every 15 degrees, and a clear click when you face north, east, south or west."
    ) { s ->
        repeated(s, "ui_tick", 4, 0f, 300, 0.6f, 1.0f)
        s.playSpatial("ui_detent", pan = 0f, volume = 0.9f)
        delay(400)
    })
    cards.add(SoundCard(
        "Wall thud",
        "A thud means you walked into a wall, or into the enemy."
    ) { s ->
        s.playSpatial("wall_thud", pan = 0f, volume = 0.9f)
        delay(500)
    })
    cards.add(SoundCard(
        "Round start countdown",
        "A countdown before every round. Fight starts when it ends."
    ) { s ->
        s.playSpatial("fight_countdown", pan = 0f, volume = 1.0f)
        delay(4100)
    })
    cards.add(SoundCard(
        "Enemy down",
        "A death sound from the enemy's side: you won the round. You must win three rounds to win the match."
    ) { s ->
        s.playSpatial("death", pan = 0.4f, volume = 1.0f, rate = 0.85f)
        delay(2600)
    })
    cards.add(SoundCard(
        "You win the match",
        "A fanfare: you won the match."
    ) { s ->
        s.playSpatial("victory", pan = 0f, volume = 1.0f)
        delay(4400)
    })
    cards.add(SoundCard(
        "You lose the match",
        "A sad sound: the enemy won the match."
    ) { s ->
        s.playSpatial("game_over", pan = 0f, volume = 1.0f)
        delay(2600)
    })
    cards.addAll(recordSoundCards())
    return cards
}
