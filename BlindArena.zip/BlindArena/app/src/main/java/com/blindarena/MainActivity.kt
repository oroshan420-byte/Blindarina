package com.blindarena

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

// =========================================================================
// 1. AUTONOMOUS SCREEN READER SYSTEM (MyScreenReader)
// =========================================================================
object MyScreenReader : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    var speechRate: Float = 1.0f
        private set

    var lastSpokenText: String = "Welcome to Blind Arena"
        private set

    var currentHelpContext: String = "Use swipe right to explore, double tap to activate"

    data class FocusItem(
        val id: String,
        val label: String,
        val role: String = "button",
        val hint: String = "",
        val onAction: () -> Unit
    )

    private val focusRegistry = mutableListOf<FocusItem>()
    val currentFocusIndex = mutableStateOf(-1)
    val currentSpokenTextState = mutableStateOf("")

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { engine ->
                engine.setLanguage(Locale.US)
                engine.setSpeechRate(speechRate)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {}
                })
                isInitialized = true
                speak("Blind Arena screen reader initialized. Swipe right to explore.")
            }
        }
    }

    fun speak(text: String, flush: Boolean = true) {
        if (text.isBlank()) return
        lastSpokenText = text
        currentSpokenTextState.value = text

        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, System.currentTimeMillis().toString())
        }

        if (isInitialized && tts != null) {
            tts?.speak(text, queueMode, params, params.getString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID))
        }
    }

    fun setRate(rate: Float) {
        val clamped = rate.coerceIn(0.5f, 2.0f)
        speechRate = clamped
        tts?.setSpeechRate(clamped)
        speak("Speech speed set to ${String.format(Locale.US, "%.1f", clamped)}x")
    }

    fun onScreenChanged(screenTitle: String, instructions: String) {
        currentHelpContext = instructions
        speak("$screenTitle. $instructions", flush = true)
    }

    fun registerItem(item: FocusItem) {
        val existing = focusRegistry.indexOfFirst { it.id == item.id }
        if (existing >= 0) {
            focusRegistry[existing] = item
        } else {
            focusRegistry.add(item)
        }
        if (currentFocusIndex.value == -1 && focusRegistry.isNotEmpty()) {
            currentFocusIndex.value = 0
        }
    }

    fun clearItems() {
        focusRegistry.clear()
        currentFocusIndex.value = -1
    }

    fun focusNext() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = (currentFocusIndex.value + 1) % focusRegistry.size
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun focusPrevious() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = if (currentFocusIndex.value < 0) {
            focusRegistry.size - 1
        } else {
            (currentFocusIndex.value - 1 + focusRegistry.size) % focusRegistry.size
        }
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun onTouchItem(id: String) {
        val index = focusRegistry.indexOfFirst { it.id == id }
        if (index >= 0) {
            currentFocusIndex.value = index
            val item = focusRegistry[index]
            speak("${item.label}, ${item.role}. Double tap to activate.")
        }
    }

    fun activateFocusedItem() {
        val index = currentFocusIndex.value
        if (index in focusRegistry.indices) {
            val item = focusRegistry[index]
            speak("Activating ${item.label}")
            item.onAction()
        }
    }

    fun repeatLastSpeech() {
        speak("Repeating: $lastSpokenText")
    }

    fun speakHelp() {
        val focused = if (currentFocusIndex.value in focusRegistry.indices) {
            focusRegistry[currentFocusIndex.value]
        } else null

        val focusedHint = if (focused != null && focused.hint.isNotBlank()) {
            " Current selection is ${focused.label}. ${focused.hint}"
        } else ""

        speak("Help. $currentHelpContext$focusedHint", flush = true)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}

// =========================================================================
// 2. GESTURE DETECTOR (Captures touches before TalkBack)
// =========================================================================
fun Modifier.myScreenReaderGestures(
    onDirectDoubleTap: (() -> Unit)? = null
): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        coroutineScope {
            var lastTapTime = 0L
            var lastTapPointerCount = 1

            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val downTime = System.currentTimeMillis()
                val startPos = down.position
                var pointersCount = 1
                var isLongPressTriggered = false

                while (true) {
                    val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                    pointersCount = maxOf(pointersCount, event.changes.size)

                    // 1 Second Long Press Detection -> Help
                    if (!isLongPressTriggered && (System.currentTimeMillis() - downTime) >= 1000L) {
                        val currentChange = event.changes.firstOrNull()
                        val distance = if (currentChange != null) {
                            (currentChange.position - startPos).getDistance()
                        } else 0f

                        if (distance < 40f) {
                            isLongPressTriggered = true
                            MyScreenReader.speakHelp()
                            break
                        }
                    }

                    if (event.changes.all { !it.pressed }) {
                        val upTime = System.currentTimeMillis()
                        val duration = upTime - downTime
                        val endPos = event.changes.firstOrNull()?.position ?: startPos
                        val dx = endPos.x - startPos.x
                        val dy = endPos.y - startPos.y

                        if (isLongPressTriggered) break

                        // Swipes
                        if (abs(dx) > 120f && abs(dx) > abs(dy) * 1.5f && duration < 500) {
                            if (dx > 0) MyScreenReader.focusNext()
                            else MyScreenReader.focusPrevious()
                        } else if (abs(dx) < 60f && abs(dy) < 60f && duration < 350) {
                            // Double Tap
                            val timeSinceLast = upTime - lastTapTime
                            if (timeSinceLast < 350L) {
                                if (pointersCount >= 2 || lastTapPointerCount >= 2) {
                                    MyScreenReader.repeatLastSpeech()
                                } else {
                                    if (onDirectDoubleTap != null) onDirectDoubleTap()
                                    else MyScreenReader.activateFocusedItem()
                                }
                                lastTapTime = 0L
                            } else {
                                lastTapTime = upTime
                                lastTapPointerCount = pointersCount
                            }
                        }
                        break
                    }
                }
            }
        }
    }

// =========================================================================
// 3. 3D SPATIAL AUDIO & SOUNDPOOL ENGINE (SoundManager)
// =========================================================================
class SoundManager(private val context: Context) {
    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<String, Int>()
    private var engineStreamId: Int = 0

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(32)
            .setAudioAttributes(audioAttributes)
            .build()

        loadAll()
    }

    fun loadSound(tag: String, resId: Int) {
        val id = soundPool.load(context, resId, 1)
        soundMap[tag] = id
    }

    // Loads every sound effect from res/raw. Swap the .wav files there to change the sounds.
    private fun loadAll() {
        loadSound("engine_loop", R.raw.engine_loop)
        loadSound("beep", R.raw.beep)
        loadSound("ball_whoosh", R.raw.ball_whoosh)
        loadSound("bat_crack", R.raw.bat_crack)
        loadSound("stumps_clatter", R.raw.stumps_clatter)
        loadSound("footstep", R.raw.footstep)
        loadSound("lock_tone", R.raw.lock_tone)
        loadSound("gunshot", R.raw.gunshot)
        loadSound("car_hum", R.raw.car_hum)
        loadSound("car_pass", R.raw.car_pass)
        loadSound("horn", R.raw.horn)
        loadSound("crash", R.raw.crash)
        loadSound("cheer", R.raw.cheer)
        loadSound("tire_screech", R.raw.tire_screech)
        loadSound("road_ambience", R.raw.road_ambience)
        loadSound("siren", R.raw.siren)
        loadSound("gun_pistol", R.raw.gun_pistol)
        loadSound("gun_rifle", R.raw.gun_rifle)
        loadSound("gun_shotgun", R.raw.gun_shotgun)
        loadSound("gun_sniper", R.raw.gun_sniper)
        loadSound("gun_empty", R.raw.gun_empty)
        loadSound("reload_pistol", R.raw.reload_pistol)
        loadSound("reload_rifle", R.raw.reload_rifle)
        loadSound("reload_shotgun", R.raw.reload_shotgun)
        loadSound("step_1", R.raw.step_1)
        loadSound("step_2", R.raw.step_2)
        loadSound("step_3", R.raw.step_3)
        loadSound("bullet_whiz", R.raw.bullet_whiz)
        loadSound("body_hit", R.raw.body_hit)
        loadSound("death", R.raw.death)
        loadSound("game_over", R.raw.game_over)
        loadSound("victory", R.raw.victory)
        loadSound("fight_countdown", R.raw.fight_countdown)
        loadSound("heartbeat", R.raw.heartbeat)
        loadSound("warehouse_loop", R.raw.warehouse_loop)
    }

    fun playSpatial(tag: String, pan: Float = 0f, volume: Float = 1.0f, rate: Float = 1.0f): Int {
        val soundId = soundMap[tag] ?: return 0
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = (volume * (if (clampedPan > 0f) 1.0f - clampedPan else 1.0f)).coerceIn(0f, 1f)
        val rightVol = (volume * (if (clampedPan < 0f) 1.0f + clampedPan else 1.0f)).coerceIn(0f, 1f)
        return soundPool.play(soundId, leftVol, rightVol, 1, 0, rate.coerceIn(0.5f, 2.0f))
    }

    // Looping stream whose pan, volume and pitch can be changed while it plays (used for approaching cars)
    fun playLoop(tag: String, pan: Float, volume: Float, rate: Float): Int {
        val soundId = soundMap[tag] ?: return 0
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = (volume * (if (clampedPan > 0f) 1.0f - clampedPan else 1.0f)).coerceIn(0f, 1f)
        val rightVol = (volume * (if (clampedPan < 0f) 1.0f + clampedPan else 1.0f)).coerceIn(0f, 1f)
        return soundPool.play(soundId, leftVol, rightVol, 2, -1, rate.coerceIn(0.5f, 2.0f))
    }

    fun updateStream(streamId: Int, pan: Float, volume: Float, rate: Float) {
        if (streamId == 0) return
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = (volume * (if (clampedPan > 0f) 1.0f - clampedPan else 1.0f)).coerceIn(0f, 1f)
        val rightVol = (volume * (if (clampedPan < 0f) 1.0f + clampedPan else 1.0f)).coerceIn(0f, 1f)
        soundPool.setVolume(streamId, leftVol, rightVol)
        soundPool.setRate(streamId, rate.coerceIn(0.5f, 2.0f))
    }

    fun stopStream(streamId: Int) {
        if (streamId != 0) soundPool.stop(streamId)
    }

    fun setEngineRate(rate: Float) {
        if (engineStreamId != 0) soundPool.setRate(engineStreamId, rate.coerceIn(0.5f, 2.0f))
    }

    fun pauseAll() {
        soundPool.autoPause()
    }

    fun resumeAll() {
        soundPool.autoResume()
    }

    fun startEngineLoop(tag: String) {
        val soundId = soundMap[tag] ?: return
        if (engineStreamId == 0) {
            engineStreamId = soundPool.play(soundId, 0.4f, 0.4f, 3, -1, 1.0f)
        }
    }

    fun stopEngine() {
        if (engineStreamId != 0) {
            soundPool.stop(engineStreamId)
            engineStreamId = 0
        }
    }

    fun playOffTrackBeep(direction: String) {
        val pan = if (direction == "left") -0.95f else 0.95f
        playSpatial("beep", pan = pan, volume = 0.8f, rate = 1.2f)
        vibrate(60)
    }

    fun playBallApproach(progress: Float) {
        val rate = 0.8f + (progress * 0.7f)
        val vol = 0.2f + (progress * 0.8f)
        playSpatial("ball_whoosh", pan = 0f, volume = vol, rate = rate)
    }

    fun playBatHit(quality: String) {
        val rate = if (quality == "perfect") 1.2f else 1.0f
        playSpatial("bat_crack", pan = 0f, volume = 1.0f, rate = rate)
        vibrate(100)
    }

    fun playStumpsOut() {
        playSpatial("stumps_clatter", pan = 0f, volume = 1.0f)
        vibrate(250)
    }

    fun playFootsteps(pan: Float, distance: Float) {
        val volume = (1.0f - (distance / 12f)).coerceIn(0.1f, 1.0f)
        playSpatial("footstep", pan = pan, volume = volume)
    }

    fun playTargetLockTone() {
        playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.5f)
        vibrate(40)
    }

    fun playGunshot(hit: Boolean) {
        playSpatial("gunshot", pan = 0f, volume = 1.0f)
        if (hit) vibrate(150)
    }

    fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        stopEngine()
        soundPool.release()
    }
}

// =========================================================================
// 4. MAIN ACTIVITY
// =========================================================================
class MainActivity : ComponentActivity(), SensorEventListener {
    lateinit var soundManager: SoundManager
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var rotationSensor: Sensor? = null

    val tiltX = mutableStateOf(0f)
    val phoneAzimuth = mutableStateOf(0f)
    val currentScreen = mutableStateOf("MENU")
    val isPaused = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        // Games are played without touching the screen, so never let it sleep
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        MyScreenReader.init(this)
        soundManager = SoundManager(this)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        setContent {
            val screen = currentScreen.value

            // System back (or back gesture) returns to the menu from any game
            BackHandler(enabled = screen != "MENU") { currentScreen.value = "MENU" }

            // Gestures are attached per screen (not here) so a game's double tap
            // never also triggers a stale menu item.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
            ) {
                when (screen) {
                    "MENU" -> MainMenuScreen(onNavigate = { currentScreen.value = it })
                    "RACING" -> CarDriveScreen(soundManager, isPaused.value)
                    "CRICKET" -> HandCricketScreen(soundManager, onBack = { currentScreen.value = "MENU" })
                    "GUNFIGHT" -> GunDuelScreen(soundManager, phoneAzimuth.value, isPaused.value, onBack = { currentScreen.value = "MENU" })
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isPaused.value = false
        if (::soundManager.isInitialized) soundManager.resumeAll()
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        isPaused.value = true
        if (::soundManager.isInitialized) soundManager.pauseAll()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        MyScreenReader.shutdown()
        soundManager.release()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> tiltX.value = event.values[0]
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val usable = FloatArray(9)
                if (Math.abs(rotationMatrix[8]) > 0.7f) {
                    // Phone lying flat: the matrix can be used as it is
                    System.arraycopy(rotationMatrix, 0, usable, 0, 9)
                } else {
                    // Phone held upright: remap so turning left or right still changes the heading smoothly
                    SensorManager.remapCoordinateSystem(rotationMatrix, SensorManager.AXIS_X, SensorManager.AXIS_Z, usable)
                }
                val orientation = FloatArray(3)
                SensorManager.getOrientation(usable, orientation)
                phoneAzimuth.value = Math.toDegrees(orientation[0].toDouble()).toFloat()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

// =========================================================================
// 5. MAIN MENU SCREEN
// =========================================================================
@Composable
fun MainMenuScreen(onNavigate: (String) -> Unit) {
    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_racing", "Mode 1: Highway Drive", "button", "Touch and hold left or right side of the screen to steer.") { onNavigate("RACING") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_cricket", "Mode 2: Hand Cricket", "button", "Pick numbers against the computer. Choose overs and wickets.") { onNavigate("CRICKET") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_gunfight", "Mode 3: Gun Fight 1 vs 1", "button", "Fight a bot. Turn to face the sounds and tap to fire. Choose weapon and difficulty.") { onNavigate("GUNFIGHT") })
        // Nothing focused yet: the first swipe right reads Mode 1, and a stray double tap does nothing
        MyScreenReader.currentFocusIndex.value = -1
        MyScreenReader.onScreenChanged("Blind Arena Main Menu", "Three audio games available. Swipe right to explore modes. Double tap to select.")
    }

    val focusedIndex = MyScreenReader.currentFocusIndex.value
    val spokenText = MyScreenReader.currentSpokenTextState.value

    Column(
        modifier = Modifier.fillMaxSize().myScreenReaderGestures().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("BLIND ARENA", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Audio-First Gaming Engine with Autonomous Screen Reader", fontSize = 13.sp, color = Color(0xFF94A3B8))
        }

        Box(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF1E293B), RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("Screen Reader: \"$spokenText\"", color = Color(0xFF38BDF8), fontSize = 15.sp)
        }

        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val modes = listOf(
                "mode_racing" to "Mode 1: Highway Drive",
                "mode_cricket" to "Mode 2: Hand Cricket",
                "mode_gunfight" to "Mode 3: Gun Fight 1 vs 1"
            )
            modes.forEachIndexed { index, (id, label) ->
                val isSelected = focusedIndex == index
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else Color(0xFF334155), RoundedCornerShape(10.dp))
                        .clickable { MyScreenReader.onTouchItem(id) }
                        .padding(18.dp)
                ) {
                    Text(label, color = Color.White, fontSize = 18.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
        Text("Gestures: Swipe Left/Right · Double Tap Select · Hold 1s Help", color = Color(0xFF64748B), fontSize = 12.sp)
    }
}

// =========================================================================
// 6. MODE 1: HIGHWAY DRIVE (see CarDrive.kt)
// =========================================================================
// =========================================================================
// 7. MODE 2: HAND CRICKET (see HandCricket.kt)
// =========================================================================
