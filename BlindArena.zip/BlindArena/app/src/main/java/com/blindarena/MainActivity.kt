package com.blindarena

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.view.View
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.abs

// =========================================================================
// 1. AUTONOMOUS SCREEN READER SYSTEM (MyScreenReader)
// =========================================================================
object MyScreenReader : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    var speechRate: Float = 1.0f
        private set

    var lastSpokenText: String = "Welcome to Blind Arena"
        private set

    var currentHelpContext: String = "Use swipe right to explore, double tap to activate"

    data class FocusItem(
        val id: String,
        val label: String,
        val role: String = "button",
        val hint: String = "",
        val onAction: () -> Unit
    )

    private val focusRegistry = mutableListOf<FocusItem>()
    val currentFocusIndex = mutableStateOf(-1)
    val currentSpokenTextState = mutableStateOf("")

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { engine ->
                engine.setLanguage(Locale.US)
                engine.setSpeechRate(speechRate)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {}
                })
                isInitialized = true
                speak("Blind Arena screen reader initialized. Swipe right to explore.")
            }
        }
    }

    fun speak(text: String, flush: Boolean = true) {
        if (text.isBlank()) return
        lastSpokenText = text
        currentSpokenTextState.value = text

        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, System.currentTimeMillis().toString())
        }

        if (isInitialized && tts != null) {
            tts?.speak(text, queueMode, params, params.getString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID))
        }
    }

    fun setRate(rate: Float) {
        val clamped = rate.coerceIn(0.5f, 2.0f)
        speechRate = clamped
        tts?.setSpeechRate(clamped)
        speak("Speech speed set to ${String.format(Locale.US, "%.1f", clamped)}x")
    }

    fun onScreenChanged(screenTitle: String, instructions: String) {
        currentHelpContext = instructions
        speak("$screenTitle. $instructions", flush = true)
    }

    fun registerItem(item: FocusItem) {
        val existing = focusRegistry.indexOfFirst { it.id == item.id }
        if (existing >= 0) {
            focusRegistry[existing] = item
        } else {
            focusRegistry.add(item)
        }
        if (currentFocusIndex.value == -1 && focusRegistry.isNotEmpty()) {
            currentFocusIndex.value = 0
        }
    }

    fun clearItems() {
        focusRegistry.clear()
        currentFocusIndex.value = -1
    }

    fun focusNext() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = (currentFocusIndex.value + 1) % focusRegistry.size
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun focusPrevious() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = (currentFocusIndex.value - 1 + focusRegistry.size) % focusRegistry.size
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun onTouchItem(id: String) {
        val index = focusRegistry.indexOfFirst { it.id == id }
        if (index >= 0) {
            currentFocusIndex.value = index
            val item = focusRegistry[index]
            speak("${item.label}, ${item.role}. Double tap to activate.")
        }
    }

    fun activateFocusedItem() {
        val index = currentFocusIndex.value
        if (index in focusRegistry.indices) {
            val item = focusRegistry[index]
            speak("Activating ${item.label}")
            item.onAction()
        }
    }

    fun repeatLastSpeech() {
        speak("Repeating: $lastSpokenText")
    }

    fun speakHelp() {
        val focused = if (currentFocusIndex.value in focusRegistry.indices) {
            focusRegistry[currentFocusIndex.value]
        } else null

        val focusedHint = if (focused != null && focused.hint.isNotBlank()) {
            " Current selection is ${focused.label}. ${focused.hint}"
        } else ""

        speak("Help. $currentHelpContext$focusedHint", flush = true)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
    }
}

// =========================================================================
// 2. GESTURE DETECTOR (Captures touches before TalkBack)
// =========================================================================
fun Modifier.myScreenReaderGestures(
    onDirectDoubleTap: (() -> Unit)? = null
): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        coroutineScope {
            var lastTapTime = 0L
            var lastTapPointerCount = 1

            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val downTime = System.currentTimeMillis()
                val startPos = down.position
                var pointersCount = 1
                var isLongPressTriggered = false

                while (true) {
                    val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                    pointersCount = maxOf(pointersCount, event.changes.size)

                    // 1 Second Long Press Detection -> Help
                    if (!isLongPressTriggered && (System.currentTimeMillis() - downTime) >= 1000L) {
                        val currentChange = event.changes.firstOrNull()
                        val distance = if (currentChange != null) {
                            (currentChange.position - startPos).getDistance()
                        } else 0f

                        if (distance < 40f) {
                            isLongPressTriggered = true
                            MyScreenReader.speakHelp()
                            break
                        }
                    }

                    if (event.changes.all { !it.pressed }) {
                        val upTime = System.currentTimeMillis()
                        val duration = upTime - downTime
                        val endPos = event.changes.firstOrNull()?.position ?: startPos
                        val dx = endPos.x - startPos.x
                        val dy = endPos.y - startPos.y

                        if (isLongPressTriggered) break

                        // Swipes
                        if (abs(dx) > 120f && abs(dx) > abs(dy) * 1.5f && duration < 500) {
                            if (dx > 0) MyScreenReader.focusNext()
                            else MyScreenReader.focusPrevious()
                        } else if (abs(dx) < 60f && abs(dy) < 60f && duration < 350) {
                            // Double Tap
                            val timeSinceLast = upTime - lastTapTime
                            if (timeSinceLast < 350L) {
                                if (pointersCount >= 2 || lastTapPointerCount >= 2) {
                                    MyScreenReader.repeatLastSpeech()
                                } else {
                                    if (onDirectDoubleTap != null) onDirectDoubleTap()
                                    else MyScreenReader.activateFocusedItem()
                                }
                                lastTapTime = 0L
                            } else {
                                lastTapTime = upTime
                                lastTapPointerCount = pointersCount
                            }
                        }
                        break
                    }
                }
            }
        }
    }

// =========================================================================
// 3. 3D SPATIAL AUDIO & SOUNDPOOL ENGINE (SoundManager)
// =========================================================================
class SoundManager(private val context: Context) {
    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<String, Int>()
    private var engineStreamId: Int = 0

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(10)
            .setAudioAttributes(audioAttributes)
            .build()

        loadAll()
    }

    fun loadSound(tag: String, resId: Int) {
        val id = soundPool.load(context, resId, 1)
        soundMap[tag] = id
    }

    // Loads every sound effect from res/raw. Swap the .wav files there to change the sounds.
    private fun loadAll() {
        loadSound("engine_loop", R.raw.engine_loop)
        loadSound("beep", R.raw.beep)
        loadSound("ball_whoosh", R.raw.ball_whoosh)
        loadSound("bat_crack", R.raw.bat_crack)
        loadSound("stumps_clatter", R.raw.stumps_clatter)
        loadSound("footstep", R.raw.footstep)
        loadSound("lock_tone", R.raw.lock_tone)
        loadSound("gunshot", R.raw.gunshot)
    }

    fun playSpatial(tag: String, pan: Float = 0f, volume: Float = 1.0f, rate: Float = 1.0f): Int {
        val soundId = soundMap[tag] ?: return 0
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = volume * ((1.0f - clampedPan) / 2.0f + if (clampedPan <= 0f) 0.5f else 0f).coerceIn(0f, 1f)
        val rightVol = volume * ((1.0f + clampedPan) / 2.0f + if (clampedPan >= 0f) 0.5f else 0f).coerceIn(0f, 1f)
        return soundPool.play(soundId, leftVol, rightVol, 1, 0, rate)
    }

    fun startEngineLoop(tag: String) {
        val soundId = soundMap[tag] ?: return
        if (engineStreamId == 0) {
            engineStreamId = soundPool.play(soundId, 0.4f, 0.4f, 1, -1, 1.0f)
        }
    }

    fun stopEngine() {
        if (engineStreamId != 0) {
            soundPool.stop(engineStreamId)
            engineStreamId = 0
        }
    }

    fun playOffTrackBeep(direction: String) {
        val pan = if (direction == "left") -0.95f else 0.95f
        playSpatial("beep", pan = pan, volume = 0.8f, rate = 1.2f)
        vibrate(60)
    }

    fun playBallApproach(progress: Float) {
        val rate = 0.8f + (progress * 0.7f)
        val vol = 0.2f + (progress * 0.8f)
        playSpatial("ball_whoosh", pan = 0f, volume = vol, rate = rate)
    }

    fun playBatHit(quality: String) {
        val rate = if (quality == "perfect") 1.2f else 1.0f
        playSpatial("bat_crack", pan = 0f, volume = 1.0f, rate = rate)
        vibrate(100)
    }

    fun playStumpsOut() {
        playSpatial("stumps_clatter", pan = 0f, volume = 1.0f)
        vibrate(250)
    }

    fun playFootsteps(pan: Float, distance: Float) {
        val volume = (1.0f - (distance / 12f)).coerceIn(0.1f, 1.0f)
        playSpatial("footstep", pan = pan, volume = volume)
    }

    fun playTargetLockTone() {
        playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.5f)
        vibrate(40)
    }

    fun playGunshot(hit: Boolean) {
        playSpatial("gunshot", pan = 0f, volume = 1.0f)
        if (hit) vibrate(150)
    }

    fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        stopEngine()
        soundPool.release()
    }
}

// =========================================================================
// 4. MAIN ACTIVITY
// =========================================================================
class MainActivity : ComponentActivity(), SensorEventListener {
    lateinit var soundManager: SoundManager
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var rotationSensor: Sensor? = null

    val tiltX = mutableStateOf(0f)
    val phoneAzimuth = mutableStateOf(0f)
    val isPushToTalkActive = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        MyScreenReader.init(this)
        soundManager = SoundManager(this)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        setContent {
            var currentScreen by remember { mutableStateOf("MENU") }

            // System back (or back gesture) returns to the menu from any game
            BackHandler(enabled = currentScreen != "MENU") { currentScreen = "MENU" }

            // Gestures are attached per screen (not here) so a game's double tap
            // never also triggers a stale menu item.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
            ) {
                when (currentScreen) {
                    "MENU" -> MainMenuScreen(onNavigate = { currentScreen = it })
                    "RACING" -> CarRacingScreen(soundManager, tiltX.value, onBack = { currentScreen = "MENU" })
                    "CRICKET" -> CricketScreen(soundManager, onBack = { currentScreen = "MENU" })
                    "GUNFIGHT" -> GunFightScreen(soundManager, phoneAzimuth.value, onBack = { currentScreen = "MENU" })
                    "MULTIPLAYER" -> MultiplayerScreen(soundManager, isPushToTalkActive.value, onBack = { currentScreen = "MENU" })
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        MyScreenReader.shutdown()
        soundManager.release()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            isPushToTalkActive.value = true
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            isPushToTalkActive.value = false
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> tiltX.value = event.values[0]
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                phoneAzimuth.value = Math.toDegrees(orientation[0].toDouble()).toFloat()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

// =========================================================================
// 5. MAIN MENU SCREEN
// =========================================================================
@Composable
fun MainMenuScreen(onNavigate: (String) -> Unit) {
    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_racing", "Mode 1: Car Racing", "button", "Tilt phone to steer.") { onNavigate("RACING") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_cricket", "Mode 2: Blind Cricket", "button", "Listen for approaching ball.") { onNavigate("CRICKET") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_gunfight", "Mode 3: 3D Gun Fight", "button", "Rotate phone to aim.") { onNavigate("GUNFIGHT") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_multiplayer", "Mode 4: Play with Friends", "button", "Spoken dialpad and voice.") { onNavigate("MULTIPLAYER") })
        MyScreenReader.onScreenChanged("Blind Arena Main Menu", "Four audio games available. Swipe right to explore modes. Double tap to select.")
    }

    val focusedIndex = MyScreenReader.currentFocusIndex.value
    val spokenText = MyScreenReader.currentSpokenTextState.value

    Column(
        modifier = Modifier.fillMaxSize().myScreenReaderGestures().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("BLIND ARENA", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Audio-First Gaming Engine with Autonomous Screen Reader", fontSize = 13.sp, color = Color(0xFF94A3B8))
        }

        Box(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF1E293B), RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("Screen Reader: \"$spokenText\"", color = Color(0xFF38BDF8), fontSize = 15.sp)
        }

        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val modes = listOf(
                "mode_racing" to "Mode 1: Car Racing",
                "mode_cricket" to "Mode 2: Blind Cricket",
                "mode_gunfight" to "Mode 3: 3D Gun Fight",
                "mode_multiplayer" to "Mode 4: Play with Friends"
            )
            modes.forEachIndexed { index, (id, label) ->
                val isSelected = focusedIndex == index
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else Color(0xFF334155), RoundedCornerShape(10.dp))
                        .clickable { MyScreenReader.onTouchItem(id) }
                        .padding(18.dp)
                ) {
                    Text(label, color = Color.White, fontSize = 18.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
        Text("Gestures: Swipe Left/Right · Double Tap Select · Hold 1s Help", color = Color(0xFF64748B), fontSize = 12.sp)
    }
}

// =========================================================================
// 6. MODE 1: CAR RACING SCREEN
// =========================================================================
@Composable
fun CarRacingScreen(soundManager: SoundManager, tiltX: Float, onBack: () -> Unit) {
    var isOffTrackLeft by remember { mutableStateOf(false) }
    var isOffTrackRight by remember { mutableStateOf(false) }
    var offTrackDuration by remember { mutableStateOf(0L) }
    var lastVoiceAlertTime by remember { mutableStateOf(0L) }
    var distanceTravelled by remember { mutableStateOf(0) }

    // Always holds the latest sensor value, without restarting the game loop on every sensor tick
    val tilt by rememberUpdatedState(tiltX)

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.onScreenChanged("Racing Game", "Tilt left, tilt right. Avoid horn sound. Engine is centered.")
        soundManager.startEngineLoop("engine_loop")
    }

    DisposableEffect(Unit) {
        onDispose { soundManager.stopEngine() }
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(100)
            distanceTravelled += 5
            val threshold = 3.5f
            val now = System.currentTimeMillis()

            if (tilt > threshold) {
                isOffTrackLeft = true
                isOffTrackRight = false
                soundManager.playOffTrackBeep("left")
                offTrackDuration += 100
                if (offTrackDuration > 2000L && (now - lastVoiceAlertTime) > 2500L) {
                    MyScreenReader.speak("Going left! Steer right!")
                    lastVoiceAlertTime = now
                }
            } else if (tilt < -threshold) {
                isOffTrackRight = true
                isOffTrackLeft = false
                soundManager.playOffTrackBeep("right")
                offTrackDuration += 100
                if (offTrackDuration > 2000L && (now - lastVoiceAlertTime) > 2500L) {
                    MyScreenReader.speak("Going right! Steer left!")
                    lastVoiceAlertTime = now
                }
            } else {
                isOffTrackLeft = false
                isOffTrackRight = false
                offTrackDuration = 0L
            }
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF020617)).myScreenReaderGestures(onDirectDoubleTap = onBack).padding(24.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("CAR RACING", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = when {
                        isOffTrackLeft -> "⚠️ BEEP LEFT EAR! (Steer Right)"
                        isOffTrackRight -> "⚠️ BEEP RIGHT EAR! (Steer Left)"
                        else -> "🔊 ENGINE CENTERED (On Track)"
                    },
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isOffTrackLeft || isOffTrackRight) Color(0xFFEF4444) else Color(0xFF10B981)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("Distance: $distanceTravelled m", fontSize = 18.sp, color = Color(0xFF94A3B8))
            }
            Text("Tilt phone left/right to stay centered. Double tap to return to menu.", fontSize = 13.sp, color = Color(0xFF64748B))
        }
    }
}

// =========================================================================
// 7. MODE 2: BLIND CRICKET SCREEN
// =========================================================================
@Composable
fun CricketScreen(soundManager: SoundManager, onBack: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var wickets by remember { mutableStateOf(0) }
    var ballsBowled by remember { mutableStateOf(0) }
    var ballState by remember { mutableStateOf("IDLE") }
    var deliveryStartTime by remember { mutableStateOf(0L) }
    var ballProgress by remember { mutableStateOf(0f) }

    val scope = rememberCoroutineScope()

    fun speakCurrentScore() {
        MyScreenReader.speak("Score is $score runs for $wickets wickets after $ballsBowled balls.")
    }

    fun startNewDelivery() {
        ballState = "BOWLING"
        deliveryStartTime = System.currentTimeMillis()
        MyScreenReader.speak("Bowler coming. Tap when ball is close.")
    }

    // Runs after every ball (hit or bowled). Lives in its own coroutine so it
    // isn't cancelled when ballState changes.
    fun afterDelivery() {
        scope.launch {
            delay(1200)
            speakCurrentScore()
            delay(2500)
            if (wickets < 10) startNewDelivery()
        }
    }

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.onScreenChanged("Blind Cricket", "Bowler coming. Tap when ball is close. 3-second approach. Double tap in the final 0.3s.")
        delay(1500)
        startNewDelivery()
    }

    LaunchedEffect(ballState) {
        if (ballState == "BOWLING") {
            while (ballState == "BOWLING") {
                val elapsed = System.currentTimeMillis() - deliveryStartTime
                ballProgress = (elapsed / 3000f).coerceIn(0f, 1f)
                soundManager.playBallApproach(ballProgress)

                if (elapsed >= 3000L) {
                    ballState = "BOWLED"
                    wickets++
                    ballsBowled++
                    soundManager.playStumpsOut()
                    MyScreenReader.speak("Bowled! Out!")
                    afterDelivery()
                    break
                }
                delay(100)
            }
        }
    }

    fun onSwingBat() {
        if (ballState != "BOWLING") return
        val elapsed = System.currentTimeMillis() - deliveryStartTime

        if (elapsed in 2700L..3000L) {
            ballState = "HIT"
            val runs = if (elapsed in 2850L..2980L) 6 else 4
            score += runs
            ballsBowled++
            soundManager.playBatHit("perfect")
            MyScreenReader.speak("Hit! $runs runs!")
        } else if (elapsed in 2400L..2699L) {
            ballState = "HIT"
            score += 1
            ballsBowled++
            soundManager.playBatHit("early")
            MyScreenReader.speak("Hit! 1 run.")
        } else {
            ballState = "BOWLED"
            wickets++
            ballsBowled++
            soundManager.playStumpsOut()
            MyScreenReader.speak("Bowled! Out!")
        }

        afterDelivery()
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0F172A)).myScreenReaderGestures(onDirectDoubleTap = { onSwingBat() }).padding(24.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("BLIND CRICKET", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("$score / $wickets", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                Text("Balls: $ballsBowled", fontSize = 18.sp, color = Color(0xFF94A3B8))
                Spacer(modifier = Modifier.height(16.dp))
                Text("Ball Distance: ${((1f - ballProgress) * 22).toInt()} yards", fontSize = 20.sp, color = Color(0xFFFBBF24))
            }
            Text("Double Tap anywhere to swing when the sound peaks. Back gesture returns to menu. Hold 1s for Help.", fontSize = 13.sp, color = Color(0xFF64748B))
        }
    }
}

// =========================================================================
// 8. MODE 3: 3D GUN FIGHT SCREEN
// =========================================================================
@Composable
fun GunFightScreen(soundManager: SoundManager, playerAzimuth: Float, onBack: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var enemyAngle by remember { mutableStateOf(90f) }
    var isTargetLocked by remember { mutableStateOf(false) }
    var lastWhisperTime by remember { mutableStateOf(0L) }

    // Always holds the latest compass heading, without restarting the loop on every sensor tick
    val azimuth by rememberUpdatedState(playerAzimuth)

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.onScreenChanged("Gun Fight Arena", "Enemies walk around you in 360 degrees. Rotate phone to aim. Tap anywhere to shoot.")
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            val now = System.currentTimeMillis()
            var relativeAngle = (enemyAngle - azimuth) % 360f
            if (relativeAngle > 180f) relativeAngle -= 360f
            if (relativeAngle < -180f) relativeAngle += 360f

            val pan = (relativeAngle / 90f).coerceIn(-1.0f, 1.0f)
            soundManager.playFootsteps(pan = pan, distance = 4f)

            if (now - lastWhisperTime > 2500L) {
                when {
                    abs(relativeAngle) > 135f -> MyScreenReader.speak("Enemy behind")
                    relativeAngle < -45f -> MyScreenReader.speak("Enemy left")
                    relativeAngle > 45f -> MyScreenReader.speak("Enemy right")
                }
                lastWhisperTime = now
            }

            if (abs(relativeAngle) <= 12f) {
                if (!isTargetLocked) {
                    isTargetLocked = true
                    soundManager.playTargetLockTone()
                    MyScreenReader.speak("Target locked")
                }
            } else {
                isTargetLocked = false
            }
        }
    }

    fun shoot() {
        soundManager.playGunshot(hit = isTargetLocked)
        if (isTargetLocked) {
            score++
            MyScreenReader.speak("Enemy eliminated! Score: $score")
            enemyAngle = (azimuth + (-120..120).random()).let { (it + 360) % 360 }
            isTargetLocked = false
        } else {
            MyScreenReader.speak("Missed!")
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF030712)).myScreenReaderGestures(onDirectDoubleTap = { shoot() }).padding(24.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("3D GUN FIGHT", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isTargetLocked) "🎯 TARGET LOCKED!" else "🎧 TRACKING FOOTSTEPS...",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isTargetLocked) Color(0xFFEF4444) else Color(0xFF38BDF8)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("Enemies Eliminated: $score", fontSize = 18.sp, color = Color.White)
            }
            Text("Rotate phone to track 3D footsteps. Double tap to fire when locked. Back gesture returns to menu.", fontSize = 13.sp, color = Color(0xFF64748B))
        }
    }
}

// =========================================================================
// 9. MODE 4: MULTIPLAYER SCREEN
// =========================================================================
@Composable
fun MultiplayerScreen(soundManager: SoundManager, isPushToTalkActive: Boolean, onBack: () -> Unit) {
    var roomCode by remember { mutableStateOf("5689") }
    var enteredCode by remember { mutableStateOf("") }
    var inRoom by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.onScreenChanged("Multiplayer Lobby", "Your room code is 5 6 8 9. Share with friends. Or use the dialpad to join another room.")
    }

    LaunchedEffect(inRoom) {
        if (inRoom) {
            val peerActions = listOf("Amit fired", "Rahul crashed", "Vikram scored 4 runs", "Priya locked on target")
            while (true) {
                delay(6000)
                MyScreenReader.speak(peerActions.random())
            }
        }
    }

    // Double tap is a no-op here so fast dialpad taps never exit the lobby; use the back gesture to leave.
    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF0B132B)).myScreenReaderGestures(onDirectDoubleTap = { }).padding(20.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("MULTIPLAYER ARENA", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)

            if (!inRoom) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Your Room: 5 6 8 9", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text("Entered: ${if (enteredCode.isEmpty()) "____" else enteredCode}", fontSize = 20.sp, color = Color.White)
                    Spacer(modifier = Modifier.height(16.dp))

                    val keypad = listOf(
                        listOf("1", "2", "3"),
                        listOf("4", "5", "6"),
                        listOf("7", "8", "9"),
                        listOf("Clear", "0", "Join")
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        keypad.forEach { row ->
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                row.forEach { key ->
                                    Box(
                                        modifier = Modifier.size(72.dp)
                                            .background(Color(0xFF1E293B), RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFF334155), RoundedCornerShape(8.dp))
                                            .clickable {
                                                MyScreenReader.speak(key)
                                                if (key == "Join") {
                                                    inRoom = true
                                                    MyScreenReader.speak("Joined room. Connecting voice chat.")
                                                } else if (key == "Clear") {
                                                    enteredCode = ""
                                                } else if (enteredCode.length < 4) {
                                                    enteredCode += key
                                                }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(key, color = Color.White, fontSize = 20.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Connected in Room $roomCode", fontSize = 20.sp, color = Color(0xFF10B981))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = if (isPushToTalkActive) "🎙️ PUSH TO TALK ACTIVE" else "Hold Volume Down to Speak",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isPushToTalkActive) Color(0xFFF43F5E) else Color(0xFF94A3B8)
                    )
                }
            }
            Text("Hold Volume Down for WebRTC Voice Chat · Friends actions spoken live · Back gesture leaves", fontSize = 12.sp, color = Color(0xFF64748B))
        }
    }
}
