package com.blindarena

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// =========================================================================
// ARCADE RUSH: a fast dodging game, all by sound.
//
//  - The car drives forward BY ITSELF. It gets faster every level. You only choose the lane:
//    touch the LEFT half of the screen to move one lane left, the RIGHT half to move one lane right.
//    (Keep your finger down and the car keeps moving every moment.)
//  - Cars, trucks, autos and fast bikes come at you in the three lanes. Their sound grows louder and sits
//    left, right or in the middle, so move AWAY from the side you hear them on.
//    Fast beeps and a horn mean a vehicle is coming in YOUR lane.
//  - A ringing bell is a bonus: steer INTO it. It gives points and brings back a life.
//  - Three lives. A crash slows the car and clears the road for a moment.
//  - Later levels add roadside noises and rain to confuse your ears.
//
// Time based on purpose: every wave of traffic is placed so that there is always a free lane you can reach in time.
// No new sound files are used.
// =========================================================================

class RushGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    companion object {
        const val START_LIVES = 3
        const val MAX_LIVES = 3
        const val GAME_OVER_SECONDS = 3f
        const val LEVEL_SECONDS = 25f
        const val MAX_LEVEL = 12
        const val START_SPEED = 15f
        const val SPEED_PER_LEVEL = 2.5f
        const val TOP_SPEED = 46f
        const val AMBIENCE_VOLUME = 0.12f
        const val RAIN_VOLUME = 0.22f
        const val RAIN_FROM_LEVEL = 7
        const val DECOY_FROM_LEVEL = 4
        const val HORN_ETA = 2.3f
        const val WARN_ETA = 1.9f
        const val GRACE_SECONDS = 3f
        const val MIN_GAP = 1.1f
        const val POINTS_PER_PASS = 50
        const val POINTS_PER_BELL = 300
        const val PAN_PER_LANE = 0.5f
        const val MAX_VEHICLES = 12
    }

    private enum class Kind { CAR, TRUCK, AUTO, BIKE, BELL }

    private class Vehicle(val kind: Kind, val lane: Int, var eta: Float, val hear: Float) {
        var stream = 0
        var horned = false
        var bellTimer = 0f
    }

    private val steering = LaneSteering(sound)
    private val engine = EngineSound(sound)

    var lives: Int = START_LIVES
        private set
    var level: Int = 1
        private set
    var distance: Float = 0f
        private set
    private var passes = 0
    private var bells = 0
    private var speed = START_SPEED

    val score: Int
        get() = (distance / 10f).toInt() + passes * POINTS_PER_PASS + bells * POINTS_PER_BELL

    override val title: String
        get() = "ARCADE RUSH"
    override val line1: String
        get() = "Level $level   Lives $lives"
    override val line2: String
        get() = "Score $score   ${distance.toInt()} m"
    override val usesLaneTouch: Boolean
        get() = true

    private val vehicles = ArrayList<Vehicle>()
    private var clock = 0f
    private var introLeft = 0f
    private var scheduling = false
    private var nextArrival = 0f
    private var prevArrival = -10f
    private var prevFree = intArrayOf(0, 1, 2)
    private var levelClock = 0f
    private var bellCountdown = 22f
    private var decoyTimer = 6f
    private var warnTimer = 0f
    private var ambienceStream = 0
    private var rainStream = 0
    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overNotified = false
    private var newRecord = false

    init {
        MyScreenReader.currentHelpContext = "Touch the left half of the screen to move left, the right half to move right. Fast beeps: a car is in your lane. A ringing bell: steer into it."
        val intro = "Arcade rush. " + Records.rushNote() + Daily.hint(Daily.RUSH_LEVEL, Daily.RUSH_BELLS, Daily.RUSH_PASSES) +
            "Use headphones. The car drives by itself. Touch the left half of the screen to move left, " +
            "the right half to move right. Move away from the side you hear a car. " +
            "Fast beeps mean a car is in your lane. A ringing bell is a bonus: steer into it. Three lives. Touch to start."
        MyScreenReader.speak(intro)
        introLeft = intro.length / (13f * MyScreenReader.speechRate) + 0.4f
    }

    override fun shutdown() {
        // Leaving in the middle of a run still keeps the score
        if (!isOver && score > 0) {
            isOver = true
            Records.rushFinished(score)
        }
        clearVehicles()
        sound.stopStream(ambienceStream)
        ambienceStream = 0
        sound.stopStream(rainStream)
        rainStream = 0
        engine.stop()
    }

    private fun clearVehicles() {
        for (v in vehicles) sound.stopStream(v.stream)
        vehicles.clear()
    }

    // ---------------------------------------------------------------- main loop

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                if (newRecord) Records.playNewRecord(sound)
                onOver(overText, false)
            }
            return
        }

        // Big sound files may still be loading when the game starts, so keep trying until the loops play
        if (ambienceStream == 0) ambienceStream = sound.playLoop("road_ambience", 0f, AMBIENCE_VOLUME, 1.0f)

        clock += dt
        if (introLeft > 1.2f && (controls.leftPressQueued || controls.rightPressQueued)) {
            // the player is ready: stop the explaining and go
            introLeft = 1.2f
            MyScreenReader.speak("Go.")
        }
        steering.update(dt, controls)
        updateSpeed(dt)
        distance += speed * dt
        engine.update(speed / TOP_SPEED)

        if (introLeft > 0f) {
            introLeft -= dt
            return
        }
        updateLevel(dt)
        if (!scheduling) {
            scheduling = true
            nextArrival = clock + hearTime()
        }

        scheduleWaves()
        updateVehicles(dt)
        if (isOver) return
        updateWarning(dt)
        updateAtmosphere(dt)
    }

    private fun targetSpeed(): Float = min(TOP_SPEED, START_SPEED + SPEED_PER_LEVEL * (level - 1))

    private fun updateSpeed(dt: Float) {
        val target = targetSpeed()
        speed = if (speed < target) min(target, speed + 6f * dt) else max(target, speed - 20f * dt)
    }

    /** Seconds between the first sound of a vehicle and the moment it reaches you. Shorter at higher levels. */
    private fun hearTime(): Float = max(3.0f, 4.4f - 0.12f * (level - 1))

    private fun updateLevel(dt: Float) {
        if (level >= MAX_LEVEL) return
        levelClock += dt
        if (levelClock < LEVEL_SECONDS) return
        levelClock -= LEVEL_SECONDS
        level += 1
        sound.playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.2f)
        sound.vibrate(60)
        val dailyDone = Daily.report(Daily.RUSH_LEVEL, level)
        val extra = when (level) {
            DECOY_FROM_LEVEL -> " Noises from the roadside start. They are not cars."
            RAIN_FROM_LEVEL -> " It is raining. Listen carefully."
            MAX_LEVEL -> " Top speed."
            else -> ""
        }
        MyScreenReader.speak("Level $level.$extra", flush = false)
        if (dailyDone) Daily.announce(sound)
    }

    // ---------------------------------------------------------------- traffic waves

    /** Plan waves a little ahead of time. Each wave arrives at one moment; the vehicles stay silent until it is time to hear them. */
    private fun scheduleWaves() {
        var guard = 0
        while (nextArrival <= clock + hearTime() + 0.25f && guard < 4) {
            guard++
            createWave(nextArrival)
            val lo = max(MIN_GAP, 2.4f - 0.13f * (level - 1))
            nextArrival += lo + Random.nextFloat() * 0.9f
        }
    }

    private fun pickKind(): Kind {
        var total = 5
        if (level >= 2) total += 2
        if (level >= 3) total += 2
        if (level >= 4) total += 2
        var r = Random.nextInt(total)
        if (r < 5) return Kind.CAR
        r -= 5
        if (level >= 2) {
            if (r < 2) return Kind.TRUCK
            r -= 2
        }
        if (level >= 3) {
            if (r < 2) return Kind.AUTO
            r -= 2
        }
        return Kind.BIKE
    }

    /** From every lane you might be in after the last wave, you must be able to reach a free lane of this wave in the time between them. */
    private fun reachable(from: IntArray, free: List<Int>, gap: Float): Boolean {
        val shift = if (gap >= 1.6f) 2 else if (gap >= 1.0f) 1 else 0
        for (p in from) {
            var ok = false
            for (n in free) if (abs(p - n) <= shift) ok = true
            if (!ok) return false
        }
        return true
    }

    private fun createWave(arrival: Float) {
        if (vehicles.size >= MAX_VEHICLES - 2) return
        val gap = arrival - prevArrival
        val eta = max(0.05f, arrival - clock)
        val hear = hearTime()

        val bellDue = level >= 2 && bellCountdown <= 0f
        val blocked = ArrayList<Int>()
        var bellLane = -1
        if (bellDue) {
            bellLane = Random.nextInt(ROAD_LANES)
            if (Random.nextFloat() < 0.5f) {
                val others = ArrayList<Int>()
                for (l in 0 until ROAD_LANES) if (l != bellLane) others.add(l)
                blocked.add(others[Random.nextInt(others.size)])
            }
            if (!reachable(prevFree, freeOf(blocked), gap)) { blocked.clear() }
            bellCountdown = if (lives < MAX_LIVES) 12f + Random.nextFloat() * 6f else 22f + Random.nextFloat() * 10f
        } else {
            val two = level >= 2 && Random.nextFloat() < min(0.65f, 0.12f * (level - 1))
            val count = if (two) 2 else 1
            var found = false
            for (attempt in 0 until 14) {
                val pick = ArrayList<Int>()
                while (pick.size < count) {
                    val l = Random.nextInt(ROAD_LANES)
                    if (l !in pick) pick.add(l)
                }
                if (reachable(prevFree, freeOf(pick), gap)) {
                    blocked.addAll(pick)
                    found = true
                    break
                }
            }
            if (!found) blocked.add(if (Random.nextBoolean()) 0 else ROAD_LANES - 1)   // the middle lane is always reachable
        }

        for (lane in blocked) {
            val kind = pickKind()
            val h = when (kind) {
                Kind.TRUCK -> hear * 1.1f
                Kind.BIKE -> hear * 0.8f
                else -> hear
            }
            vehicles.add(Vehicle(kind, lane, eta, h))
        }
        if (bellLane >= 0) vehicles.add(Vehicle(Kind.BELL, bellLane, eta, hear * 0.9f))
        prevFree = freeOf(blocked).toIntArray()
        prevArrival = arrival
        if (!bellDue) bellCountdown -= gap
    }

    private fun freeOf(blocked: List<Int>): List<Int> {
        val out = ArrayList<Int>()
        for (l in 0 until ROAD_LANES) if (l !in blocked) out.add(l)
        return out
    }

    // ---------------------------------------------------------------- vehicles

    private fun updateVehicles(dt: Float) {
        var crashed = false
        val iterator = vehicles.iterator()
        while (iterator.hasNext()) {
            val v = iterator.next()
            v.eta -= dt
            if (v.eta <= 0f) {
                sound.stopStream(v.stream)
                iterator.remove()
                if (v.kind == Kind.BELL) {
                    if (v.lane == steering.lane) collectBell()
                } else if (v.lane == steering.lane) {
                    crashed = true
                } else {
                    passed(v)
                }
                continue
            }
            if (v.eta > v.hear) continue      // not audible yet
            if (v.kind == Kind.BELL) updateBell(v, dt) else updateVehicleAudio(v)
        }
        if (crashed) onCrash()
    }

    private fun panOf(lane: Int): Float = ((lane - steering.lane) * PAN_PER_LANE).coerceIn(-1f, 1f)

    private fun updateVehicleAudio(v: Vehicle) {
        val c = (1f - v.eta / v.hear).coerceIn(0f, 1f)
        val volume = 0.15f + 0.85f * c * c
        val pan = panOf(v.lane)
        val tag: String
        val rate: Float
        when (v.kind) {
            Kind.TRUCK -> { tag = "car_hum"; rate = 0.6f + 0.35f * c }
            Kind.AUTO -> { tag = "rickshaw_loop"; rate = 0.9f + 0.4f * c }
            Kind.BIKE -> { tag = "car_hum"; rate = 1.3f + 0.6f * c }
            else -> { tag = "car_hum"; rate = 0.85f + 0.55f * c }
        }
        if (v.stream == 0) v.stream = sound.playLoop(tag, pan, volume, rate) else sound.updateStream(v.stream, pan, volume, rate)

        if (!v.horned && v.lane == steering.lane && v.eta < HORN_ETA) {
            v.horned = true
            when (v.kind) {
                Kind.TRUCK -> sound.playSpatial("horn_truck", pan = 0f, volume = 1.0f)
                Kind.AUTO -> sound.playSpatial("horn_auto", pan = 0f, volume = 1.0f)
                Kind.BIKE -> sound.playSpatial("horn", pan = 0f, volume = 0.9f, rate = 1.5f)
                else -> sound.playSpatial("horn", pan = 0f, volume = 1.0f)
            }
        }
    }

    /** A ringing bell: rings faster and louder as it comes closer. */
    private fun updateBell(v: Vehicle, dt: Float) {
        v.bellTimer -= dt
        if (v.bellTimer > 0f) return
        val c = (1f - v.eta / v.hear).coerceIn(0f, 1f)
        sound.playSpatial("bicycle_bell", pan = panOf(v.lane), volume = 0.4f + 0.55f * c, rate = 1.0f + 0.25f * c)
        v.bellTimer = 0.5f + 0.7f * (v.eta / v.hear)
    }

    private fun passed(v: Vehicle) {
        passes += 1
        val dailyDone = Daily.report(Daily.RUSH_PASSES, passes)
        val gapLanes = abs(v.lane - steering.lane)
        val rate = if (v.kind == Kind.BIKE) 1.3f else 1.0f
        sound.playSpatial("car_pass", pan = panOf(v.lane), volume = if (gapLanes == 1) 1.0f else 0.7f, rate = rate)
        if (dailyDone) Daily.announce(sound)
    }

    private fun collectBell() {
        bells += 1
        val dailyDone = Daily.report(Daily.RUSH_BELLS, bells)
        sound.playSpatial("ui_select", pan = 0f, volume = 1.0f)
        sound.playSpatial("lock_tone", pan = 0f, volume = 0.8f, rate = 1.6f)
        if (lives < MAX_LIVES) {
            lives += 1
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("Bonus! A life is back. You have $lives $word.", flush = false)
        } else {
            MyScreenReader.speak("Bonus!", flush = false)
        }
        if (dailyDone) Daily.announce(sound)
    }

    // Like a parking sensor: while a vehicle is coming in YOUR lane you hear soft beeps that get faster and higher as it nears
    private fun updateWarning(dt: Float) {
        var nearest = Float.MAX_VALUE
        for (v in vehicles) {
            if (v.kind != Kind.BELL && v.lane == steering.lane && v.eta <= v.hear && v.eta < nearest) nearest = v.eta
        }
        if (nearest >= WARN_ETA) {
            warnTimer = 0f
            return
        }
        warnTimer -= dt
        if (warnTimer <= 0f) {
            val c = (1f - nearest / WARN_ETA).coerceIn(0f, 1f)
            sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.45f * c, rate = 1.0f + 0.7f * c)
            warnTimer = 0.10f + 0.35f * (1f - c)
        }
    }

    // ---------------------------------------------------------------- crash and the end

    private fun onCrash() {
        sound.playSpatial("crash", pan = 0f, volume = 1.0f)
        sound.vibrate(300)
        lives -= 1
        clearVehicles()
        speed = 6f
        prevFree = intArrayOf(0, 1, 2)
        prevArrival = clock
        nextArrival = clock + GRACE_SECONDS + hearTime()
        if (lives <= 0) {
            endGame()
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("Crash! $lives $word left.")
        }
    }

    private fun endGame() {
        isOver = true
        overTimer = GAME_OVER_SECONDS
        val s = score
        val result = Records.rushFinished(s)
        newRecord = result.newRecord
        overText = "Game over. Score $s. You reached level $level and drove ${distance.toInt()} meters." + result.text
        engine.stop()
        clearVehicles()
        sound.stopStream(ambienceStream)
        ambienceStream = 0
        sound.stopStream(rainStream)
        rainStream = 0
        // Police arrive after the last crash (the recording starts faint and grows by itself)
        sound.playSpatial("siren", pan = 0f, volume = 0.35f)
    }

    // ---------------------------------------------------------------- distractions

    private fun updateAtmosphere(dt: Float) {
        if (level >= RAIN_FROM_LEVEL) {
            if (rainStream == 0) rainStream = sound.playLoop("rain_loop", 0f, RAIN_VOLUME, 1.0f)
        }
        if (level >= DECOY_FROM_LEVEL) {
            decoyTimer -= dt
            if (decoyTimer <= 0f) {
                decoyTimer = 5f + Random.nextFloat() * 5f
                val tag = when (Random.nextInt(4)) {
                    0 -> "dog_bark"
                    1 -> "cow_moo"
                    2 -> "crowd_cheer_short"
                    else -> "owl_hoot"
                }
                val pan = (Random.nextFloat() * 2f - 1f) * 0.9f
                sound.playSpatial(tag, pan = pan, volume = 0.3f + 0.2f * Random.nextFloat())
            }
        }
    }

    // ---------------------------------------------------------------- hooks for the tests

    internal fun dbgLane(): Int = steering.lane
    internal fun dbgLives(): Int = lives
    internal fun dbgLevel(): Int = level
    internal fun dbgScore(): Int = score
    internal fun dbgSpeed(): Float = speed
    internal fun dbgClock(): Float = clock
    internal fun dbgIsOver(): Boolean = isOver
    internal fun dbgBells(): Int = bells
    internal fun dbgPasses(): Int = passes
    /** Vehicles on the way: [lane, seconds until it reaches you, kind (0 car, 1 truck, 2 auto, 3 bike, 4 bell), 1 if you can already hear it]. */
    internal fun dbgVehicles(): List<FloatArray> {
        val out = ArrayList<FloatArray>()
        for (v in vehicles) out.add(floatArrayOf(v.lane.toFloat(), v.eta, v.kind.ordinal.toFloat(), if (v.eta <= v.hear) 1f else 0f))
        return out
    }
    internal fun dbgIntroLeft(): Float = introLeft
    internal fun dbgHear(): Float = hearTime()
}
