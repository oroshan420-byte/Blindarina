package com.blindarena

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// =========================================================================
// RECORDS AND DAILY CHALLENGE SCREEN (main menu, Mode 5)
// Swipe right or left: every game tells its best results, the first entry is today's challenge.
// Double tap repeats the entry. The last entry goes back to the main menu.
// =========================================================================

/** The entries of the records screen: the label, what is said after it, and what a double tap says. */
fun recordsItems(onMenu: () -> Unit): List<MyScreenReader.FocusItem> {
    val items = ArrayList<MyScreenReader.FocusItem>()
    val lines = Records.allLines()
    for (i in lines.indices) {
        val label = lines[i].first
        val line = lines[i].second
        items.add(MyScreenReader.FocusItem("rec_$i", label, line, "") { MyScreenReader.speak("$label. $line") })
    }
    items.add(MyScreenReader.FocusItem("rec_menu", "Main menu", "button", "") { onMenu() })
    return items
}

@Composable
fun RecordsScreen(onMenu: () -> Unit) {
    val lines = Records.allLines()

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        for (item in recordsItems(onMenu)) {
            MyScreenReader.registerItem(item)
        }
        // Nothing focused yet: the first swipe reads the first entry and a stray double tap does nothing
        MyScreenReader.currentFocusIndex.value = -1
        MyScreenReader.onScreenChanged(
            "Records and daily challenge",
            "Swipe right to hear today's challenge and your best result in every game. Double tap repeats an entry. The back gesture returns to the menu."
        )
    }

    val focusedIndex = MyScreenReader.currentFocusIndex.value
    val spokenText = MyScreenReader.currentSpokenTextState.value

    Column(
        modifier = Modifier.fillMaxSize().myScreenReaderGestures().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text("RECORDS AND DAILY CHALLENGE", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)

        Box(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF1E293B), RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("Screen Reader: \"$spokenText\"", color = Color(0xFF38BDF8), fontSize = 15.sp)
        }

        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            for (i in lines.indices) {
                val isSelected = focusedIndex == i
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else Color(0xFF334155), RoundedCornerShape(10.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Text(lines[i].first, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(lines[i].second, color = Color(0xFFCBD5E1), fontSize = 13.sp)
                    }
                }
            }
            val menuSelected = focusedIndex == lines.size
            Box(
                modifier = Modifier.fillMaxWidth()
                    .background(if (menuSelected) Color(0xFF2563EB) else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                    .border(if (menuSelected) 3.dp else 1.dp, if (menuSelected) Color.White else Color(0xFF334155), RoundedCornerShape(10.dp))
                    .padding(12.dp)
            ) {
                Text("Main menu", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
        Text("Gestures: Swipe Left/Right · Double Tap Repeat · Hold 1s Help", color = Color(0xFF64748B), fontSize = 12.sp)
    }
}
