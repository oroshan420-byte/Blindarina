package com.blindarena

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// =========================================================================
// MODE 1: ROAD DRIVE
// You drive the car yourself. It stands still until you speed up.
//  - Tap the TOP edge of the screen: next gear (faster).
//  - Tap the BOTTOM edge: previous gear (slower). Two quick taps = brake hard.
//  - Touch and hold the LEFT or RIGHT half of the middle of the screen: change lane.
// Three routes: a jungle road (animals, fallen trees, bends, a bridge), a 70 km long drive to Kalimpong (one finger:
// the further up you slide the faster you go, down to reverse, sideways to steer, lift the finger to stop)
// and a highway.
// =========================================================================

const val ROAD_LANES = 3
const val LANE_HOLD_REPEAT_SECONDS = 0.45f

/** Finger state, written by the touch handler and read by the game loop. */
class CarControls {
    var leftHeld = false
    var rightHeld = false
    var leftPressQueued = false
    var rightPressQueued = false
    var gearUpQueued = false
    var gearDownQueued = false

    // the one-finger stick used on the long drive: how far the finger is from where it first touched, -1 to 1
    var stickActive = false
    var stickX = 0f
    var stickY = 0f       // up is positive
    var stickBoost = 0f   // 0 to 1: how fast the first swipe was
    var gpsQueued = false // a quick tap with the one-finger stick: ask the GPS
}

/** Every route is a game with a title, two lines for the screen, and a tick. */
interface DriveGame {
    val title: String
    val line1: String
    val line2: String
    val usesStick: Boolean
        get() = false
    fun tick(dt: Float, controls: CarControls)
    fun shutdown()
}

/** Engine sound: idle, low and high recordings play together and fade into each other as the speed changes. */
class EngineSound(private val sound: SoundManager) {

    companion object {
        const val ENGINE_VOLUME = 0.6f
    }

    private var idleStream = 0
    private var lowStream = 0
    private var highStream = 0

    /** fraction: 0 = standing still, 1 = top speed. Also starts the streams if they are not playing (files may still be loading). */
    fun update(fraction: Float) {
        val f = fraction.coerceIn(0f, 1f)
        val idleVolume = (1f - f / 0.22f).coerceIn(0f, 1f)
        val lowVolume = if (f < 0.22f) f / 0.22f else (1f - (f - 0.45f) / 0.35f).coerceIn(0f, 1f)
        val highVolume = ((f - 0.40f) / 0.35f).coerceIn(0f, 1f)

        idleStream = drive(idleStream, "eng_idle", idleVolume, (0.9f + 1.2f * f).coerceAtMost(1.2f))
        lowStream = drive(lowStream, "eng_low", lowVolume, (0.72f + 0.9f * f).coerceAtMost(1.3f))
        highStream = drive(highStream, "eng_high", highVolume, 0.8f + 0.6f * f)
    }

    private fun drive(stream: Int, tag: String, volume: Float, rate: Float): Int {
        val v = volume * ENGINE_VOLUME
        if (stream == 0) return sound.playLoop(tag, 0f, v, rate)
        sound.updateStream(stream, 0f, v, rate)
        return stream
    }

    fun stop() {
        sound.stopStream(idleStream)
        sound.stopStream(lowStream)
        sound.stopStream(highStream)
        idleStream = 0
        lowStream = 0
        highStream = 0
    }
}

/** Gears, speed, engine sound. The car never drives by itself: speed follows the gear you chose. */
class Drivetrain(private val sound: SoundManager) {

    companion object {
        const val MAX_GEAR = 4
        const val TOP_SPEED = 36f
        const val ACCEL = 5f
        const val BRAKE = 12f
        val GEAR_SPEEDS = floatArrayOf(0f, 9f, 18f, 27f, 36f)
    }

    var gear: Int = 0
        private set
    var speed: Float = 0f
        private set

    val kmh: Int
        get() = (speed * 3.6f).toInt()

    private val engine = EngineSound(sound)
    private var clock = 0f
    private var lastDownAt = -10f
    private var lastAccelSoundAt = -10f

    fun stopEngine() {
        engine.stop()
    }

    fun reset() {
        gear = 0
        speed = 0f
        lastDownAt = -10f
        lastAccelSoundAt = -10f
        applyEngine()
    }

    fun gearUp() {
        if (gear >= MAX_GEAR) {
            sound.playSpatial("ui_tick", pan = 0f, volume = 0.6f)
            return
        }
        gear += 1
        sound.playSpatial("gear_shift", pan = 0f, volume = 0.9f)
        if (clock - lastAccelSoundAt > 2.5f) {
            lastAccelSoundAt = clock
            sound.playSpatial("car_accel", pan = 0f, volume = 0.5f)
        }
    }

    fun gearDown() {
        if (gear == 0) {
            sound.playSpatial("ui_tick", pan = 0f, volume = 0.6f)
            return
        }
        val quick = clock - lastDownAt < 0.7f
        lastDownAt = clock
        if (quick) {
            gear = 0
            sound.playSpatial("brake_screech", pan = 0f, volume = 1.0f)
        } else {
            gear -= 1
            sound.playSpatial("gear_shift", pan = 0f, volume = 0.8f, rate = 0.9f)
            if (gear == 0) sound.playSpatial("brake_screech", pan = 0f, volume = 0.6f)
        }
    }

    /** A hard bump takes one gear off. */
    fun shock() {
        if (gear > 1) gear -= 1
    }

    fun crashStop() {
        gear = 0
        speed = 0f
    }

    fun update(dt: Float) {
        clock += dt
        val target = GEAR_SPEEDS[gear]
        speed = if (speed < target) min(target, speed + ACCEL * dt) else max(target, speed - BRAKE * dt)
        applyEngine()
    }

    private fun applyEngine() {
        engine.update(speed / TOP_SPEED)
    }
}

/** Which of the three lanes you are in, and the lane tones. */
class LaneSteering(private val sound: SoundManager) {

    var lane: Int = 1
        private set

    private var holdTimer = 0f

    fun reset() {
        lane = 1
        holdTimer = 0f
    }

    fun forceLane(target: Int) {
        lane = target
    }

    fun update(dt: Float, controls: CarControls) {
        if (holdTimer > 0f) holdTimer -= dt

        val freshLeft = controls.leftPressQueued
        val freshRight = controls.rightPressQueued
        controls.leftPressQueued = false
        controls.rightPressQueued = false

        var dir = 0
        if (freshLeft != freshRight) {
            // A new tap always moves one lane straight away
            dir = if (freshLeft) -1 else 1
        } else if (holdTimer <= 0f && controls.leftHeld != controls.rightHeld) {
            // Holding repeats the move
            dir = if (controls.leftHeld) -1 else 1
        }
        if (dir == 0) return

        holdTimer = LANE_HOLD_REPEAT_SECONDS
        move(dir)
    }

    private fun move(dir: Int) {
        val target = lane + dir
        if (target < 0 || target >= ROAD_LANES) {
            // Road edge: a short tyre scrape on that side
            sound.playSpatial("tire_screech", pan = dir * 0.9f, volume = 0.6f)
            sound.vibrate(30)
            return
        }
        lane = target
        val rate = when (lane) {
            0 -> 0.8f
            1 -> 1.0f
            else -> 1.25f
        }
        // Lane tone: low and left, middle and centre, high and right
        sound.playSpatial("beep", pan = (lane - 1) * 0.8f, volume = 0.7f, rate = rate)
    }
}

/** Gear taps are read here for every route. */
fun handleGears(controls: CarControls, drive: Drivetrain) {
    if (controls.gearUpQueued) {
        controls.gearUpQueued = false
        drive.gearUp()
    }
    if (controls.gearDownQueued) {
        controls.gearDownQueued = false
        drive.gearDown()
    }
}

// ---------------------------------------------------------------------------------------------
// HIGHWAY: oncoming cars in three lanes. Their sound moves from far/quiet to near/loud and sits
// left, centre or right. A horn and fast beeps mean a car is coming in YOUR lane.
// ---------------------------------------------------------------------------------------------

class CarGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    companion object {
        const val SPAWN_DISTANCE = 120f
        const val HIT_DISTANCE = 3f
        const val HORN_DISTANCE = 45f
        const val INTRO_SECONDS = 9f
        const val GAME_OVER_SECONDS = 3.0f
        const val START_LIVES = 3
        const val LEVEL_LENGTH_M = 600f
        const val MAX_CARS = 4
        const val MAX_LEVEL = 10
        const val AMBIENCE_VOLUME = 0.12f
        const val WARN_DISTANCE = 70f
        const val ONCOMING_SPEED = 18f
    }

    private class Car(val lane: Int, var distance: Float) {
        var streamId: Int = 0
        var horned: Boolean = false
    }

    private val drive = Drivetrain(sound)
    private val steering = LaneSteering(sound)

    var lives: Int = START_LIVES
        private set
    var level: Int = 1
        private set
    var distance: Float = 0f
        private set

    override val title: String
        get() = "HIGHWAY"
    override val line1: String
        get() = "Gear ${drive.gear}   ${drive.kmh} km/h"
    override val line2: String
        get() = "Lives $lives   Level $level   ${distance.toInt()} m"

    private val cars = mutableListOf<Car>()
    private var spawnTimer = 0.5f
    private var introLeft = INTRO_SECONDS
    private var ambienceStream = 0
    private var warnTimer = 0f
    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overNotified = false

    init {
        drive.reset()
        MyScreenReader.currentHelpContext = "Tap the top edge for a faster gear, the bottom edge for a slower gear. Hold the left or right side of the screen to change lane."
        MyScreenReader.speak(
            "Highway. The car is stopped. Tap the top edge of the screen to speed up, the bottom edge to slow down, and twice quickly to brake hard. " +
                "Touch and hold the left or right side to change lane. Fast beeps and a horn mean a car is coming in your lane. " +
                "Do the back gesture twice to leave."
        )
    }

    override fun shutdown() {
        clearCars()
        stopAmbience()
        drive.stopEngine()
    }

    private fun ensureAmbience() {
        if (ambienceStream == 0) {
            ambienceStream = sound.playLoop("road_ambience", 0f, AMBIENCE_VOLUME, 1.0f)
        }
    }

    private fun stopAmbience() {
        sound.stopStream(ambienceStream)
        ambienceStream = 0
    }

    private fun clearCars() {
        for (car in cars) {
            sound.stopStream(car.streamId)
        }
        cars.clear()
    }

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                onOver(overText, false)
            }
            return
        }

        // Big sound files may still be loading when the game starts, so keep trying until the loops play
        ensureAmbience()

        handleGears(controls, drive)
        steering.update(dt, controls)
        drive.update(dt)
        distance += drive.speed * dt
        updateLevel()

        if (introLeft > 0f) {
            introLeft -= dt
            return
        }

        val closing = drive.speed + ONCOMING_SPEED
        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            trySpawn(closing)
            spawnTimer = (2.4f - 0.14f * level).coerceAtLeast(1.0f) * (0.8f + Random.nextFloat() * 0.4f)
        }

        updateCars(dt, closing)
        updateWarning(dt)
    }

    private fun updateLevel() {
        val newLevel = (1 + (distance / LEVEL_LENGTH_M).toInt()).coerceAtMost(MAX_LEVEL)
        if (newLevel > level) {
            level = newLevel
            sound.playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.2f)
            MyScreenReader.speak("Level $level. More traffic.", flush = false)
        }
    }

    private fun trySpawn(closing: Float) {
        if (cars.size >= MAX_CARS) return

        // Always leave one lane free among cars that arrive close together
        val recentLimit = SPAWN_DISTANCE - closing * 1.2f
        val blockedLanes = HashSet<Int>()
        for (car in cars) {
            if (car.distance > recentLimit) blockedLanes.add(car.lane)
        }
        if (blockedLanes.size >= ROAD_LANES - 1) return

        cars.add(Car(Random.nextInt(ROAD_LANES), SPAWN_DISTANCE))
    }

    private fun updateCars(dt: Float, closing: Float) {
        var crashed = false
        val iterator = cars.iterator()
        while (iterator.hasNext()) {
            val car = iterator.next()
            car.distance -= closing * dt

            if (car.distance <= HIT_DISTANCE) {
                sound.stopStream(car.streamId)
                iterator.remove()
                if (car.lane == steering.lane) {
                    crashed = true
                } else {
                    val pan = ((car.lane - steering.lane) * 0.9f).coerceIn(-1f, 1f)
                    sound.playSpatial("car_pass", pan = pan, volume = 1.0f)
                }
            } else {
                if (!car.horned && car.lane == steering.lane && car.distance < HORN_DISTANCE) {
                    car.horned = true
                    sound.playSpatial("horn", pan = 0f, volume = 1.0f)
                }
                updateCarAudio(car)
            }
        }
        if (crashed) onCrash()
    }

    // Like a parking sensor: while a car is coming in YOUR lane you hear soft beeps that get faster and higher as it nears
    private fun updateWarning(dt: Float) {
        var nearest = Float.MAX_VALUE
        for (car in cars) {
            if (car.lane == steering.lane && car.distance < nearest) nearest = car.distance
        }
        if (nearest >= WARN_DISTANCE) {
            warnTimer = 0f
            return
        }
        warnTimer -= dt
        if (warnTimer <= 0f) {
            val closeness = (1f - nearest / WARN_DISTANCE).coerceIn(0f, 1f)
            sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.45f * closeness, rate = 1.0f + 0.7f * closeness)
            warnTimer = 0.10f + 0.45f * (1f - closeness)
        }
    }

    private fun updateCarAudio(car: Car) {
        val closeness = (1f - car.distance / SPAWN_DISTANCE).coerceIn(0f, 1f)
        val volume = 0.15f + 0.85f * closeness * closeness
        val rate = 0.85f + 0.55f * closeness
        val pan = ((car.lane - steering.lane) * 0.85f).coerceIn(-1f, 1f)
        if (car.streamId == 0) {
            car.streamId = sound.playLoop("car_hum", pan, volume, rate)
        } else {
            sound.updateStream(car.streamId, pan, volume, rate)
        }
    }

    private fun onCrash() {
        sound.playSpatial("crash", pan = 0f, volume = 1.0f)
        sound.vibrate(300)
        lives -= 1
        clearCars()
        drive.crashStop()
        spawnTimer = 3f
        if (lives <= 0) {
            endGame()
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("Crash! $lives $word left. Tap the top edge to drive again.")
        }
    }

    private fun endGame() {
        isOver = true
        overTimer = GAME_OVER_SECONDS
        overText = "Game over. You drove ${distance.toInt()} meters and reached level $level."
        drive.stopEngine()
        stopAmbience()
        // Police arrive after the last crash (the recording starts faint and grows by itself)
        sound.playSpatial("siren", pan = 0f, volume = 0.35f)
    }
}

/** Pick a route, drive it, then choose what to do next. Uses the app's own screen reader for the menus. */
class CarDriveController(
    private val sound: SoundManager,
    private val onExit: () -> Unit
) {
    private enum class Route { JUNGLE, KALIMPONG, HIGHWAY }

    var game by mutableStateOf<DriveGame?>(null)
    var title by mutableStateOf("ROAD DRIVE")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    private var route = Route.JUNGLE
    private var lastChangeMs = 0L

    fun begin() {
        showRoutes()
    }

    fun shutdown() {
        game?.shutdown()
        game = null
    }

    private fun tooSoon(): Boolean = System.currentTimeMillis() - lastChangeMs < 800L

    private fun say(text: String, help: String) {
        MyScreenReader.currentHelpContext = help
        MyScreenReader.speak(text)
    }

    private fun setItems(items: List<MyScreenReader.FocusItem>) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        lastChangeMs = System.currentTimeMillis()
        // Nothing focused yet: the first swipe reads the first option and a stray double tap does nothing
        if (items.isNotEmpty()) MyScreenReader.currentFocusIndex.value = -1
    }

    private fun showRoutes() {
        game = null
        title = "ROAD DRIVE"
        line1 = "Choose a route"
        line2 = "Swipe left or right, double tap to select"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("route_jungle", "Jungle road", "night journey, animals, bends and a bridge", "") { if (!tooSoon()) startRoute(Route.JUNGLE) })
        items.add(MyScreenReader.FocusItem("route_kalimpong", "Long drive to Kalimpong", "70 kilometres to the Mary Scott Home hostel, GPS guided, one finger drive", "") { if (!tooSoon()) startRoute(Route.KALIMPONG) })
        items.add(MyScreenReader.FocusItem("route_highway", "Highway", "fast oncoming traffic, how far can you get", "") { if (!tooSoon()) startRoute(Route.HIGHWAY) })
        setItems(items)
        say(
            "Road drive. You drive the car yourself. Choose a route. Swipe right or left to hear the options, then double tap to select. " +
                "The back gesture returns to the menu.",
            "Swipe to hear the routes, then double tap to select."
        )
    }

    private fun startRoute(r: Route) {
        route = r
        MyScreenReader.clearItems()
        val over: (String, Boolean) -> Unit = { text, won -> onOver(text, won) }
        game = when (r) {
            Route.JUNGLE -> JungleGame(sound, over)
            Route.KALIMPONG -> KalimpongGame(sound, over)
            Route.HIGHWAY -> CarGame(sound, over)
        }
    }

    private fun onOver(text: String, won: Boolean) {
        game?.shutdown()
        game = null
        showEnd(text, won)
    }

    private fun showEnd(text: String, won: Boolean) {
        title = if (won) "YOU MADE IT" else "GAME OVER"
        line1 = text
        line2 = when (route) {
            Route.JUNGLE -> "Jungle road"
            Route.KALIMPONG -> "Long drive to Kalimpong"
            Route.HIGHWAY -> "Highway"
        }
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("drive_again", "Play again", "same route", "") { if (!tooSoon()) startRoute(route) })
        items.add(MyScreenReader.FocusItem("drive_route", "Change route", "button", "") { if (!tooSoon()) showRoutes() })
        items.add(MyScreenReader.FocusItem("drive_menu", "Main menu", "button", "") { if (!tooSoon()) onExit() })
        setItems(items)
        say("$text Swipe to choose Play again, Change route or Main menu.", "Swipe to choose, then double tap.")
    }
}

/**
 * Top edge tap = faster, bottom edge tap = slower. In the middle, touching and holding the left or the right half steers.
 */
private fun Modifier.carTouchControls(controls: CarControls): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        awaitPointerEventScope {
            var prevLeft = false
            var prevRight = false
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val middle = size.width / 2f
                val height = size.height.toFloat()
                var left = false
                var right = false
                for (change in event.changes) {
                    val fraction = change.position.y / height
                    if (fraction < 0.18f) {
                        if (change.pressed && !change.previousPressed) controls.gearUpQueued = true
                    } else if (fraction > 0.82f) {
                        if (change.pressed && !change.previousPressed) controls.gearDownQueued = true
                    } else if (change.pressed) {
                        if (change.position.x < middle) left = true else right = true
                    }
                }
                if (left && !prevLeft) controls.leftPressQueued = true
                if (right && !prevRight) controls.rightPressQueued = true
                controls.leftHeld = left
                controls.rightHeld = right
                prevLeft = left
                prevRight = right
            }
        }
    }

/**
 * One finger: where you first touch is the centre. The further up you slide, the faster the car goes. Down reverses,
 * left or right steers. The car goes while the finger is down and stops when you lift it. A quick tap asks the GPS.
 */
private fun Modifier.stickTouchControls(controls: CarControls): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val startX = down.position.x
            val startY = down.position.y
            val startTime = System.currentTimeMillis()
            val fullY = size.height * 0.25f
            val fullX = size.width * 0.22f
            var peakSpeed = 0f
            var moved = 0f
            var lastY = startY
            var lastTime = startTime
            controls.stickActive = true
            controls.stickX = 0f
            controls.stickY = 0f
            controls.stickBoost = 0f

            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull()
                if (change == null || !change.pressed) break
                val now = System.currentTimeMillis()
                controls.stickX = ((change.position.x - startX) / fullX).coerceIn(-1f, 1f)
                controls.stickY = (-(change.position.y - startY) / fullY).coerceIn(-1f, 1f)
                val travelled = abs(change.position.x - startX) + abs(change.position.y - startY)
                if (travelled > moved) moved = travelled

                // How fast the finger moves in the first moments decides how hard the car accelerates
                val step = now - lastTime
                if (now - startTime < 400L && step > 0L) {
                    val pixelsPerSecond = abs(change.position.y - lastY) / step * 1000f
                    peakSpeed = max(peakSpeed, pixelsPerSecond)
                    controls.stickBoost = (peakSpeed / (size.height * 2.5f)).coerceIn(0f, 1f)
                }
                lastY = change.position.y
                lastTime = now
            }

            // a quick tap that did not move asks the GPS
            if (moved < 30f && System.currentTimeMillis() - startTime < 300L) controls.gpsQueued = true

            controls.stickActive = false
            controls.stickX = 0f
            controls.stickY = 0f
            controls.stickBoost = 0f
        }
    }

@Composable
fun CarDriveScreen(soundManager: SoundManager, paused: Boolean, onBack: () -> Unit) {
    val controller = remember { CarDriveController(soundManager, onBack) }
    val controls = remember { CarControls() }
    var uiTick by remember { mutableStateOf(0) }
    val isPaused by rememberUpdatedState(paused)
    var backPressedAt by remember { mutableStateOf(0L) }

    // Holding the left or right edge of the screen can look like a back gesture, so during a drive ask twice before leaving
    BackHandler(enabled = controller.game != null) {
        val now = System.currentTimeMillis()
        if (now - backPressedAt < 2500L) {
            soundManager.playSpatial("ui_back", pan = 0f, volume = 0.9f)
            onBack()
        } else {
            backPressedAt = now
            MyScreenReader.speak("Do the back gesture again to leave the drive.")
        }
    }

    LaunchedEffect(Unit) {
        controller.begin()
    }

    DisposableEffect(Unit) {
        onDispose { controller.shutdown() }
    }

    val game = controller.game

    LaunchedEffect(game) {
        if (game == null) return@LaunchedEffect
        var last = System.nanoTime()
        var counter = 0
        while (true) {
            delay(30)
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            if (isPaused) continue
            game.tick(dt, controls)
            counter++
            if (counter % 5 == 0) uiTick++
        }
    }

    val refresh = uiTick

    if (game == null) {
        val spoken = MyScreenReader.currentSpokenTextState.value
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .myScreenReaderGestures()
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(controller.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(controller.line1, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text(controller.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
                }
                Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
                Text(
                    "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture returns to the menu.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .then(if (game.usesStick) Modifier.stickTouchControls(controls) else Modifier.carTouchControls(controls))
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(game.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(game.line1, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text(game.line2, fontSize = 20.sp, color = Color(0xFF94A3B8))
                }
                Text(
                    if (game.usesStick) {
                        "One finger: slide up to drive, the further up the faster. Slide down to reverse, left or right to steer. Lift the finger to stop. Quick tap: GPS. Back gesture twice leaves the drive."
                    } else {
                        "Top edge tap: faster. Bottom edge tap: slower, twice quickly: brake. Hold left or right half: change lane. Back gesture twice leaves the drive."
                    },
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}
