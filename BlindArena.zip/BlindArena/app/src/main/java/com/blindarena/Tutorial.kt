package com.blindarena

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// =========================================================================
// TUTORIALS (Mode 4, and a "Tutorial" option in the first menu of every game)
// A list of tutorials. Every game has
//   - a GESTURE lesson: the app asks for one gesture at a time and listens for it,
//   - a SOUND lesson: swipe to a sound, double tap to hear it and to hear what it means.
// The lessons are in TutorialLessons.kt.
// =========================================================================

class TutorialController(
    override val sound: SoundManager,
    private val scope: CoroutineScope,
    private val onExit: () -> Unit
) : TutorialHost {
    var title by mutableStateOf("TUTORIALS")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    /** Which touch surface the screen shows right now. */
    var inputMode by mutableStateOf(TutorialInput.MENU)

    /** How many menus are open on top of the first list. */
    var depth by mutableStateOf(0)
    var inLesson by mutableStateOf(false)

    val canGoBack: Boolean
        get() = inLesson || depth > 0

    override val controls = CarControls()
    override val duel = DuelControls()

    private var sim: PracticeSim? = null
    private var lessonJob: Job? = null
    private var cardJob: Job? = null
    private val stack = ArrayList<String>()
    private val seen = HashSet<String>()
    private var lastSeq = 0
    private var lastChangeMs = 0L

    // ---------------------------------------------------------------- the host for the lessons

    override fun setInput(mode: TutorialInput) {
        inputMode = mode
        controls.leftHeld = false
        controls.rightHeld = false
        controls.leftPressQueued = false
        controls.rightPressQueued = false
        controls.gearUpQueued = false
        controls.gearDownQueued = false
        controls.stickActive = false
        controls.stickX = 0f
        controls.stickY = 0f
        controls.stickBoost = 0f
        controls.gpsQueued = false
        duel.clear()
        duel.moveHeld = MOVE_NONE
    }

    override fun setSim(sim: PracticeSim?) {
        this.sim?.stop()
        this.sim = sim
    }

    override fun setItems(items: List<MyScreenReader.FocusItem>) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        lastChangeMs = Clock.now()
        // Nothing focused yet: the first swipe reads the first option and a stray double tap does nothing
        if (items.isNotEmpty()) MyScreenReader.currentFocusIndex.value = -1
    }

    override fun setHelp(text: String) {
        MyScreenReader.currentHelpContext = text
    }

    override fun clearGestures() {
        seen.clear()
        lastSeq = MyScreenReader.gestureSeq
    }

    override fun gestureSeen(name: String): Boolean = seen.contains(name)

    override suspend fun say(text: String, flush: Boolean) {
        speakAndWait(text, flush)
    }

    override suspend fun pause(ms: Long) {
        delay(ms)
    }

    override suspend fun waitFor(timeoutMs: Long, condition: () -> Boolean): Boolean {
        var waited = 0L
        while (waited < timeoutMs) {
            if (condition()) return true
            delay(40)
            waited += 40L
        }
        return condition()
    }

    // ---------------------------------------------------------------- the loop, called every 30 ms by the screen

    fun tick(dt: Float) {
        val seq = MyScreenReader.gestureSeq
        if (seq != lastSeq) {
            lastSeq = seq
            val gesture = MyScreenReader.lastGesture
            seen.add(gesture)
            // swiping to another sound stops the one that is being played
            if ((gesture == "next" || gesture == "previous") && cardJob != null) {
                cardJob?.cancel()
                cardJob = null
            }
        }
        sim?.tick(dt, controls, duel)
    }

    fun shutdown() {
        endLesson()
        cardJob?.cancel()
        cardJob = null
    }

    // ---------------------------------------------------------------- menus

    fun begin(startAt: String) {
        stack.clear()
        stack.add("top")
        if (startAt == "road" || startAt == "cricket" || startAt == "gun") stack.add(startAt)
        depth = stack.size - 1
        showMenu("")
    }

    private fun tooSoon(): Boolean = Clock.now() - lastChangeMs < 800L

    private fun openMenu(id: String) {
        if (tooSoon()) return
        stack.add(id)
        depth = stack.size - 1
        showMenu("")
    }

    /** The back gesture: out of a lesson, then up one menu at a time, then out of the tutorials. */
    fun back() {
        if (inLesson) {
            endLesson()
            showMenu("")
            return
        }
        if (stack.size > 1) {
            stack.removeAt(stack.size - 1)
            depth = stack.size - 1
            showMenu("")
            return
        }
        onExit()
    }

    private fun goBackItem(label: String): MyScreenReader.FocusItem {
        return MyScreenReader.FocusItem("tut_back", label, "button", "") { if (!tooSoon()) back() }
    }

    private fun entry(id: String, label: String, role: String, action: () -> Unit): MyScreenReader.FocusItem {
        return MyScreenReader.FocusItem(id, label, role, "") { if (!tooSoon()) action() }
    }

    private fun showMenu(prefix: String) {
        endLesson()
        cardJob?.cancel()
        cardJob = null
        setInput(TutorialInput.MENU)
        val id = stack[stack.size - 1]
        val items = ArrayList<MyScreenReader.FocusItem>()
        var heading = "Tutorials"
        var text = ""
        when (id) {
            "top" -> {
                heading = "Tutorials"
                items.add(entry("t_menu", "Menu gestures", "swipe, double tap, hold and the back gesture") { lesson { menuGesturesLesson(it) } })
                items.add(entry("t_road", "Road Drive", "three kinds of road drive") { openMenu("road") })
                items.add(entry("t_cricket", "Hand Cricket", "how to play and the sounds") { openMenu("cricket") })
                items.add(entry("t_gun", "Gun Fight", "gestures and sounds") { openMenu("gun") })
                items.add(MyScreenReader.FocusItem("t_exit", "Main menu", "button", "") { if (!tooSoon()) onExit() })
                text = "Tutorials. Learn the gestures and the sounds of every game. Swipe to hear the tutorials, then double tap to start one. The back gesture goes back."
            }
            "road" -> {
                heading = "Road Drive tutorials"
                items.add(entry("t_kalimpong", "Long drive to Kalimpong", "one finger driving and GPS", { openMenu("kalimpong") }))
                items.add(entry("t_rush", "Arcade rush", "the car drives by itself, you choose the lane", { openMenu("rush") }))
                items.add(entry("t_classic", "Highway and jungle road", "gears and lanes", { openMenu("classic") }))
                items.add(goBackItem("Back"))
                text = "Road Drive tutorials. Choose a road."
            }
            "kalimpong" -> {
                heading = "Long drive to Kalimpong"
                items.add(entry("t_k_gest", "Gestures", "practise the one finger driving", { lesson { stickLesson(it) } }))
                items.add(entry("t_k_snd", "Sounds", "what every sound means", { openMenu("sounds:kalimpong") }))
                items.add(goBackItem("Back"))
                text = "Long drive to Kalimpong. Choose gestures to practise driving with one finger, or sounds to learn what every sound means."
            }
            "rush" -> {
                heading = "Arcade rush"
                items.add(entry("t_r_gest", "Gestures", "practise changing lane and dodging", { lesson { rushLesson(it) } }))
                items.add(entry("t_r_snd", "Sounds", "what every sound means", { openMenu("sounds:rush") }))
                items.add(goBackItem("Back"))
                text = "Arcade rush. Choose gestures to practise changing lane, or sounds to learn what every sound means."
            }
            "classic" -> {
                heading = "Highway and jungle road"
                items.add(entry("t_c_gest", "Gestures", "practise gears and lanes", { lesson { carLesson(it) } }))
                items.add(entry("t_c_snd", "Sounds", "what every sound means", { openMenu("sounds:classic") }))
                items.add(goBackItem("Back"))
                text = "Highway and jungle road. Choose gestures to practise gears and lanes, or sounds to learn what every sound means."
            }
            "cricket" -> {
                heading = "Hand Cricket"
                items.add(entry("t_h_play", "Practice balls", "bat one ball and bowl one ball, with the real sounds", { lesson { cricketLesson(it) } }))
                items.add(entry("t_h_snd", "Sounds", "what every sound means", { openMenu("sounds:cricket") }))
                items.add(entry("t_h_gest", "Menu gestures", "swipe and double tap", { lesson { menuGesturesLesson(it) } }))
                items.add(goBackItem("Back"))
                text = "Hand Cricket. Choose practice balls to play one ball batting and one ball bowling, or sounds to learn what every sound means."
            }
            "gun" -> {
                heading = "Gun Fight"
                items.add(entry("t_g_gest", "Gestures", "practise walking, turning and shooting", { lesson { gunLesson(it) } }))
                items.add(entry("t_g_snd", "Sounds", "what every sound means", { openMenu("sounds:gun") }))
                items.add(goBackItem("Back"))
                text = "Gun Fight. Choose gestures to practise walking, turning and shooting, or sounds to learn what every sound means."
            }
            else -> {
                val kind = id.removePrefix("sounds:")
                val cards = when (kind) {
                    "kalimpong" -> kalimpongSoundCards()
                    "rush" -> rushSoundCards()
                    "classic" -> classicSoundCards()
                    "cricket" -> cricketSoundCards()
                    else -> gunSoundCards()
                }
                heading = "Sounds"
                items.add(entry("snd_all", "Play all sounds", "one after another, swipe to stop", { playAll(cards) }))
                for ((index, card) in cards.withIndex()) {
                    items.add(MyScreenReader.FocusItem("snd_$index", card.label, "sound", card.explanation) { if (!tooSoon()) playCard(card) })
                }
                items.add(goBackItem("Back"))
                text = "Sounds. There are ${cards.size} sounds. Swipe to a sound and double tap to hear it and to learn what it means. " +
                    "The first option plays them all. Hold one finger for one second to hear the explanation again."
            }
        }
        title = "TUTORIALS"
        line1 = heading
        line2 = "Swipe left or right, double tap to select"
        setItems(items)
        MyScreenReader.currentHelpContext = "Swipe to hear the options, then double tap to select. The back gesture goes back."
        MyScreenReader.speak(prefix + text)
    }

    // ---------------------------------------------------------------- lessons and sound cards

    private fun stopSim() {
        sim?.stop()
        sim = null
    }

    private fun endLesson() {
        lessonJob?.cancel()
        lessonJob = null
        stopSim()
        inputMode = TutorialInput.MENU
        inLesson = false
    }

    private fun lesson(block: suspend (TutorialHost) -> Unit) {
        endLesson()
        cardJob?.cancel()
        cardJob = null
        MyScreenReader.clearItems()
        inLesson = true
        title = "LESSON"
        line2 = "The back gesture leaves the lesson"
        lessonJob = scope.launch {
            block(this@TutorialController)
            lessonJob = null
            showMenu("Lesson finished. ")
        }
    }

    private fun playCard(card: SoundCard) {
        cardJob?.cancel()
        cardJob = scope.launch {
            delay(450) // let the select sound finish
            card.demo(sound)
            speakAndWait(card.explanation)
        }
    }

    private fun playAll(cards: List<SoundCard>) {
        cardJob?.cancel()
        cardJob = scope.launch {
            delay(450)
            speakAndWait("Playing all ${cards.size} sounds. Swipe to stop.")
            for (card in cards) {
                speakAndWait(card.label, pauseAfterMs = 100L)
                card.demo(sound)
                speakAndWait(card.explanation)
                delay(400)
            }
            speakAndWait("That was every sound. Swipe to a sound and double tap to hear it again.")
        }
    }
}

private fun inputHint(mode: TutorialInput): String {
    return when (mode) {
        TutorialInput.MENU -> "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture goes back."
        TutorialInput.STICK -> "One finger: slide up faster, down slower, left or right to steer. Lift to stop. Quick tap: GPS. Back gesture leaves the lesson."
        TutorialInput.LANES -> "Touch the left half: move left. Touch the right half: move right. Back gesture leaves the lesson."
        TutorialInput.CAR -> "Top edge tap: faster. Bottom edge tap: slower, twice quickly: brake. Hold left or right half: change lane. Back gesture leaves the lesson."
        TutorialInput.DUEL -> "Swipe left or right to turn, up to walk, down to step back. Tap the middle to fire, bottom edge to reload, top edge for status. Back gesture leaves the lesson."
    }
}

@Composable
fun TutorialScreen(soundManager: SoundManager, startAt: String, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val controller = remember { TutorialController(soundManager, scope, onBack) }

    BackHandler(enabled = controller.canGoBack) {
        soundManager.playSpatial("ui_back", pan = 0f, volume = 0.9f)
        controller.back()
    }

    LaunchedEffect(Unit) {
        controller.begin(startAt)
    }

    DisposableEffect(Unit) {
        onDispose { controller.shutdown() }
    }

    LaunchedEffect(Unit) {
        var last = System.nanoTime()
        while (true) {
            delay(30)
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            controller.tick(dt)
        }
    }

    val spoken = MyScreenReader.currentSpokenTextState.value
    val mode = controller.inputMode

    // A new touch surface for every kind of lesson: key() makes sure the old touch code is thrown away
    key(mode) {
        val touch = when (mode) {
            TutorialInput.MENU -> Modifier.myScreenReaderGestures()
            TutorialInput.STICK -> Modifier.stickTouchControls(controller.controls)
            TutorialInput.LANES -> Modifier.laneTouchControls(controller.controls)
            TutorialInput.CAR -> Modifier.carTouchControls(controller.controls)
            TutorialInput.DUEL -> Modifier.duelTouchControls(controller.duel)
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .then(touch)
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(controller.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(controller.line1, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text(controller.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
                }
                Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
                Text(inputHint(mode), fontSize = 13.sp, color = Color(0xFF64748B))
            }
        }
    }
}
