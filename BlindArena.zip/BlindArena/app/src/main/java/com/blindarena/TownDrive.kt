package com.blindarena

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.random.Random

// =========================================================================
// TOWN: find the hospital. The town is a grid of streets, 100 metres apart,
// with buildings in between. You drive with ONE finger:
//  - touch the screen and drag UP to drive forward (further and faster = quicker car),
//    DOWN to reverse, LEFT or RIGHT to steer like a real car (it only turns while moving)
//  - the car goes while your finger is down and stops when you lift it
// Listen: the hospital's ambulance siren comes from where the hospital is. The GPS
// voice tells you where to turn. A beeping pedestrian signal means the light is
// RED: stop. Cows, dogs, crowds, autos, buses, trucks, bikes and cyclists are on the roads.
// =========================================================================

class TownGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    private enum class Type { COW, DOG, CROWD, BUMP, AUTO, BUS, TRUCK, BIKE, CYCLIST }

    private class Thing(val type: Type, var x: Float, var y: Float) {
        var alongX: Boolean = false     // moving things: true = drives along an east-west road
        var dirSign: Float = 1f
        var speed: Float = 0f
        var callTimer: Float = 0f
        var beepTimer: Float = 0f
        var stream: Int = 0
        var gone: Boolean = false
    }

    private class Light(val x: Float, val y: Float) {
        var timer: Float = 0f
        var red: Boolean = false
        var beepTimer: Float = 0f
        var fined: Boolean = false
    }

    private class Source(val x: Float, val y: Float, val tag: String, val range: Float, val volume: Float) {
        var stream: Int = 0
    }

    companion object {
        const val BLOCK = 100f
        const val GRID = 4
        const val MAP_MAX = 400f
        const val ROAD_HALF = 6f
        const val TOP_SPEED = 14f
        const val REVERSE_TOP = 5f
        const val ACCEL = 4f
        const val BRAKE = 9f
        const val WHEELBASE = 2.7f
        const val MAX_STEER = 0.61f
        const val START_LIVES = 3
        const val GAME_OVER_SECONDS = 3.0f
        const val LIGHT_CYCLE = 16f
        const val LIGHT_RED_SECONDS = 6f
        const val ARRIVE_DISTANCE = 22f
    }

    // the car: x grows to the east, y to the north. Heading: 0 = north, 90 = east
    private var px = 0f
    private var py = 30f
    private var heading = 0f
    private var speed = 0f
    private var crashCooldown = 0f
    private var bumpTimer = 0f
    private var skidTimer = 0f
    private var wasFast = false

    var lives: Int = START_LIVES
        private set

    private var destI = 4
    private var destJ = 4
    private val destX: Float
        get() = destI * BLOCK
    private val destY: Float
        get() = destJ * BLOCK

    override val title: String
        get() = "TOWN"
    override val line1: String
        get() = "${(abs(speed) * 3.6f).toInt()} km/h   ${compassName(heading)}"
    override val line2: String
        get() = "Lives $lives   Hospital ${(distanceTo(destX, destY) / 10f).toInt() * 10} m"
    override val usesStick: Boolean
        get() = true

    private val engine = EngineSound(sound)
    private val things = mutableListOf<Thing>()
    private val lights = mutableListOf<Light>()
    private val sources = mutableListOf<Source>()
    private var sirenSource: Source? = null
    private var ambienceStream = 0
    private var reverseStream = 0
    private var indicatorStream = 0
    private var templeTimer = 8f

    // GPS
    private var announcedKey = -1
    private var turnNowSpoken = false
    private var plannedTurn = 0
    private var approachDir = 0
    private var passNodeI = -1
    private var passNodeJ = -1
    private var enteredNode = false

    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overWon = false
    private var overNotified = false

    init {
        do {
            destI = Random.nextInt(GRID + 1)
            destJ = Random.nextInt(GRID + 1)
        } while (destI + destJ < 3)
        buildTown()
        sound.playSpatial("door_close", pan = 0f, volume = 0.9f)
        MyScreenReader.currentHelpContext = "One finger: drag up to drive forward, down to reverse, left or right to steer. Lift the finger to stop. Follow the ambulance siren and the GPS."
        MyScreenReader.speak(
            "Town. A patient is in your car and the hospital is waiting. Listen for the ambulance siren: it comes from the hospital. The GPS will tell you where to turn. " +
                "Touch the screen with one finger and drag up to drive. Drag further and faster to go quicker. Drag down to reverse. Slide left or right to steer. Lift your finger to stop. " +
                "A beeping pedestrian signal means a red light: stop. Do the back gesture twice to leave."
        )
    }

    // ---------------------------------------------------------------- building the town

    private fun buildTown() {
        addStatic(Type.COW, 3)
        addStatic(Type.DOG, 2)
        addStatic(Type.CROWD, 2)
        addStatic(Type.BUMP, 5)
        addMover(Type.AUTO, 5f)
        addMover(Type.AUTO, 5f)
        addMover(Type.BUS, 4f)
        addMover(Type.TRUCK, 4f)
        addMover(Type.BIKE, 7f)
        addMover(Type.CYCLIST, 3f)

        // five traffic lights at inner junctions
        val nodes = ArrayList<Int>()
        for (i in 1..3) {
            for (j in 1..3) nodes.add(i * 10 + j)
        }
        nodes.shuffle()
        for (k in 0 until 5) {
            val light = Light((nodes[k] / 10) * BLOCK, (nodes[k] % 10) * BLOCK)
            light.timer = Random.nextFloat() * LIGHT_CYCLE
            light.red = light.timer < LIGHT_RED_SECONDS
            lights.add(light)
        }

        // places you can hear from far away
        sources.add(Source(150f, 250f, "market_loop", 130f, 0.9f))
        sources.add(Source(250f, 150f, "school_loop", 120f, 0.9f))
        val siren = Source(destX, destY, "siren_loop", 450f, 0.8f)
        sirenSource = siren
        sources.add(siren)
    }

    private fun roadPoint(alongX: Boolean): FloatArray {
        // a point on a street, never right inside a junction
        while (true) {
            val line = Random.nextInt(GRID + 1) * BLOCK
            val along = 20f + Random.nextFloat() * (MAP_MAX - 40f)
            val offset = along % BLOCK
            if (offset > 16f && offset < BLOCK - 16f) {
                return if (alongX) floatArrayOf(along, line) else floatArrayOf(line, along)
            }
        }
    }

    private fun addStatic(type: Type, count: Int) {
        for (n in 0 until count) {
            var point = roadPoint(Random.nextBoolean())
            var tries = 0
            while (distanceTo(point[0], point[1]) < 60f && tries < 20) {
                point = roadPoint(Random.nextBoolean())
                tries += 1
            }
            things.add(Thing(type, point[0], point[1]))
        }
    }

    private fun addMover(type: Type, speed: Float) {
        val alongX = Random.nextBoolean()
        val point = roadPoint(alongX)
        val thing = Thing(type, point[0], point[1])
        thing.alongX = alongX
        thing.dirSign = if (Random.nextBoolean()) 1f else -1f
        thing.speed = speed
        // keep to one side of the street
        if (alongX) thing.y += thing.dirSign * 2.5f else thing.x -= thing.dirSign * 2.5f
        thing.callTimer = 2f + Random.nextFloat() * 4f
        things.add(thing)
    }

    // ---------------------------------------------------------------- geometry and 3D sound

    private fun distanceTo(x: Float, y: Float): Float {
        val dx = x - px
        val dy = y - py
        return sqrt(dx * dx + dy * dy)
    }

    /** Angle of something relative to where the car points: 0 ahead, +90 right, -90 left, 180 behind. */
    private fun relAngle(x: Float, y: Float): Float {
        val bearing = Math.toDegrees(atan2((x - px).toDouble(), (y - py).toDouble())).toFloat()
        var d = (bearing - heading) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    private fun panFor(rel: Float): Float {
        return sin(Math.toRadians(rel.toDouble())).toFloat()
    }

    private fun volumeFor(rel: Float, distance: Float, range: Float, base: Float): Float {
        var volume = (1.1f - distance / range).coerceIn(0f, 1f) * base
        if (abs(rel) > 90f) volume *= 0.65f // behind you: quieter
        return volume.coerceIn(0f, 1f)
    }

    private fun playAt(tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float) {
        val d = distanceTo(x, y)
        if (d >= range) return
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (volume < 0.03f) return
        sound.playSpatial(tag, pan = panFor(rel), volume = volume, rate = rate)
    }

    /** A looping sound at a place: starts when you get close, follows it, stops when you are far. Returns the stream id (0 = not playing). */
    private fun updateLoop(stream: Int, tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float): Int {
        val d = distanceTo(x, y)
        if (d >= range) {
            if (stream != 0) sound.stopStream(stream)
            return 0
        }
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (stream == 0) return sound.playLoop(tag, panFor(rel), volume, rate)
        sound.updateStream(stream, panFor(rel), volume, rate)
        return stream
    }

    private fun onRoad(x: Float, y: Float): Boolean {
        if (x < -ROAD_HALF || x > MAP_MAX + ROAD_HALF || y < -ROAD_HALF || y > MAP_MAX + ROAD_HALF) return false
        val ex = abs(x - Math.round(x / BLOCK) * BLOCK)
        val ey = abs(y - Math.round(y / BLOCK) * BLOCK)
        return ex < ROAD_HALF || ey < ROAD_HALF
    }

    // ---------------------------------------------------------------- main loop

    override fun shutdown() {
        stopAll()
    }

    private fun stopAll() {
        engine.stop()
        sound.stopStream(ambienceStream)
        sound.stopStream(reverseStream)
        sound.stopStream(indicatorStream)
        ambienceStream = 0
        reverseStream = 0
        indicatorStream = 0
        for (s in sources) {
            sound.stopStream(s.stream)
            s.stream = 0
        }
        for (t in things) {
            sound.stopStream(t.stream)
            t.stream = 0
        }
    }

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                onOver(overText, overWon)
            }
            return
        }

        updateCar(dt, controls)
        if (isOver) return
        updateThings(dt)
        if (isOver) return
        updateLights(dt)
        if (isOver) return
        updateLandmarks(dt)
        updateGps()
        if (!isOver && distanceTo(destX, destY) < ARRIVE_DISTANCE) win()
    }

    // ---------------------------------------------------------------- the car

    private fun updateCar(dt: Float, controls: CarControls) {
        crashCooldown = max(0f, crashCooldown - dt)
        bumpTimer = max(0f, bumpTimer - dt)
        skidTimer = max(0f, skidTimer - dt)

        var target = 0f
        var steerCmd = 0f
        if (controls.stickActive) {
            val sy = controls.stickY
            val sx = controls.stickX
            if (sy > 0.06f) {
                // dragging further, or flicking faster, asks for more speed
                target = TOP_SPEED * (sy + 0.45f * controls.stickBoost).coerceIn(0f, 1f)
            } else if (sy < -0.06f) {
                target = -REVERSE_TOP * (-sy).coerceIn(0f, 1f)
            }
            steerCmd = if (abs(sx) > 0.08f) sx else 0f
        }

        val boostMultiplier = 1f + 2f * controls.stickBoost
        val slowing = abs(target) < abs(speed) || target * speed < 0f
        val rate = if (slowing) BRAKE else ACCEL * boostMultiplier
        speed = if (speed < target) min(target, speed + rate * dt) else max(target, speed - rate * dt)

        // A handbrake sound when you come to a stop from a good speed
        if (abs(speed) > 5f) wasFast = true
        if (wasFast && abs(speed) < 0.3f) {
            wasFast = false
            sound.playSpatial("handbrake", pan = 0f, volume = 0.7f)
        }

        // Steering like a real car: it only turns while moving, and the faster you go the less the wheels can turn
        val steerAngle = steerCmd * MAX_STEER / (1f + abs(speed) / 5f)
        val yawRate = speed / WHEELBASE * tan(steerAngle)
        heading += yawRate * dt * 57.2958f
        heading = ((heading % 360f) + 360f) % 360f

        val radians = Math.toRadians(heading.toDouble()).toFloat()
        val nx = px + sin(radians) * speed * dt
        val ny = py + kotlin.math.cos(radians) * speed * dt
        if (onRoad(nx, ny)) {
            px = nx
            py = ny
        } else if (abs(speed) > 0.2f) {
            hitBuilding()
        }

        // Tyres squeal in a hard fast turn
        if (abs(speed) > 8f && abs(steerCmd) > 0.7f && skidTimer <= 0f) {
            skidTimer = 1.5f
            sound.playSpatial("car_skid", pan = 0f, volume = 0.5f)
        }

        // Engine, reverse beeper, indicator
        engine.update(abs(speed) / TOP_SPEED)
        reverseStream = onOff(reverseStream, "reverse_beep_loop", speed < -0.4f, 0f, 0.5f)
        val indicating = abs(steerCmd) > 0.25f && speed > 0.3f
        indicatorStream = onOff(indicatorStream, "indicator_loop", indicating, if (steerCmd < 0f) -0.4f else 0.4f, 0.45f)
    }

    private fun onOff(stream: Int, tag: String, active: Boolean, pan: Float, volume: Float): Int {
        if (active) {
            if (stream == 0) return sound.playLoop(tag, pan, volume, 1.0f)
            sound.updateStream(stream, pan, volume, 1.0f)
            return stream
        }
        if (stream != 0) sound.stopStream(stream)
        return 0
    }

    private fun hitBuilding() {
        if (abs(speed) > 3f && crashCooldown <= 0f) {
            loseLife("You hit a building.", "collision_hit", abs(speed) > 8f)
        } else if (bumpTimer <= 0f) {
            bumpTimer = 0.6f
            sound.playSpatial("wall_thud", pan = 0f, volume = 0.8f)
            sound.vibrate(40)
        }
        speed = 0f
    }

    // ---------------------------------------------------------------- crashes and penalties

    private fun loseLife(reason: String, soundTag: String, glass: Boolean) {
        if (crashCooldown > 0f) return
        crashCooldown = 2.0f
        lives -= 1
        speed = 0f
        sound.playSpatial(soundTag, pan = 0f, volume = 1.0f)
        if (glass) sound.playSpatial("glass_break", pan = 0f, volume = 0.8f)
        sound.vibrate(300)
        if (lives <= 0) {
            isOver = true
            overWon = false
            overTimer = GAME_OVER_SECONDS
            overText = "$reason Game over. The hospital was ${(distanceTo(destX, destY) / 10f).toInt() * 10} meters away."
            stopAll()
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("$reason $lives $word left.")
        }
    }

    private fun win() {
        isOver = true
        overWon = true
        overTimer = 4.5f
        overText = "You reached the hospital! The patient is safe. You finished with $lives ${if (lives == 1) "life" else "lives"} left."
        stopAll()
        sound.playSpatial("door_open", pan = 0f, volume = 0.9f)
        sound.playSpatial("victory", pan = 0f, volume = 1.0f)
        MyScreenReader.speak("You reached the hospital!")
    }

    // ---------------------------------------------------------------- animals, people, vehicles

    private fun nameOf(type: Type): String {
        return when (type) {
            Type.COW -> "cow"
            Type.DOG -> "dog"
            Type.CROWD -> "crowd of people"
            Type.BUMP -> "speed bump"
            Type.AUTO -> "auto rickshaw"
            Type.BUS -> "bus"
            Type.TRUCK -> "truck"
            Type.BIKE -> "motorcycle"
            Type.CYCLIST -> "cyclist"
        }
    }

    private fun radiusOf(type: Type): Float {
        return when (type) {
            Type.COW -> 2.5f
            Type.DOG -> 2.0f
            Type.CROWD -> 3.0f
            Type.BUMP -> 0f
            Type.AUTO -> 2.5f
            Type.BUS -> 4.0f
            Type.TRUCK -> 3.5f
            Type.BIKE -> 2.0f
            Type.CYCLIST -> 2.0f
        }
    }

    private fun updateThings(dt: Float) {
        for (t in things) {
            if (t.gone) continue

            // vehicles and cyclists drive back and forth along their street
            if (t.type == Type.AUTO || t.type == Type.BUS || t.type == Type.TRUCK || t.type == Type.BIKE || t.type == Type.CYCLIST) {
                val step = t.speed * t.dirSign * dt
                if (t.alongX) {
                    t.x += step
                    if (t.x < 0f) {
                        t.x = 0f
                        t.dirSign = 1f
                    } else if (t.x > MAP_MAX) {
                        t.x = MAP_MAX
                        t.dirSign = -1f
                    }
                } else {
                    t.y += step
                    if (t.y < 0f) {
                        t.y = 0f
                        t.dirSign = 1f
                    } else if (t.y > MAP_MAX) {
                        t.y = MAP_MAX
                        t.dirSign = -1f
                    }
                }
            }

            val d = distanceTo(t.x, t.y)
            t.callTimer -= dt

            when (t.type) {
                Type.COW -> {
                    if (t.callTimer <= 0f && d < 90f) {
                        playAt("cow_moo", t.x, t.y, 90f, 1.0f, 1.0f)
                        t.callTimer = 4f + Random.nextFloat() * 3f
                    }
                }
                Type.DOG -> {
                    if (t.callTimer <= 0f && d < 70f) {
                        playAt("dog_bark", t.x, t.y, 70f, 1.0f, 1.0f)
                        t.callTimer = 2.5f + Random.nextFloat() * 2f
                    }
                }
                Type.CROWD -> {
                    t.stream = updateLoop(t.stream, "crowd_town_loop", t.x, t.y, 80f, 0.9f, 1.0f)
                }
                Type.BUMP -> {
                    bumpCue(t, dt, d)
                }
                Type.AUTO -> {
                    t.stream = updateLoop(t.stream, "rickshaw_loop", t.x, t.y, 100f, 0.8f, 1.0f)
                    horn(t, d, "horn_auto", 45f)
                }
                Type.BUS -> {
                    t.stream = updateLoop(t.stream, "eng_idle", t.x, t.y, 100f, 0.8f, 0.7f)
                    horn(t, d, "horn_bus", 55f)
                }
                Type.TRUCK -> {
                    t.stream = updateLoop(t.stream, "eng_idle", t.x, t.y, 100f, 0.8f, 0.6f)
                    horn(t, d, "horn_truck", 55f)
                }
                Type.BIKE -> {
                    t.stream = updateLoop(t.stream, "eng_high", t.x, t.y, 90f, 0.6f, 1.25f)
                    if (t.callTimer <= 0f && d < 30f) {
                        playAt("moto_pass", t.x, t.y, 60f, 1.0f, 1.0f)
                        t.callTimer = 9f
                    }
                }
                Type.CYCLIST -> {
                    if (t.callTimer <= 0f && d < 45f) {
                        playAt("bicycle_bell", t.x, t.y, 60f, 1.0f, 1.0f)
                        t.callTimer = 4f
                    }
                }
            }

            // running into something
            val radius = radiusOf(t.type)
            if (radius > 0f && d < radius && crashCooldown <= 0f && (abs(speed) > 0.5f || t.speed > 0f)) {
                val name = nameOf(t.type)
                val isStatic = t.type == Type.COW || t.type == Type.DOG || t.type == Type.CROWD
                if (isStatic) {
                    t.gone = true
                    sound.stopStream(t.stream)
                    t.stream = 0
                }
                loseLife("You hit a $name.", "collision_hit", t.type == Type.BUS || t.type == Type.TRUCK)
                if (isOver) return
            }
        }
    }

    private fun horn(t: Thing, d: Float, tag: String, range: Float) {
        if (t.callTimer <= 0f && d < range) {
            playAt(tag, t.x, t.y, range + 30f, 1.0f, 1.0f)
            t.callTimer = 5f + Random.nextFloat() * 4f
        }
    }

    /** Low beeps when a speed bump is straight ahead, and a thump when you cross one. */
    private fun bumpCue(t: Thing, dt: Float, d: Float) {
        val rel = relAngle(t.x, t.y)
        if (d < 35f && abs(rel) < 25f && speed > 1f) {
            t.beepTimer -= dt
            if (t.beepTimer <= 0f) {
                val closeness = (1f - d / 35f).coerceIn(0f, 1f)
                sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.4f * closeness, rate = 0.6f + 0.4f * closeness)
                t.beepTimer = 0.12f + 0.4f * (1f - closeness)
            }
        }
        if (d < 3f && t.callTimer <= 0f && abs(speed) > 0.5f) {
            t.callTimer = 2f
            sound.playSpatial("bump_thud", pan = 0f, volume = 1.0f)
            if (abs(speed) > 6f) {
                sound.vibrate(100)
                speed *= 0.5f
            }
        }
    }

    // ---------------------------------------------------------------- traffic lights

    private fun updateLights(dt: Float) {
        for (l in lights) {
            l.timer += dt
            if (l.timer >= LIGHT_CYCLE) l.timer -= LIGHT_CYCLE
            val red = l.timer < LIGHT_RED_SECONDS
            if (red && !l.red) l.fined = false
            l.red = red

            val d = distanceTo(l.x, l.y)
            // The beeping pedestrian signal is the sound of a RED light for cars
            if (red && d < 130f) {
                l.beepTimer -= dt
                if (l.beepTimer <= 0f) {
                    playAt("ped_beep", l.x, l.y, 140f, 0.9f, 1.0f)
                    l.beepTimer = 0.55f
                }
            }
            if (red && !l.fined && d < 9f && abs(speed) > 2.5f && crashCooldown <= 0f) {
                l.fined = true
                loseLife("You ran a red light.", "police_whistle", false)
                if (isOver) return
            }
        }
    }

    // ---------------------------------------------------------------- places you can hear

    private fun updateLandmarks(dt: Float) {
        ambienceStream = onOff(ambienceStream, "crowd_town_loop", true, 0f, 0.12f)

        for (s in sources) {
            val rate = 1.0f
            s.stream = updateLoop(s.stream, s.tag, s.x, s.y, s.range, s.volume, rate)
        }

        // the temple bell now and then, from the north east corner of town
        templeTimer -= dt
        if (templeTimer <= 0f) {
            playAt("temple_bell", 350f, 350f, 240f, 1.0f, 1.0f)
            templeTimer = 14f + Random.nextFloat() * 10f
        }
    }

    // ---------------------------------------------------------------- GPS

    private fun snapDirection(): Int {
        return ((Math.round(heading / 90f) % 4) + 4) % 4
    }

    private fun stepX(dir: Int): Int = when (dir) {
        1 -> 1
        3 -> -1
        else -> 0
    }

    private fun stepY(dir: Int): Int = when (dir) {
        0 -> 1
        2 -> -1
        else -> 0
    }

    /** 0 = straight on, 1 = right, 2 = left, at junction (i, j) when arriving in direction dir. Chooses the way that gets closest to the hospital. */
    private fun chooseTurn(i: Int, j: Int, dir: Int): Int {
        var best = 0
        var bestScore = Int.MAX_VALUE
        val options = intArrayOf(0, 1, 2)
        for (option in options) {
            val newDir = when (option) {
                0 -> dir
                1 -> (dir + 1) % 4
                else -> (dir + 3) % 4
            }
            val ni = i + stepX(newDir)
            val nj = j + stepY(newDir)
            if (ni < 0 || ni > GRID || nj < 0 || nj > GRID) continue
            val score = abs(destI - ni) + abs(destJ - nj)
            if (score < bestScore) {
                bestScore = score
                best = option
            }
        }
        return best
    }

    private fun updateGps() {
        if (speed < 0.5f) return
        val dir = snapDirection()
        val vertical = dir == 0 || dir == 2

        // the next junction ahead on the street you are driving along
        val nodeI: Int
        val nodeJ: Int
        val along: Float
        if (vertical) {
            nodeI = Math.round(px / BLOCK)
            nodeJ = if (dir == 0) {
                Math.floor(((py + 3f) / BLOCK).toDouble()).toInt() + 1
            } else {
                Math.ceil(((py - 3f) / BLOCK).toDouble()).toInt() - 1
            }
            along = abs(nodeJ * BLOCK - py)
        } else {
            nodeJ = Math.round(py / BLOCK)
            nodeI = if (dir == 1) {
                Math.floor(((px + 3f) / BLOCK).toDouble()).toInt() + 1
            } else {
                Math.ceil(((px - 3f) / BLOCK).toDouble()).toInt() - 1
            }
            along = abs(nodeI * BLOCK - px)
        }

        // after you pass a junction: did you take the turn the GPS gave?
        if (passNodeI >= 0) {
            val d = distanceTo(passNodeI * BLOCK, passNodeJ * BLOCK)
            if (d < 14f) {
                enteredNode = true
            } else if (enteredNode && d > 18f) {
                val actual = (dir - approachDir + 4) % 4
                val actualTurn = when (actual) {
                    0 -> 0
                    1 -> 1
                    else -> 2
                }
                if (plannedTurn != 0) {
                    if (actualTurn == plannedTurn) {
                        sound.playSpatial("ui_select", pan = 0f, volume = 0.5f)
                    } else {
                        MyScreenReader.speak("Recalculating.", flush = false)
                    }
                }
                passNodeI = -1
                passNodeJ = -1
                enteredNode = false
            }
        }

        if (nodeI < 0 || nodeI > GRID || nodeJ < 0 || nodeJ > GRID) return

        if (along <= 140f) {
            val key = nodeI * 100 + nodeJ * 10 + dir
            if (key != announcedKey) {
                announcedKey = key
                turnNowSpoken = false
                plannedTurn = chooseTurn(nodeI, nodeJ, dir)
                approachDir = dir
                passNodeI = nodeI
                passNodeJ = nodeJ
                enteredNode = false
                if (plannedTurn != 0) {
                    val side = if (plannedTurn == 1) "right" else "left"
                    val meters = (Math.round(along / 50f) * 50).coerceAtLeast(50)
                    MyScreenReader.speak("In $meters meters, turn $side.", flush = false)
                }
            }
            if (plannedTurn != 0 && !turnNowSpoken && along <= 35f && key == announcedKey) {
                turnNowSpoken = true
                val side = if (plannedTurn == 1) "right" else "left"
                MyScreenReader.speak("Turn $side now.", flush = false)
            }
        }
    }
}
