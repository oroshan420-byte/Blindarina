package com.blindarena

import kotlin.random.Random

// =========================================================================
// PREMIER LEAGUE SEASON (Hand Cricket, in the style of the IPL)
//
//  - Six teams: you and five computer teams, each with a star whose number habits are in CricketBots.kt.
//  - League stage: every team plays every other team once, so you play 5 matches. A win is 2 points, a tie 1 point each.
//    The matches between the computer teams are played at once by the computer (with the same rules and the same habits).
//    The table is sorted by points, then by runs scored minus runs given away.
//  - Playoffs for the top four:
//      Qualifier 1: 1st against 2nd. The winner goes straight to the Final, the loser gets a second chance.
//      Eliminator: 3rd against 4th. The loser is out.
//      Qualifier 2: the loser of Qualifier 1 against the winner of the Eliminator. The loser is out.
//      Final: the winner of Qualifier 1 against the winner of Qualifier 2.
//  - This file has no sounds and no screens: it is only the rules, so they can be tested alone.
//    The season can be saved after every match and continued later.
//  - The team names are only city names, and the stars carry the names of well-known cricketers. Change them here if you wish.
// =========================================================================

const val SEASON_OVERS = 2
const val SEASON_WICKETS = 2
const val SEASON_TEAMS = 6
const val SEASON_ROUNDS = 5

const val FINISH_NONE = 0
const val FINISH_LEAGUE = 1      // out after the league stage
const val FINISH_PLAYOFFS = 2    // out in the playoffs
const val FINISH_RUNNER_UP = 3
const val FINISH_CHAMPION = 4

class SeasonTeam(val name: String, val intro: String, val bot: CricketBot?)

object SeasonTeams {
    /** Number 0 is you. */
    val all: List<SeasonTeam> = listOf(
        SeasonTeam("Your team", "", null),
        SeasonTeam(
            "Kalimpong",
            "Kalimpong is a young team. Their captain Roshan is a beginner who picks his numbers at random.",
            CricketBot("Roshan", intArrayOf(1, 1, 1, 1, 1, 1), 0f, 0f)
        ),
        SeasonTeam(
            "Kolkata",
            "Kolkata is led by Pranit, a copycat who often repeats the number you showed last.",
            CricketBot("Pranit", intArrayOf(1, 1, 1, 1, 1, 1), 0.4f, 0f)
        ),
        SeasonTeam(
            "Bengaluru",
            "Bengaluru has Virat Kohli. They play steady cricket and like the numbers 1, 2, 3 and 4.",
            CricketBot("Virat Kohli", intArrayOf(3, 3, 3, 3, 1, 1), 0f, 0f)
        ),
        SeasonTeam(
            "Hyderabad",
            "Hyderabad has Travis Head and Abhishek Sharma. They are attacking hitters and love 4, 5 and 6.",
            CricketBot("Travis Head and Abhishek Sharma", intArrayOf(1, 1, 1, 2, 3, 4), 0f, 0f)
        ),
        SeasonTeam(
            "Mumbai",
            "Mumbai has Jasprit Bumrah, a clever bowler who remembers your favourite numbers.",
            CricketBot("Jasprit Bumrah", intArrayOf(1, 1, 1, 1, 1, 1), 0f, 0.5f)
        )
    )

    /** How a team is called in a sentence: "You" for the player's team. */
    fun label(i: Int): String = if (i == 0) "You" else all[i].name
}

/** The next match of the player: who is the opponent, what is it called, and one sentence about what is at stake. */
class Fixture(val opponent: Int, val label: String, val blurb: String)

class Row(val team: Int, val points: Int, val net: Int, val played: Int)

/**
 * What happened after the player's match. text: the words to say. replay: the match was tied in a playoff and must be played again.
 * over: the season is finished for the player. champion: the number of the champion team (-1 while unknown).
 */
class SeasonReport(val text: String, val replay: Boolean, val over: Boolean, val finish: Int, val champion: Int)

fun ordinalWord(n: Int): String = when (n) {
    1 -> "first"
    2 -> "second"
    3 -> "third"
    4 -> "fourth"
    5 -> "fifth"
    else -> "sixth"
}

fun pointsWord(n: Int): String = if (n == 1) "1 point" else "$n points"

/** "A", "A and B", "A, B and C". */
fun joinNames(names: List<String>): String {
    if (names.isEmpty()) return ""
    if (names.size == 1) return names[0]
    return names.subList(0, names.size - 1).joinToString(", ") + " and " + names[names.size - 1]
}

class Season(private val rnd: Random = Random) {

    companion object {
        const val STAGE_LEAGUE = 0
        const val STAGE_PLAYOFF_ONE = 1     // Qualifier 1 and the Eliminator
        const val STAGE_QUALIFIER_TWO = 2
        const val STAGE_FINAL = 3
        const val STAGE_OVER = 4

        private const val VERSION = 1
        private const val KEY = "season_"
        private const val SAVED_INTS = 39

        /** The three matches of a league round (the circle method): every team plays once in every round and every pair meets once. */
        fun leagueFixtures(round: Int): List<Pair<Int, Int>> {
            val arr = IntArray(SEASON_TEAMS)
            arr[0] = 0
            for (i in 1 until SEASON_TEAMS) arr[i] = 1 + (i - 1 + round) % (SEASON_TEAMS - 1)
            return listOf(Pair(arr[0], arr[5]), Pair(arr[1], arr[4]), Pair(arr[2], arr[3]))
        }

        fun leagueOpponent(round: Int): Int {
            for (p in leagueFixtures(round)) {
                if (p.first == 0) return p.second
                if (p.second == 0) return p.first
            }
            return 1
        }

        /** The saved season, or null when there is none (or it was finished). */
        fun load(store: KeyValueStore, rnd: Random = Random): Season? {
            if (store.getInt(KEY + "0", 0) != VERSION) return null
            val v = IntArray(SAVED_INTS) { store.getInt(KEY + it, 0) }
            if (!validInts(v)) return null
            val s = Season(rnd)
            s.fromInts(v)
            if (s.stage == STAGE_OVER) return null
            return s
        }

        /** A damaged or unfinished save is ignored instead of crashing the game. */
        private fun validInts(v: IntArray): Boolean {
            if (v.size != SAVED_INTS || v[0] != VERSION) return false
            val stage = v[1]
            val round = v[2]
            if (stage < STAGE_LEAGUE || stage > STAGE_OVER) return false
            if (round < 0 || round > SEASON_ROUNDS) return false
            if (stage == STAGE_LEAGUE && round >= SEASON_ROUNDS) return false
            if (v[3] < 0 || v[4] < FINISH_NONE || v[4] > FINISH_CHAMPION) return false
            for (k in 5..10) if (v[k] < -1 || v[k] >= SEASON_TEAMS) return false   // playerOpp, champion, q1Winner, q1Loser, elimWinner, q2Winner
            if (v[5] < 0) return false
            for (k in 11 until 11 + SEASON_TEAMS) if (v[k] < 0) return false
            for (k in 11 + 3 * SEASON_TEAMS until 11 + 4 * SEASON_TEAMS) if (v[k] < 0 || v[k] > 20) return false
            for (k in 35 until 39) if (v[k] < -1 || v[k] >= SEASON_TEAMS) return false
            if (stage != STAGE_LEAGUE) {
                // in the playoffs the player must be one of the top four
                var inTop = false
                for (k in 35 until 39) if (v[k] == 0) inTop = true
                if (!inTop) return false
            }
            return true
        }

        fun clearSaved(store: KeyValueStore) {
            store.putInt(KEY + "0", 0)
        }
    }

    var stage = STAGE_LEAGUE
        private set
    var round = 0
        private set
    /** How many matches of the player were started in all. The batting order of the player alternates. */
    var attempts = 0
    var finish = FINISH_NONE
        private set
    var champion = -1
        private set

    val points = IntArray(SEASON_TEAMS)
    val runsFor = IntArray(SEASON_TEAMS)
    val runsAgainst = IntArray(SEASON_TEAMS)
    val played = IntArray(SEASON_TEAMS)

    private var playerOpp = leagueOpponent(0)
    private val top4 = IntArray(4) { -1 }
    private var q1Winner = -1
    private var q1Loser = -1
    private var elimWinner = -1
    private var q2Winner = -1

    // ---------------------------------------------------------------- the table

    fun standings(): List<Row> {
        val rows = ArrayList<Row>()
        for (t in 0 until SEASON_TEAMS) rows.add(Row(t, points[t], runsFor[t] - runsAgainst[t], played[t]))
        return rows.sortedWith(compareByDescending<Row> { it.points }.thenByDescending { it.net }.thenBy { it.team })
    }

    /** 1 to 6. */
    fun position(team: Int): Int {
        val st = standings()
        for (i in st.indices) if (st[i].team == team) return i + 1
        return SEASON_TEAMS
    }

    fun tableText(): String {
        val sb = StringBuilder("Points table after $round ${if (round == 1) "match" else "matches"}. ")
        val st = standings()
        for (i in st.indices) {
            val r = st[i]
            val net = if (r.net > 0) "plus ${r.net}" else if (r.net < 0) "minus ${-r.net}" else "zero"
            sb.append("${ordinalWord(i + 1)}, ${SeasonTeams.all[r.team].name}, ${pointsWord(r.points)}, net runs $net. ")
        }
        return sb.toString().trim()
    }

    // ---------------------------------------------------------------- the next match of the player

    fun isOver(): Boolean = stage == STAGE_OVER

    fun nextFixture(): Fixture? {
        return when (stage) {
            STAGE_LEAGUE -> Fixture(playerOpp, "League match ${round + 1} of $SEASON_ROUNDS", "")
            STAGE_PLAYOFF_ONE ->
                if (playerSlot() < 2) {
                    Fixture(playerOpp, "Qualifier 1", "The winner goes straight to the Final. The loser gets a second chance.")
                } else {
                    Fixture(playerOpp, "Eliminator", "Win or go home.")
                }
            STAGE_QUALIFIER_TWO -> Fixture(playerOpp, "Qualifier 2", "Win to reach the Final. Lose and your season ends.")
            STAGE_FINAL -> Fixture(playerOpp, "Final", "The winner is the champion.")
            else -> null
        }
    }

    private fun playerSlot(): Int {
        for (i in 0 until 4) if (top4[i] == 0) return i
        return -1
    }

    /** A few words for the "continue season" menu. */
    fun describeProgress(): String {
        val f = nextFixture() ?: return "the season is over"
        return if (stage == STAGE_LEAGUE) {
            "${f.label.lowercase()}, you are ${ordinalWord(position(0))} with ${pointsWord(points[0])}"
        } else {
            "the playoffs, ${f.label}"
        }
    }

    // ---------------------------------------------------------------- the player's match is over

    fun report(playerWon: Boolean, tied: Boolean, playerRuns: Int, opponentRuns: Int): SeasonReport {
        return when (stage) {
            STAGE_LEAGUE -> leagueResult(playerWon, tied, playerRuns, opponentRuns)
            STAGE_PLAYOFF_ONE -> playoffOneResult(playerWon, tied)
            STAGE_QUALIFIER_TWO -> qualifierTwoResult(playerWon, tied)
            STAGE_FINAL -> finalResult(playerWon, tied)
            else -> SeasonReport("The season is over.", false, true, finish, champion)
        }
    }

    private fun record(a: Int, b: Int, runsA: Int, runsB: Int) {
        runsFor[a] += runsA
        runsAgainst[a] += runsB
        runsFor[b] += runsB
        runsAgainst[b] += runsA
        played[a] += 1
        played[b] += 1
        if (runsA > runsB) {
            points[a] += 2
        } else if (runsB > runsA) {
            points[b] += 2
        } else {
            points[a] += 1
            points[b] += 1
        }
    }

    private fun leagueResult(playerWon: Boolean, tied: Boolean, playerRuns: Int, opponentRuns: Int): SeasonReport {
        // the player's match: the result is the one that was played
        record(0, playerOpp, playerRuns, opponentRuns)
        // the other two matches of the round
        for (p in leagueFixtures(round)) {
            if (p.first != 0 && p.second != 0) {
                val r = simulate(p.first, p.second)
                record(p.first, p.second, r.first, r.second)
            }
        }
        round += 1

        var text = if (tied) {
            "Each team earns 1 point."
        } else if (playerWon) {
            "You earn 2 points."
        } else {
            "You earn no points."
        }
        val pos = position(0)
        if (round < SEASON_ROUNDS) {
            text += " You are ${ordinalWord(pos)} with ${pointsWord(points[0])}."
            if (pos != 1) {
                val leader = standings()[0]
                text += " ${SeasonTeams.label(leader.team)} lead with ${pointsWord(leader.points)}."
            }
            playerOpp = leagueOpponent(round)
            return SeasonReport(text, false, false, FINISH_NONE, -1)
        }

        // the league stage is over
        val st = standings()
        for (i in 0 until 4) top4[i] = st[i].team
        text += " The league stage is over. You finished ${ordinalWord(pos)} with ${pointsWord(points[0])}."
        val names = ArrayList<String>()
        for (i in 0 until 4) names.add(if (top4[i] == 0) "your team" else SeasonTeams.all[top4[i]].name)
        if (pos <= 4) {
            text += " The top four are ${joinNames(names)}. You are in the playoffs!"
            stage = STAGE_PLAYOFF_ONE
            playerOpp = if (pos == 1) top4[1] else if (pos == 2) top4[0] else if (pos == 3) top4[3] else top4[2]
            return SeasonReport(text, false, false, FINISH_NONE, -1)
        }
        // out: the computer plays the playoffs
        text += " Only the top four go through, so your season ends."
        q1Winner = playMatch(top4[0], top4[1])
        q1Loser = if (q1Winner == top4[0]) top4[1] else top4[0]
        elimWinner = playMatch(top4[2], top4[3])
        q2Winner = playMatch(q1Loser, elimWinner)
        champion = playMatch(q1Winner, q2Winner)
        text += " The champions are ${SeasonTeams.label(champion)}."
        return end(text, FINISH_LEAGUE)
    }

    private fun playoffOneResult(playerWon: Boolean, tied: Boolean): SeasonReport {
        if (tied) return tiedAgain()
        val slot = playerSlot()
        val opp = playerOpp
        if (slot < 2) {
            // Qualifier 1: the Eliminator is played at the same time by the computer
            q1Winner = if (playerWon) 0 else opp
            q1Loser = if (playerWon) opp else 0
            val e1 = top4[2]
            val e2 = top4[3]
            elimWinner = playMatch(e1, e2)
            val elimLoser = if (elimWinner == e1) e2 else e1
            val eText = "In the Eliminator, ${SeasonTeams.label(elimWinner)} beat ${SeasonTeams.label(elimLoser)}."
            if (playerWon) {
                q2Winner = playMatch(q1Loser, elimWinner)
                val q2Loser = if (q2Winner == q1Loser) elimWinner else q1Loser
                stage = STAGE_FINAL
                playerOpp = q2Winner
                return SeasonReport(
                    "You win Qualifier 1 and go straight to the Final! $eText In Qualifier 2, ${SeasonTeams.label(q2Winner)} beat ${SeasonTeams.label(q2Loser)}.",
                    false, false, FINISH_NONE, -1
                )
            }
            stage = STAGE_QUALIFIER_TWO
            playerOpp = elimWinner
            return SeasonReport(
                "You lose Qualifier 1, but you get a second chance in Qualifier 2. $eText",
                false, false, FINISH_NONE, -1
            )
        }
        // the Eliminator: Qualifier 1 is played at the same time by the computer
        q1Winner = playMatch(top4[0], top4[1])
        q1Loser = if (q1Winner == top4[0]) top4[1] else top4[0]
        val qText = "In Qualifier 1, ${SeasonTeams.label(q1Winner)} beat ${SeasonTeams.label(q1Loser)}."
        if (playerWon) {
            elimWinner = 0
            stage = STAGE_QUALIFIER_TWO
            playerOpp = q1Loser
            return SeasonReport(
                "You win the Eliminator and play Qualifier 2! $qText",
                false, false, FINISH_NONE, -1
            )
        }
        elimWinner = opp
        q2Winner = playMatch(q1Loser, elimWinner)
        champion = playMatch(q1Winner, q2Winner)
        return end(
            "You lose the Eliminator and your season ends. $qText ${SeasonTeams.label(champion)} are the champions.",
            FINISH_PLAYOFFS
        )
    }

    private fun qualifierTwoResult(playerWon: Boolean, tied: Boolean): SeasonReport {
        if (tied) return tiedAgain()
        val opp = playerOpp
        if (playerWon) {
            q2Winner = 0
            stage = STAGE_FINAL
            playerOpp = q1Winner
            return SeasonReport(
                "You win Qualifier 2 and reach the Final!",
                false, false, FINISH_NONE, -1
            )
        }
        q2Winner = opp
        champion = playMatch(q1Winner, q2Winner)
        return end(
            "You lose Qualifier 2 and your season ends. ${SeasonTeams.label(champion)} are the champions.",
            FINISH_PLAYOFFS
        )
    }

    private fun finalResult(playerWon: Boolean, tied: Boolean): SeasonReport {
        if (tied) return tiedAgain()
        if (playerWon) {
            champion = 0
            return end("You win the Final! You are the champions!", FINISH_CHAMPION)
        }
        champion = playerOpp
        return end("You lose the Final. You are the runners-up. ${SeasonTeams.label(champion)} are the champions.", FINISH_RUNNER_UP)
    }

    private fun tiedAgain(): SeasonReport {
        return SeasonReport("A tied playoff match is played again.", true, false, FINISH_NONE, -1)
    }

    private fun end(text: String, result: Int): SeasonReport {
        stage = STAGE_OVER
        finish = result
        return SeasonReport(text, false, true, result, champion)
    }

    // ---------------------------------------------------------------- matches between computer teams

    /** The computer plays a match between two computer teams. Returns the winner (a tie is decided by a coin). */
    private fun playMatch(a: Int, b: Int): Int {
        val r = simulate(a, b)
        return if (r.first > r.second) a else if (r.second > r.first) b else (if (rnd.nextBoolean()) a else b)
    }

    /** Runs of team a and team b in a match played by the computer: both sides use their own number habits. */
    private fun simulate(a: Int, b: Int): Pair<Int, Int> {
        val botA = SeasonTeams.all[a].bot ?: CricketBots.random
        val botB = SeasonTeams.all[b].bot ?: CricketBots.random
        val brainA = BotBrain(botA, rnd)
        val brainB = BotBrain(botB, rnd)
        val m = HandCricketMatch(SEASON_OVERS, SEASON_WICKETS, rnd.nextBoolean())   // team a plays the part of "the player"
        var guard = 0
        while (!m.matchOver && guard < 1000) {
            guard += 1
            val aBatting = m.playerBatting
            val pa = brainA.pick(!aBatting)
            val pb = brainB.pick(aBatting)
            m.playBall(pa, pb)
            brainA.observe(pb, !aBatting)
            brainB.observe(pa, aBatting)
        }
        return Pair(m.playerRuns, m.computerRuns)
    }

    // ---------------------------------------------------------------- saving

    fun toInts(): IntArray {
        val out = ArrayList<Int>()
        out.add(VERSION)
        out.add(stage)
        out.add(round)
        out.add(attempts)
        out.add(finish)
        out.add(playerOpp)
        out.add(champion)
        out.add(q1Winner)
        out.add(q1Loser)
        out.add(elimWinner)
        out.add(q2Winner)
        for (x in points) out.add(x)
        for (x in runsFor) out.add(x)
        for (x in runsAgainst) out.add(x)
        for (x in played) out.add(x)
        for (x in top4) out.add(x)
        return out.toIntArray()
    }

    private fun fromInts(v: IntArray) {
        var i = 1
        stage = v[i++]
        round = v[i++]
        attempts = v[i++]
        finish = v[i++]
        playerOpp = v[i++]
        champion = v[i++]
        q1Winner = v[i++]
        q1Loser = v[i++]
        elimWinner = v[i++]
        q2Winner = v[i++]
        for (t in 0 until SEASON_TEAMS) points[t] = v[i++]
        for (t in 0 until SEASON_TEAMS) runsFor[t] = v[i++]
        for (t in 0 until SEASON_TEAMS) runsAgainst[t] = v[i++]
        for (t in 0 until SEASON_TEAMS) played[t] = v[i++]
        for (t in 0 until 4) top4[t] = v[i++]
    }

    fun save(store: KeyValueStore) {
        val v = toInts()
        // the version is switched off while the numbers are written and on again at the end: a half written season is never loaded
        store.putInt(KEY + "0", 0)
        for (i in 1 until v.size) store.putInt(KEY + i, v[i])
        store.putInt(KEY + "0", v[0])
    }
}
