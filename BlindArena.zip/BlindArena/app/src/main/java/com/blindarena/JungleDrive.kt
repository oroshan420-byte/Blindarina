package com.blindarena

import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

// =========================================================================
// JUNGLE ROAD: a night journey of 4 kilometres to the village clinic.
// Things come towards you as you drive (they stand still, YOU move):
//  - animals on the road: you hear their calls on their side. They wander off after a while.
//  - fallen trees: beeps in the lanes that are blocked. The silent lane is free.
//  - potholes: low beeps when one is in your lane. Too fast and a tyre bursts.
//  - sharp bends: the GPS tells you. Slow to gear 2 and keep to the side of the bend.
//  - a narrow wooden bridge: stay in the middle lane and do not go too fast.
// Later it rains, thunder rolls, owls hoot.
// =========================================================================

class JungleGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    private enum class Kind { POTHOLE, TREE, ANIMAL, BEND, BRIDGE }

    // lane: POTHOLE / ANIMAL = the lane it is in; TREE = the one FREE lane; BEND = the lane you must be in; BRIDGE = 1
    private class Hazard(val kind: Kind, val lane: Int, var distance: Float) {
        var animal: String = ""
        var leaveTimer: Float = 0f
        var callTimer: Float = 0f
        var beepTimer: Float = 0f
        var bendLeft: Boolean = false
        var length: Float = 0f
        var entered: Boolean = false
        var cracked: Boolean = false
        var creakTimer: Float = 0f
    }

    companion object {
        const val GOAL_M = 4000f
        const val SPAWN_DISTANCE = 130f
        const val HIT_DISTANCE = 3f
        const val START_LIVES = 3
        const val GAME_OVER_SECONDS = 3.0f
        const val BRIDGE_AT_M = 1700f
        const val RAIN_FROM_M = 2000f
        const val OWLS_FROM_M = 1200f
        const val WARN_RANGE = 70f
        const val POTHOLE_WARN_RANGE = 45f
        const val BURST_SPEED = 26f
        const val BEND_MAX_GEAR = 2
        const val BRIDGE_MAX_GEAR = 2
        const val JUNGLE_VOLUME = 0.3f
        const val RAIN_VOLUME = 0.5f
        const val RIVER_VOLUME = 0.5f
        const val DIRT_VOLUME = 0.45f
    }

    private val drive = Drivetrain(sound)
    private val steering = LaneSteering(sound)

    var lives: Int = START_LIVES
        private set
    var progress: Float = 0f
        private set

    override val title: String
        get() = "JUNGLE ROAD"
    override val line1: String
        get() = "Gear ${drive.gear}   ${drive.kmh} km/h"
    override val line2: String
        get() = "Lives $lives   ${progress.toInt()} m of ${GOAL_M.toInt()} m"

    private val hazards = mutableListOf<Hazard>()
    private var nextSpawnAt = 120f
    private var bridgeSpawned = false
    private var nextMilestone = 1000f

    private var jungleStream = 0
    private var dirtStream = 0
    private var rainStream = 0
    private var riverStream = 0
    private var rainVolume = 0f
    private var riverVolume = 0f
    private var rainAnnounced = false
    private var thunderTimer = 8f
    private var owlTimer = 10f
    private var idleTimer = 0f

    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overWon = false
    private var overNotified = false

    init {
        drive.reset()
        sound.startEngineLoop("engine_loop")
        MyScreenReader.currentHelpContext = "Tap the top edge for a faster gear, the bottom edge for a slower gear, twice quickly to brake. Hold the left or right side of the screen to change lane."
        MyScreenReader.speak(
            "Jungle road. It is night. The village clinic is waiting for the medicine in your car. Drive 4 kilometres. " +
                "The car is stopped. Tap the top edge of the screen to speed up, the bottom edge to slow down, and twice quickly to brake hard. " +
                "Touch and hold the left or right side to change lane. " +
                "Listen for animals, fallen trees, bends and a bridge. Do the back gesture twice to leave."
        )
    }

    override fun shutdown() {
        stopAllLoops()
        sound.stopEngine()
    }

    // ---------------------------------------------------------------- loops

    private fun stopAllLoops() {
        sound.stopStream(jungleStream)
        sound.stopStream(dirtStream)
        sound.stopStream(rainStream)
        sound.stopStream(riverStream)
        jungleStream = 0
        dirtStream = 0
        rainStream = 0
        riverStream = 0
    }

    private fun ensureLoops() {
        // Big sound files may still be loading when the game starts, so keep trying until the loops play
        sound.startEngineLoop("engine_loop")
        if (jungleStream == 0) jungleStream = sound.playLoop("jungle_loop", 0f, JUNGLE_VOLUME, 1.0f)
        if (dirtStream == 0) dirtStream = sound.playLoop("dirt_loop", 0f, 0.01f, 1.0f)
    }

    // ---------------------------------------------------------------- main loop

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                onOver(overText, overWon)
            }
            return
        }

        ensureLoops()
        handleGears(controls, drive)
        steering.update(dt, controls)
        drive.update(dt)

        val step = drive.speed * dt
        progress += step

        spawnHazards()
        updateHazards(dt, step)
        if (isOver) return
        updateAtmosphere(dt)
        updateRoadNoise()
        updateMilestonesAndHints(dt)

        if (!isOver && progress >= GOAL_M) win()
    }

    // ---------------------------------------------------------------- what comes next on the road

    private fun spawnHazards() {
        if (progress < nextSpawnAt) return
        if (nextSpawnAt > GOAL_M - 200f) return

        if (!bridgeSpawned && progress >= BRIDGE_AT_M - SPAWN_DISTANCE) {
            bridgeSpawned = true
            val bridge = Hazard(Kind.BRIDGE, 1, SPAWN_DISTANCE)
            bridge.length = 120f
            hazards.add(bridge)
            MyScreenReader.speak("Narrow wooden bridge ahead. Slow down to gear 2 and stay in the middle lane.", flush = false)
            nextSpawnAt = progress + 300f
            return
        }

        val roll = Random.nextFloat()
        if (roll < 0.28f) {
            hazards.add(Hazard(Kind.POTHOLE, Random.nextInt(ROAD_LANES), SPAWN_DISTANCE))
        } else if (roll < 0.62f) {
            spawnAnimal()
        } else if (roll < 0.80f) {
            val tree = Hazard(Kind.TREE, Random.nextInt(ROAD_LANES), SPAWN_DISTANCE)
            hazards.add(tree)
            sound.playSpatial("tree_fall", pan = 0f, volume = 0.7f)
        } else if (progress > 400f) {
            val bendLeft = Random.nextBoolean()
            val bend = Hazard(Kind.BEND, if (bendLeft) 0 else 2, SPAWN_DISTANCE)
            bend.bendLeft = bendLeft
            bend.length = 60f
            hazards.add(bend)
            val side = if (bendLeft) "left" else "right"
            MyScreenReader.speak("Sharp $side bend ahead. Slow down to gear 2 and keep to the $side lane.", flush = false)
        } else {
            hazards.add(Hazard(Kind.POTHOLE, Random.nextInt(ROAD_LANES), SPAWN_DISTANCE))
        }
        nextSpawnAt = progress + 110f + Random.nextFloat() * 80f
    }

    private fun spawnAnimal() {
        val kinds = ArrayList<String>()
        kinds.add("deer")
        kinds.add("monkey")
        if (progress > 800f) kinds.add("elephant")
        if (progress > 2000f) kinds.add("tiger")
        val name = kinds[Random.nextInt(kinds.size)]
        val animal = Hazard(Kind.ANIMAL, Random.nextInt(ROAD_LANES), SPAWN_DISTANCE)
        animal.animal = name
        animal.leaveTimer = if (name == "tiger") 12f else 9f + Random.nextFloat() * 3f
        animal.callTimer = 0.3f
        hazards.add(animal)
    }

    // ---------------------------------------------------------------- hazards come closer

    private fun updateHazards(dt: Float, step: Float) {
        var crashReason: String? = null
        var bridgeAhead: Hazard? = null

        val iterator = hazards.iterator()
        while (iterator.hasNext()) {
            val h = iterator.next()
            h.distance -= step

            when (h.kind) {
                Kind.POTHOLE -> {
                    beacon(h, dt, h.lane == steering.lane, POTHOLE_WARN_RANGE, 0.6f)
                    if (h.distance <= HIT_DISTANCE) {
                        iterator.remove()
                        if (h.lane == steering.lane) {
                            sound.playSpatial("pothole_thud", pan = 0f, volume = 1.0f)
                            sound.vibrate(120)
                            if (drive.speed >= BURST_SPEED) {
                                if (crashReason == null) crashReason = "A tyre burst. You hit a pothole too fast."
                            } else {
                                drive.shock()
                            }
                        }
                    }
                }
                Kind.TREE -> {
                    beacon(h, dt, h.lane != steering.lane, WARN_RANGE, 1.0f)
                    if (h.distance <= HIT_DISTANCE) {
                        iterator.remove()
                        if (h.lane != steering.lane && crashReason == null) crashReason = "You hit a fallen tree."
                    }
                }
                Kind.ANIMAL -> {
                    h.leaveTimer -= dt
                    if (h.leaveTimer <= 0f) {
                        // It wanders off: one last, quieter call as it goes
                        playAnimal(h, 0.35f, 0.8f)
                        iterator.remove()
                    } else {
                        animalCalls(h, dt)
                        beacon(h, dt, h.lane == steering.lane, WARN_RANGE, 1.0f)
                        if (h.distance <= HIT_DISTANCE) {
                            iterator.remove()
                            if (h.lane == steering.lane && crashReason == null) crashReason = "You hit a ${h.animal}."
                        }
                    }
                }
                Kind.BEND -> {
                    if (!h.entered && h.distance <= 0f) {
                        h.entered = true
                        val slowEnough = drive.gear <= BEND_MAX_GEAR
                        val inLane = steering.lane == h.lane
                        if (slowEnough && inLane) {
                            sound.playSpatial("ui_select", pan = if (h.bendLeft) -0.5f else 0.5f, volume = 0.6f)
                            MyScreenReader.speak("Good turn.", flush = false)
                        } else {
                            sound.playSpatial("brake_screech", pan = 0f, volume = 1.0f)
                            if (crashReason == null) {
                                crashReason = if (!slowEnough) "You took the bend too fast and skidded off." else "You took the bend in the wrong lane."
                            }
                        }
                    }
                    if (h.distance < -h.length) iterator.remove()
                }
                Kind.BRIDGE -> {
                    if (bridgeAhead == null) bridgeAhead = h
                    if (h.distance <= 0f) {
                        if (!h.entered) {
                            h.entered = true
                            MyScreenReader.speak("On the bridge.", flush = false)
                        }
                        h.creakTimer -= dt
                        if (h.creakTimer <= 0f) {
                            sound.playSpatial("bridge_creak", pan = 0f, volume = 0.4f + 0.1f * drive.gear)
                            h.creakTimer = 2.8f
                        }
                        if (steering.lane != h.lane && crashReason == null) {
                            crashReason = "You drove off the bridge."
                            steering.forceLane(h.lane)
                        }
                        if (drive.gear > BRIDGE_MAX_GEAR && !h.cracked && crashReason == null) {
                            h.cracked = true
                            crashReason = "The bridge cracked. You went over it too fast."
                        }
                    }
                    if (h.distance < -h.length) {
                        iterator.remove()
                        bridgeAhead = null
                        MyScreenReader.speak("Across the bridge.", flush = false)
                    }
                }
            }
        }

        updateRiver(dt, bridgeAhead)

        val reason = crashReason
        if (reason != null) onCrash(reason)
    }

    /** Beeps like a parking sensor: faster and higher as the hazard nears. Low pitch means road damage. */
    private fun beacon(h: Hazard, dt: Float, active: Boolean, range: Float, basePitch: Float) {
        if (!active || h.distance >= range || h.distance <= 0f) return
        h.beepTimer -= dt
        if (h.beepTimer <= 0f) {
            val closeness = (1f - h.distance / range).coerceIn(0f, 1f)
            sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.45f * closeness, rate = basePitch + 0.7f * closeness)
            h.beepTimer = 0.10f + 0.45f * (1f - closeness)
        }
    }

    private fun animalCalls(h: Hazard, dt: Float) {
        h.callTimer -= dt
        if (h.callTimer <= 0f) {
            val closeness = (1f - h.distance / SPAWN_DISTANCE).coerceIn(0f, 1f)
            playAnimal(h, 0.25f + 0.75f * closeness * closeness, 1.0f)
            h.callTimer = 1.8f + Random.nextFloat() * 0.8f
        }
    }

    private fun playAnimal(h: Hazard, volume: Float, rate: Float) {
        val tag = when (h.animal) {
            "elephant" -> "elephant_call"
            "monkey" -> "monkey_call"
            "tiger" -> "tiger_roar"
            else -> "deer_call"
        }
        val pan = ((h.lane - steering.lane) * 0.85f).coerceIn(-1f, 1f)
        sound.playSpatial(tag, pan = pan, volume = volume.coerceIn(0f, 1f), rate = rate)
    }

    // ---------------------------------------------------------------- crash, goal

    private fun onCrash(reason: String) {
        sound.playSpatial("crash", pan = 0f, volume = 1.0f)
        sound.vibrate(300)
        lives -= 1
        drive.crashStop()
        // Clear what is right in front of you so you do not crash again at once
        hazards.removeAll { it.distance > 0f && it.distance < 45f }
        if (lives <= 0) {
            isOver = true
            overWon = false
            overTimer = GAME_OVER_SECONDS
            overText = "$reason Game over. You drove ${progress.toInt()} meters of ${GOAL_M.toInt()}."
            sound.stopEngine()
            stopAllLoops()
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("$reason $lives $word left. Tap the top edge to drive again.")
        }
    }

    private fun win() {
        isOver = true
        overWon = true
        overTimer = 4.5f
        overText = "You reached the village! The clinic gets its medicine in time. You finished with $lives ${if (lives == 1) "life" else "lives"} left."
        sound.stopEngine()
        stopAllLoops()
        sound.playSpatial("victory", pan = 0f, volume = 1.0f)
        MyScreenReader.speak("You reached the village!")
    }

    // ---------------------------------------------------------------- atmosphere

    private fun updateAtmosphere(dt: Float) {
        // rain from 2 kilometres, with thunder
        val rainTarget = if (progress >= RAIN_FROM_M) RAIN_VOLUME else 0f
        rainVolume += (rainTarget - rainVolume) * min(1f, dt * 0.5f)
        if (rainVolume > 0.02f) {
            if (rainStream == 0) {
                rainStream = sound.playLoop("rain_loop", 0f, rainVolume, 1.0f)
            } else {
                sound.updateStream(rainStream, 0f, rainVolume, 1.0f)
            }
        }
        if (progress >= RAIN_FROM_M) {
            if (!rainAnnounced) {
                rainAnnounced = true
                MyScreenReader.speak("It starts to rain.", flush = false)
            }
            thunderTimer -= dt
            if (thunderTimer <= 0f) {
                sound.playSpatial("thunder_roll", pan = (Random.nextFloat() - 0.5f) * 1.6f, volume = 0.7f)
                thunderTimer = 22f + Random.nextFloat() * 25f
            }
        }

        // owls hoot in the dark
        if (progress >= OWLS_FROM_M) {
            owlTimer -= dt
            if (owlTimer <= 0f) {
                sound.playSpatial("owl_hoot", pan = (Random.nextFloat() - 0.5f) * 1.8f, volume = 0.5f)
                owlTimer = 14f + Random.nextFloat() * 16f
            }
        }
    }

    /** The river gets louder as the bridge nears and stays while you cross it. */
    private fun updateRiver(dt: Float, bridge: Hazard?) {
        val target = if (bridge != null) {
            RIVER_VOLUME * (1f - (max(bridge.distance, 0f) / SPAWN_DISTANCE).coerceIn(0f, 1f))
        } else {
            0f
        }
        riverVolume += (target - riverVolume) * min(1f, dt * 2f)
        if (riverVolume > 0.02f) {
            if (riverStream == 0) {
                riverStream = sound.playLoop("river_loop", 0f, riverVolume, 1.0f)
            } else {
                sound.updateStream(riverStream, 0f, riverVolume, 1.0f)
            }
        } else if (riverStream != 0) {
            sound.stopStream(riverStream)
            riverStream = 0
        }
    }

    /** The dirt road under the wheels: louder and higher the faster you go. */
    private fun updateRoadNoise() {
        if (dirtStream == 0) return
        val fraction = (drive.speed / Drivetrain.TOP_SPEED).coerceIn(0f, 1f)
        sound.updateStream(dirtStream, 0f, DIRT_VOLUME * fraction, 0.8f + 0.4f * fraction)
    }

    private fun updateMilestonesAndHints(dt: Float) {
        if (progress >= nextMilestone && nextMilestone < GOAL_M) {
            val km = (nextMilestone / 1000f).toInt()
            val left = (GOAL_M / 1000f).toInt() - km
            MyScreenReader.speak("$km ${if (km == 1) "kilometre" else "kilometres"} done. $left to go.", flush = false)
            nextMilestone += 1000f
        }

        if (drive.gear == 0) {
            idleTimer += dt
            if (idleTimer > 14f) {
                idleTimer = 0f
                MyScreenReader.speak("Tap the top edge of the screen to drive.", flush = false)
            }
        } else {
            idleTimer = 0f
        }
    }
}
