package com.blindarena

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

// =========================================================================
// MODE 3: GUN FIGHT - 1 VS 1 DUEL (against a bot, offline)
// A warehouse arena (30 x 20 metres). You and the enemy both WALK around it.
//  - Swipe left / right: turn. Swipe up: walk forward. Swipe down: step back.
//    Keep your finger down after a swipe to keep turning or walking.
//  - Tap the middle: fire. Tap the bottom edge: reload. Tap the top edge: status.
// Footsteps tell you where the enemy is and how fast he moves. When he is in
// FRONT of you a tone beeps, faster the better you are lined up.
// First to 3 rounds wins the match.
// =========================================================================

class DuelWeapon(
    val name: String,
    val blurb: String,
    val soundTag: String,
    val reloadTag: String,
    val damage: Float,
    val magazine: Int,
    val cooldown: Float,
    val reloadSeconds: Float,
    val toleranceDeg: Float,
    val enemyAccuracy: Float,
    val enemyFireFactor: Float,
    val shotgun: Boolean
) {
    /** Shotguns hurt a lot up close and little from far away. */
    fun damageAt(distance: Float): Float {
        return if (shotgun) damage * (1.3f - distance / 10f).coerceIn(0.35f, 1.0f) else damage
    }
}

class DuelDifficulty(
    val name: String,
    val blurb: String,
    val reaction: Float,
    val fireGap: Float,
    val hitChance: Float,
    val damageScale: Float,
    val aimBonus: Float,
    val runChance: Float,
    val minDistance: Float,
    val maxDistance: Float,
    val enemyHealth: Float
)

val DUEL_WEAPONS = listOf(
    DuelWeapon(
        name = "Pistol", blurb = "fast and light, 12 bullets",
        soundTag = "gun_pistol", reloadTag = "reload_pistol",
        damage = 16f, magazine = 12, cooldown = 0.35f, reloadSeconds = 1.2f,
        toleranceDeg = 12f, enemyAccuracy = 1.0f, enemyFireFactor = 1.0f, shotgun = false
    ),
    DuelWeapon(
        name = "Assault rifle", blurb = "rapid fire, 30 bullets",
        soundTag = "gun_rifle", reloadTag = "reload_rifle",
        damage = 7f, magazine = 30, cooldown = 0.16f, reloadSeconds = 2.3f,
        toleranceDeg = 12f, enemyAccuracy = 0.9f, enemyFireFactor = 0.5f, shotgun = false
    ),
    DuelWeapon(
        name = "Shotgun", blurb = "huge damage up close, 6 shells",
        soundTag = "gun_shotgun", reloadTag = "reload_shotgun",
        damage = 42f, magazine = 6, cooldown = 0.9f, reloadSeconds = 1.85f,
        toleranceDeg = 18f, enemyAccuracy = 1.0f, enemyFireFactor = 1.0f, shotgun = true
    ),
    DuelWeapon(
        name = "Sniper rifle", blurb = "two hits kill, slow, 5 bullets",
        soundTag = "gun_sniper", reloadTag = "reload_rifle",
        damage = 60f, magazine = 5, cooldown = 1.3f, reloadSeconds = 2.3f,
        toleranceDeg = 8f, enemyAccuracy = 0.6f, enemyFireFactor = 1.0f, shotgun = false
    )
)

val DUEL_DIFFICULTIES = listOf(
    DuelDifficulty(
        name = "Easy", blurb = "weak enemy, often misses",
        reaction = 2.2f, fireGap = 1.6f, hitChance = 0.25f, damageScale = 0.7f, aimBonus = 1.5f, runChance = 0.25f, minDistance = 12f, maxDistance = 18f, enemyHealth = 100f
    ),
    DuelDifficulty(
        name = "Medium", blurb = "balanced",
        reaction = 1.4f, fireGap = 1.1f, hitChance = 0.48f, damageScale = 0.85f, aimBonus = 1.2f, runChance = 0.4f, minDistance = 8f, maxDistance = 14f, enemyHealth = 170f
    ),
    DuelDifficulty(
        name = "Hard", blurb = "tough, fast and deadly",
        reaction = 0.9f, fireGap = 0.75f, hitChance = 0.6f, damageScale = 1.0f, aimBonus = 1.0f, runChance = 0.55f, minDistance = 5f, maxDistance = 10f, enemyHealth = 260f
    )
)

const val MOVE_NONE = 0
const val MOVE_FORWARD = 1
const val MOVE_BACK = 2
const val MOVE_LEFT = 3
const val MOVE_RIGHT = 4

/** Taps and swipes seen by the touch handler, consumed by the game loop. */
class DuelControls {
    var fireQueued = false
    var reloadQueued = false
    var statusQueued = false
    var moveQueued = MOVE_NONE   // one swipe
    var moveHeld = MOVE_NONE     // the finger is still down after that swipe: keep going

    fun clear() {
        fireQueued = false
        reloadQueued = false
        statusQueued = false
        moveQueued = MOVE_NONE
    }
}

/** One match: rules, bot, sounds and speech. No Compose code in here. */
class GunDuel(
    private val sound: SoundManager,
    private val weapon: DuelWeapon,
    private val difficulty: DuelDifficulty,
    private val onMatchOver: (String, Boolean) -> Unit
) {
    private enum class Phase { INTRO, PREP, COUNTDOWN, FIGHT, ROUND_END, MATCH_END, DONE }

    companion object {
        const val WIN_ROUNDS = 3
        const val START_HEALTH = 100f
        const val LOW_HEALTH = 35f
        const val INTRO_SECONDS = 24f
        const val PREP_SECONDS = 1.5f
        const val COUNTDOWN_SECONDS = 4.0f
        const val ROUND_END_SECONDS = 4.0f
        const val MATCH_END_SECONDS = 5.0f
        const val AMBIENCE_VOLUME = 0.22f

        // the arena, in metres
        const val ARENA_W = 30f
        const val ARENA_H = 20f
        const val WALL_MARGIN = 0.6f

        // how the player moves
        const val STEP_LENGTH = 1.0f
        const val BACK_STEP_LENGTH = 0.7f
        const val STEP_INTERVAL = 0.32f
        const val STEP_HOLD_DELAY = 0.35f
        const val SINGLE_TURN_DEG = 10f
        const val TURN_HOLD_DELAY = 0.3f
    }

    // shown on screen
    var round: Int = 0
        private set
    var playerWins: Int = 0
        private set
    var enemyWins: Int = 0
        private set
    var playerHealth: Float = START_HEALTH
        private set
    var ammo: Int = 0
        private set

    val magazine: Int
        get() = weapon.magazine

    val phaseLabel: String
        get() = when (phase) {
            Phase.INTRO -> "TAP TO SKIP THE INSTRUCTIONS"
            Phase.PREP -> "GET READY"
            Phase.COUNTDOWN -> "3 - 2 - 1"
            Phase.FIGHT -> if (reloading) "RELOADING" else "FIGHT"
            Phase.ROUND_END -> "ROUND OVER"
            Phase.MATCH_END -> "MATCH OVER"
            Phase.DONE -> ""
        }

    val facing: String
        get() = compassName(heading)

    private var phase = Phase.INTRO
    private var phaseTimer = 0f

    // positions in metres: x grows to the east, y grows to the north. Heading: 0 = north, 90 = east
    private var px = 4f
    private var py = 10f
    private var heading = 90f
    private var enemyX = 26f
    private var enemyY = 10f

    private var enemyHealth = START_HEALTH
    private var moveTimer = 0f
    private var strafeDir = 1f
    private var desiredDistance = 10f
    private var running = false
    private var pauseTimer = 0f
    private var stepTimer = 0f
    private var lastStep = 0
    private var enemyFireTimer = 0f
    private var lockTimer = 0f

    private var holdTime = 0f
    private var stepCooldown = 0f
    private var sinceMove = 99f
    private var lastPlayerStep = 0

    private var reloading = false
    private var reloadLeft = 0f
    private var cooldownLeft = 0f

    private var playerWonMatch = false
    private var summaryText = ""

    private var ambienceStream = 0
    private var heartbeatStream = 0

    // ---------------------------------------------------------------- start / stop

    fun start(withIntro: Boolean) {
        round = 0
        playerWins = 0
        enemyWins = 0
        ensureAmbience()
        if (withIntro) {
            phase = Phase.INTRO
            phaseTimer = INTRO_SECONDS
            MyScreenReader.speak(
                "${weapon.name}, ${difficulty.name}. First to $WIN_ROUNDS rounds wins. " +
                    "Swipe left or right to turn. Swipe up to walk forward, swipe down to step back. " +
                    "Keep your finger down after a swipe to keep going. " +
                    "Listen for the enemy's footsteps. When he is in front of you a tone beeps, faster when you line up. " +
                    "Tap the middle of the screen to fire. Tap the bottom edge to reload. Tap the top edge for health and ammo. " +
                    "Tap now to skip this."
            )
        } else {
            phase = Phase.INTRO
            phaseTimer = 0.05f
        }
    }

    fun shutdown() {
        stopHeartbeat()
        sound.stopStream(ambienceStream)
        ambienceStream = 0
        phase = Phase.DONE
    }

    private fun ensureAmbience() {
        if (ambienceStream == 0) {
            ambienceStream = sound.playLoop("warehouse_loop", 0f, AMBIENCE_VOLUME, 1.0f)
        }
    }

    private fun stopHeartbeat() {
        sound.stopStream(heartbeatStream)
        heartbeatStream = 0
    }

    // ---------------------------------------------------------------- main loop

    fun tick(dt: Float, controls: DuelControls) {
        if (phase == Phase.DONE) return
        ensureAmbience()
        phaseTimer -= dt
        sinceMove += dt

        when (phase) {
            Phase.INTRO -> {
                // a tap skips the spoken instructions
                if (controls.fireQueued || controls.reloadQueued || controls.statusQueued) phaseTimer = 0f
                controls.clear()
                if (phaseTimer <= 0f) beginRound()
            }
            Phase.PREP -> {
                controls.clear()
                if (phaseTimer <= 0f) {
                    phase = Phase.COUNTDOWN
                    phaseTimer = COUNTDOWN_SECONDS
                    sound.playSpatial("fight_countdown", pan = 0f, volume = 1.0f)
                }
            }
            Phase.COUNTDOWN -> {
                // you may already turn and walk while the countdown runs
                handleMovement(dt, controls)
                controls.fireQueued = false
                controls.reloadQueued = false
                controls.statusQueued = false
                if (phaseTimer <= 0f) {
                    phase = Phase.FIGHT
                    enemyFireTimer = difficulty.reaction
                    lockTimer = 0f
                }
            }
            Phase.FIGHT -> fightTick(dt, controls)
            Phase.ROUND_END -> {
                controls.clear()
                if (phaseTimer <= 0f) afterRound()
            }
            Phase.MATCH_END -> {
                controls.clear()
                if (phaseTimer <= 0f) {
                    phase = Phase.DONE
                    stopHeartbeat()
                    onMatchOver(summaryText, playerWonMatch)
                }
            }
            Phase.DONE -> {
            }
        }
    }

    private fun beginRound() {
        round += 1
        playerHealth = START_HEALTH
        enemyHealth = difficulty.enemyHealth
        ammo = weapon.magazine
        reloading = false
        reloadLeft = 0f
        cooldownLeft = 0f

        // You start on the west side facing a random direction, the enemy somewhere on the east side
        px = 4f
        py = 8f + Random.nextFloat() * 4f
        heading = (Random.nextInt(8) * 45).toFloat()
        enemyX = 20f + Random.nextFloat() * 7f
        enemyY = 3f + Random.nextFloat() * 14f
        desiredDistance = difficulty.minDistance + Random.nextFloat() * (difficulty.maxDistance - difficulty.minDistance)
        moveTimer = 0f
        strafeDir = 1f
        running = false
        pauseTimer = 0f
        stepTimer = 0.3f
        holdTime = 0f
        stepCooldown = 0f
        sinceMove = 99f

        phase = Phase.PREP
        phaseTimer = PREP_SECONDS
        val score = if (round == 1) "" else " You $playerWins, enemy $enemyWins."
        MyScreenReader.speak("Round $round.$score You are facing ${compassName(heading)}.")
    }

    private fun fightTick(dt: Float, controls: DuelControls) {
        cooldownLeft = max(0f, cooldownLeft - dt)
        if (reloading) {
            reloadLeft -= dt
            if (reloadLeft <= 0f) {
                reloading = false
                ammo = weapon.magazine
            }
        }

        handleMovement(dt, controls)

        if (controls.statusQueued) {
            controls.statusQueued = false
            speakStatus()
        }
        if (controls.reloadQueued) {
            controls.reloadQueued = false
            startReload()
        }
        if (controls.fireQueued) {
            controls.fireQueued = false
            fire()
        }
        if (phase != Phase.FIGHT) return // a shot may have just ended the round

        moveEnemy(dt)
        lockTone(dt)
        enemyShooting(dt)
        updateHeartbeat()
    }

    // ---------------------------------------------------------------- the player walks and turns

    private fun handleMovement(dt: Float, controls: DuelControls) {
        stepCooldown = max(0f, stepCooldown - dt)

        val queued = controls.moveQueued
        controls.moveQueued = MOVE_NONE

        if (queued != MOVE_NONE) {
            holdTime = 0f
            discreteMove(queued)
            stepCooldown = STEP_INTERVAL
        } else if (controls.moveHeld != MOVE_NONE) {
            holdTime += dt
            val held = controls.moveHeld
            if (held == MOVE_LEFT || held == MOVE_RIGHT) {
                if (holdTime > TURN_HOLD_DELAY) {
                    val rate = if (holdTime < 1.4f) 60f else 110f
                    turnBy((if (held == MOVE_LEFT) -1f else 1f) * rate * dt)
                }
            } else if (holdTime > STEP_HOLD_DELAY && stepCooldown <= 0f) {
                discreteMove(held)
                stepCooldown = STEP_INTERVAL
            }
        } else {
            holdTime = 0f
        }
    }

    private fun discreteMove(move: Int) {
        when (move) {
            MOVE_FORWARD -> walk(STEP_LENGTH)
            MOVE_BACK -> walk(-BACK_STEP_LENGTH)
            MOVE_LEFT -> turnBy(-SINGLE_TURN_DEG)
            MOVE_RIGHT -> turnBy(SINGLE_TURN_DEG)
        }
    }

    private fun turnBy(delta: Float) {
        val old = heading
        var h = (heading + delta) % 360f
        if (h < 0f) h += 360f
        heading = h

        // A soft tick every 15 degrees and a clear click when you pass north, east, south or west
        val oldSector = Math.floor((old / 90f).toDouble()).toInt()
        val newSector = Math.floor((h / 90f).toDouble()).toInt()
        val oldCell = Math.floor((old / 15f).toDouble()).toInt()
        val newCell = Math.floor((h / 15f).toDouble()).toInt()
        if (oldSector != newSector) {
            sound.playSpatial("ui_detent", pan = 0f, volume = 0.9f)
        } else if (oldCell != newCell) {
            sound.playSpatial("ui_tick", pan = 0f, volume = 0.6f)
        }
    }

    private fun walk(distance: Float) {
        val radians = Math.toRadians(heading.toDouble())
        val nx = px + (sin(radians) * distance).toFloat()
        val ny = py + (cos(radians) * distance).toFloat()
        val cx = nx.coerceIn(WALL_MARGIN, ARENA_W - WALL_MARGIN)
        val cy = ny.coerceIn(WALL_MARGIN, ARENA_H - WALL_MARGIN)
        val hitWall = cx != nx || cy != ny

        // you cannot walk through the enemy
        val ex = enemyX - cx
        val ey = enemyY - cy
        val blockedByEnemy = sqrt(ex * ex + ey * ey) < 1.2f

        if (blockedByEnemy) {
            sound.playSpatial("wall_thud", pan = 0f, volume = 0.7f, rate = 1.3f)
            sound.vibrate(40)
            return
        }

        px = cx
        py = cy
        sinceMove = 0f
        if (hitWall) {
            sound.playSpatial("wall_thud", pan = 0f, volume = 0.9f)
            sound.vibrate(50)
        } else {
            var index = Random.nextInt(3) + 1
            if (index == lastPlayerStep) index = index % 3 + 1
            lastPlayerStep = index
            sound.playSpatial("step_$index", pan = 0f, volume = 0.5f, rate = if (distance < 0f) 0.9f else 1.0f)
        }
    }

    // ---------------------------------------------------------------- where the enemy is, and how it sounds

    private fun enemyDistance(): Float {
        val dx = enemyX - px
        val dy = enemyY - py
        return max(0.5f, sqrt(dx * dx + dy * dy))
    }

    /** Angle of the enemy relative to where you face: 0 = straight ahead, +90 = right, -90 = left, 180 = behind. */
    private fun relAngle(): Float {
        val dx = enemyX - px
        val dy = enemyY - py
        val bearing = Math.toDegrees(atan2(dx.toDouble(), dy.toDouble())).toFloat()
        var d = (bearing - heading) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    /** Closer enemies are easier to hit: the angle you may be off by grows when he is near and shrinks when he is far. */
    private fun aimTolerance(distance: Float): Float {
        return weapon.toleranceDeg * difficulty.aimBonus * (10f / distance).coerceIn(0.6f, 1.5f)
    }

    private fun playAt(tag: String, rel: Float, distance: Float, range: Float, baseVolume: Float, rate: Float) {
        val radians = Math.toRadians(rel.toDouble())
        val pan = sin(radians).toFloat()
        var volume = (1.1f - distance / range).coerceIn(0f, 1f) * baseVolume
        var pitch = rate
        if (cos(radians) < 0.0) {
            // Behind you: quieter and a little duller
            volume *= 0.65f
            pitch *= 0.92f
        }
        if (volume < 0.03f) return
        sound.playSpatial(tag, pan = pan, volume = volume.coerceIn(0f, 1f), rate = pitch)
    }

    // ---------------------------------------------------------------- the bot

    private fun moveEnemy(dt: Float) {
        if (pauseTimer > 0f) {
            pauseTimer -= dt
            return
        }
        moveTimer -= dt
        if (moveTimer <= 0f) {
            strafeDir = if (Random.nextBoolean()) 1f else -1f
            running = Random.nextFloat() < difficulty.runChance
            moveTimer = 1.2f + Random.nextFloat() * 1.8f
            desiredDistance = difficulty.minDistance + Random.nextFloat() * (difficulty.maxDistance - difficulty.minDistance)
        }

        val dx = px - enemyX
        val dy = py - enemyY
        val dist = max(0.1f, sqrt(dx * dx + dy * dy))
        val ux = dx / dist // unit vector from the enemy towards you
        val uy = dy / dist
        val speed = if (running) 3.4f else 1.6f

        // He walks towards you when he is too far, backs off when too close, and strafes sideways all the time
        val radial = if (dist > desiredDistance + 1.5f) 1f else if (dist < desiredDistance - 1.5f) -1f else 0f
        var mx = ux * radial + (-uy * strafeDir) * 0.8f
        var my = uy * radial + (ux * strafeDir) * 0.8f
        val len = sqrt(mx * mx + my * my)
        if (len > 0.01f) {
            mx /= len
            my /= len
        }
        enemyX = (enemyX + mx * speed * dt).coerceIn(WALL_MARGIN, ARENA_W - WALL_MARGIN)
        enemyY = (enemyY + my * speed * dt).coerceIn(WALL_MARGIN, ARENA_H - WALL_MARGIN)

        // Slow footsteps when walking, quick and a bit higher when running
        stepTimer -= dt
        if (stepTimer <= 0f) {
            var index = Random.nextInt(3) + 1
            if (index == lastStep) index = index % 3 + 1
            lastStep = index
            val rate = if (running) 1.2f + Random.nextFloat() * 0.1f else 0.95f + Random.nextFloat() * 0.1f
            val volume = if (running) 1.0f else 0.8f
            playAt("step_$index", relAngle(), enemyDistance(), 22f, volume, rate)
            stepTimer = if (running) 0.36f else 0.74f
        }
    }

    private fun lockTone(dt: Float) {
        lockTimer -= dt
        val offTarget = abs(relAngle())
        val tolerance = aimTolerance(enemyDistance())
        if (offTarget <= tolerance && lockTimer <= 0f) {
            val closeness = 1f - offTarget / tolerance
            sound.playSpatial("lock_tone", pan = 0f, volume = 0.7f, rate = 0.9f + 0.5f * closeness)
            lockTimer = 0.32f - 0.16f * closeness
        }
    }

    private fun enemyShooting(dt: Float) {
        enemyFireTimer -= dt
        if (enemyFireTimer > 0f) return

        val baseGap = if (weapon.enemyFireFactor < 1f) {
            difficulty.fireGap * weapon.enemyFireFactor // automatic weapons: quick bursts
        } else {
            max(difficulty.fireGap, weapon.cooldown * 1.5f)
        }
        enemyFireTimer = baseGap * (0.8f + Random.nextFloat() * 0.5f)
        pauseTimer = minOf(0.35f, enemyFireTimer * 0.8f) // he stands still to shoot

        val rel = relAngle()
        val distance = enemyDistance()
        playAt(weapon.soundTag, rel, distance, 45f, 0.95f, 0.95f)

        // Far shots miss more, and a moving target is harder to hit
        var chance = difficulty.hitChance * weapon.enemyAccuracy * (1.3f - distance / 30f).coerceIn(0.5f, 1.1f)
        if (sinceMove < 0.8f) chance *= 0.75f
        if (weapon.shotgun) chance *= (1.4f - distance / 10f).coerceIn(0.4f, 1.2f)

        if (Random.nextFloat() < chance) {
            hurtPlayer(weapon.damageAt(distance) * difficulty.damageScale)
        } else {
            // A miss: you hear the bullet fly past on his side
            playAt("bullet_whiz", rel + (Random.nextFloat() - 0.5f) * 40f, max(4f, distance * 0.5f), 45f, 1.0f, 1.0f)
        }
    }

    private fun hurtPlayer(damage: Float) {
        val before = playerHealth
        playerHealth = max(0f, playerHealth - damage)
        sound.playSpatial("body_hit", pan = 0f, volume = 0.9f)
        sound.vibrate(150)
        if (playerHealth <= 0f) {
            playerDown()
            return
        }
        val crossedTwoThirds = before > 66f && playerHealth <= 66f
        val crossedOneThird = before > 33f && playerHealth <= 33f
        if (crossedTwoThirds || crossedOneThird) {
            MyScreenReader.speak("Health ${playerHealth.toInt()}.", flush = false)
        }
    }

    private fun updateHeartbeat() {
        if (phase == Phase.FIGHT && playerHealth < LOW_HEALTH) {
            val danger = 1f - playerHealth / LOW_HEALTH
            val volume = 0.35f + 0.65f * danger
            val rate = 1.0f + 0.4f * danger
            if (heartbeatStream == 0) {
                heartbeatStream = sound.playLoop("heartbeat", 0f, volume, rate)
            } else {
                sound.updateStream(heartbeatStream, 0f, volume, rate)
            }
        } else {
            stopHeartbeat()
        }
    }

    // ---------------------------------------------------------------- the player's weapon

    private fun fire() {
        if (phase != Phase.FIGHT) return
        if (reloading || cooldownLeft > 0f) {
            if (reloading) sound.playSpatial("gun_empty", pan = 0f, volume = 0.5f)
            return
        }
        if (ammo <= 0) {
            sound.playSpatial("gun_empty", pan = 0f, volume = 0.9f)
            startReload()
            return
        }

        ammo -= 1
        cooldownLeft = weapon.cooldown
        sound.playSpatial(weapon.soundTag, pan = 0f, volume = 1.0f)
        sound.vibrate(40)

        val rel = relAngle()
        val distance = enemyDistance()
        if (abs(rel) <= aimTolerance(distance)) {
            enemyHealth -= weapon.damageAt(distance)
            playAt("body_hit", rel, distance, 45f, 1.0f, 1.0f)
            if (enemyHealth <= 0f) {
                enemyDown()
                return
            }
        }
        if (ammo == 0) MyScreenReader.speak("Empty. Tap again to reload.", flush = false)
    }

    private fun startReload() {
        if (phase != Phase.FIGHT || reloading || ammo >= weapon.magazine) return
        reloading = true
        reloadLeft = weapon.reloadSeconds
        sound.playSpatial(weapon.reloadTag, pan = 0f, volume = 0.9f)
    }

    private fun speakStatus() {
        val reloadText = if (reloading) ", reloading" else ""
        MyScreenReader.speak(
            "Health ${playerHealth.toInt()}. Ammo $ammo of ${weapon.magazine}$reloadText. " +
                "Facing ${compassName(heading)}. You $playerWins, enemy $enemyWins."
        )
    }

    // ---------------------------------------------------------------- round and match end

    private fun enemyDown() {
        playerWins += 1
        stopHeartbeat()
        playAt("death", relAngle(), enemyDistance(), 45f, 1.0f, 0.85f)
        phase = Phase.ROUND_END
        phaseTimer = ROUND_END_SECONDS
        MyScreenReader.speak("Enemy down! You win the round. You $playerWins, enemy $enemyWins.")
    }

    private fun playerDown() {
        enemyWins += 1
        stopHeartbeat()
        sound.playSpatial("death", pan = 0f, volume = 1.0f)
        phase = Phase.ROUND_END
        phaseTimer = ROUND_END_SECONDS
        MyScreenReader.speak("You are down. The enemy wins the round. You $playerWins, enemy $enemyWins.")
    }

    private fun afterRound() {
        if (playerWins >= WIN_ROUNDS || enemyWins >= WIN_ROUNDS) {
            endMatch()
        } else {
            beginRound()
        }
    }

    private fun endMatch() {
        playerWonMatch = playerWins > enemyWins
        stopHeartbeat()
        if (playerWonMatch) {
            sound.playSpatial("victory", pan = 0f, volume = 1.0f)
            summaryText = "You win the match, $playerWins to $enemyWins!"
        } else {
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
            summaryText = "You lost the match, $playerWins to $enemyWins."
        }
        MyScreenReader.speak(summaryText)
        phase = Phase.MATCH_END
        phaseTimer = MATCH_END_SECONDS
    }
}

/** Compass direction for a heading in degrees (0 = north, 90 = east). */
fun compassName(degrees: Float): String {
    val names = listOf("north", "north east", "east", "south east", "south", "south west", "west", "north west")
    val index = (Math.round(degrees / 45f) % 8 + 8) % 8
    return names[index]
}

/** Weapon, difficulty and end-of-match menus. They use the app's own screen reader, like Hand Cricket. */
class GunDuelController(
    private val sound: SoundManager,
    private val onExit: () -> Unit
) {
    var game by mutableStateOf<GunDuel?>(null)
    var title by mutableStateOf("GUN FIGHT")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    private var weapon: DuelWeapon = DUEL_WEAPONS[0]
    private var difficulty: DuelDifficulty = DUEL_DIFFICULTIES[1]
    private var introShown = false
    private var lastChangeMs = 0L

    fun begin() {
        showWeapons()
    }

    fun shutdown() {
        game?.shutdown()
        game = null
    }

    private fun tooSoon(): Boolean = System.currentTimeMillis() - lastChangeMs < 800L

    private fun say(text: String, help: String) {
        MyScreenReader.currentHelpContext = help
        MyScreenReader.speak(text)
    }

    private fun setItems(items: List<MyScreenReader.FocusItem>) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        lastChangeMs = System.currentTimeMillis()
        // Nothing focused yet: the first swipe reads the first option and a stray double tap does nothing
        if (items.isNotEmpty()) MyScreenReader.currentFocusIndex.value = -1
    }

    private fun showWeapons() {
        game = null
        title = "GUN FIGHT - 1 VS 1 DUEL"
        line1 = "Choose your weapon"
        line2 = "Swipe left or right, double tap to select"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (w in DUEL_WEAPONS) {
            items.add(MyScreenReader.FocusItem("weapon_${w.name}", w.name, w.blurb, "") { chooseWeapon(w) })
        }
        setItems(items)
        say(
            "Gun Fight, one versus one duel. Choose your weapon. Swipe right or left to hear the options, then double tap to select. " +
                "The back gesture returns to the menu.",
            "Swipe right or left to hear the weapons, then double tap to select."
        )
    }

    private fun chooseWeapon(w: DuelWeapon) {
        if (tooSoon()) return
        weapon = w
        showDifficulty()
    }

    private fun showDifficulty() {
        line1 = "Choose difficulty"
        line2 = weapon.name
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (d in DUEL_DIFFICULTIES) {
            items.add(MyScreenReader.FocusItem("difficulty_${d.name}", d.name, d.blurb, "") { chooseDifficulty(d) })
        }
        setItems(items)
        say(
            "${weapon.name} selected. Now choose the difficulty. Swipe to hear the options, then double tap.",
            "Swipe to hear the difficulty levels, then double tap to select."
        )
    }

    private fun chooseDifficulty(d: DuelDifficulty) {
        if (tooSoon()) return
        difficulty = d
        startMatch()
    }

    private fun startMatch() {
        MyScreenReader.clearItems()
        title = "1 VS 1 DUEL"
        val g = GunDuel(sound, weapon, difficulty) { text, won -> onMatchOver(text, won) }
        game = g
        g.start(!introShown)
        introShown = true
    }

    private fun onMatchOver(text: String, won: Boolean) {
        game?.shutdown()
        game = null
        showEnd(text, won)
    }

    private fun showEnd(text: String, won: Boolean) {
        title = if (won) "YOU WIN" else "YOU LOST"
        line1 = text
        line2 = "${weapon.name}, ${difficulty.name}"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("duel_again", "Play again", "same weapon and difficulty", "") { if (!tooSoon()) startMatch() })
        items.add(MyScreenReader.FocusItem("duel_change", "Change weapon", "button", "") { if (!tooSoon()) showWeapons() })
        items.add(MyScreenReader.FocusItem("duel_menu", "Main menu", "button", "") { if (!tooSoon()) onExit() })
        setItems(items)
        say("$text Swipe to choose Play again, Change weapon or Main menu.", "Swipe to choose, then double tap.")
    }
}

/**
 * Swipe left / right = turn, swipe up = walk forward, swipe down = step back (keep the finger down to keep going).
 * A quick tap: middle of the screen fires, bottom edge reloads, top edge tells health and ammo.
 */
private fun Modifier.duelTouchControls(controls: DuelControls): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        awaitEachGesture {
            val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
            val startX = down.position.x
            val startY = down.position.y
            val downTime = System.currentTimeMillis()
            val minSwipe = maxOf(70f, size.width * 0.08f)
            var swiped = false

            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val change = event.changes.firstOrNull()

                if (!swiped && change != null && change.pressed) {
                    val dx = change.position.x - startX
                    val dy = change.position.y - startY
                    var move = MOVE_NONE
                    if (abs(dx) >= minSwipe && abs(dx) >= abs(dy)) {
                        move = if (dx > 0f) MOVE_RIGHT else MOVE_LEFT
                    } else if (abs(dy) >= minSwipe && abs(dy) > abs(dx)) {
                        move = if (dy < 0f) MOVE_FORWARD else MOVE_BACK
                    }
                    if (move != MOVE_NONE) {
                        swiped = true
                        controls.moveQueued = move
                        controls.moveHeld = move
                    }
                }

                if (event.changes.all { !it.pressed }) {
                    controls.moveHeld = MOVE_NONE
                    if (!swiped && System.currentTimeMillis() - downTime < 500L) {
                        val fraction = startY / size.height.toFloat()
                        if (fraction < 0.18f) {
                            controls.statusQueued = true
                        } else if (fraction > 0.82f) {
                            controls.reloadQueued = true
                        } else {
                            controls.fireQueued = true
                        }
                    }
                    break
                }
            }
        }
    }

@Composable
fun GunDuelScreen(soundManager: SoundManager, paused: Boolean, onBack: () -> Unit) {
    val controller = remember { GunDuelController(soundManager, onBack) }
    val controls = remember { DuelControls() }
    var uiTick by remember { mutableStateOf(0) }
    val isPaused by rememberUpdatedState(paused)
    var backPressedAt by remember { mutableStateOf(0L) }

    // Swiping near the screen edge can look like a back gesture, so during a match ask twice before leaving
    BackHandler(enabled = controller.game != null) {
        val now = System.currentTimeMillis()
        if (now - backPressedAt < 2500L) {
            soundManager.playSpatial("ui_back", pan = 0f, volume = 0.9f)
            onBack()
        } else {
            backPressedAt = now
            MyScreenReader.speak("Do the back gesture again to leave the match.")
        }
    }

    LaunchedEffect(Unit) {
        controller.begin()
    }

    DisposableEffect(Unit) {
        onDispose { controller.shutdown() }
    }

    val game = controller.game

    LaunchedEffect(game) {
        if (game == null) return@LaunchedEffect
        var last = System.nanoTime()
        var counter = 0
        while (true) {
            delay(30)
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            if (isPaused) continue
            game.tick(dt, controls)
            counter++
            if (counter % 5 == 0) uiTick++
        }
    }

    val refresh = uiTick

    if (game == null) {
        val spoken = MyScreenReader.currentSpokenTextState.value
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .myScreenReaderGestures()
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(controller.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(controller.line1, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text(controller.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
                }
                Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
                Text(
                    "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture returns to the menu.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .duelTouchControls(controls)
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text("ROUND ${game.round}   You ${game.playerWins} - ${game.enemyWins} Enemy", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(game.phaseLabel, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                    Text("Health ${game.playerHealth.toInt()}   Facing ${game.facing}", fontSize = 22.sp, color = Color(0xFF4ADE80))
                    Text("Ammo ${game.ammo} / ${game.magazine}", fontSize = 22.sp, color = Color(0xFFFBBF24))
                }
                Text(
                    "Swipe left or right to turn, up to walk, down to step back. Tap the middle to fire, bottom edge to reload, top edge for status. Back gesture twice leaves the match.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}
