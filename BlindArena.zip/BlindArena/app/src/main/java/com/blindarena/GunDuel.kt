package com.blindarena

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.random.Random

// =========================================================================
// MODE 3: GUN FIGHT - 1 VS 1 DUEL (against a bot, offline)
// You stand in the middle of a warehouse. The enemy walks or runs around you.
// Turn your body (the phone's compass) to face the sounds: footsteps tell you
// where he is and how fast he moves. When he is in FRONT of you a tone beeps,
// faster the better you are lined up. Tap the middle of the screen to fire,
// the bottom edge to reload, the top edge to hear health and ammo.
// First to 3 rounds wins the match.
// =========================================================================

class DuelWeapon(
    val name: String,
    val blurb: String,
    val soundTag: String,
    val reloadTag: String,
    val damage: Float,
    val magazine: Int,
    val cooldown: Float,
    val reloadSeconds: Float,
    val toleranceDeg: Float,
    val enemyAccuracy: Float,
    val enemyFireFactor: Float,
    val shotgun: Boolean
) {
    /** Shotguns hurt a lot up close and little from far away. */
    fun damageAt(distance: Float): Float {
        return if (shotgun) damage * (1.3f - distance / 10f).coerceIn(0.35f, 1.0f) else damage
    }
}

class DuelDifficulty(
    val name: String,
    val blurb: String,
    val reaction: Float,
    val fireGap: Float,
    val hitChance: Float,
    val damageScale: Float,
    val aimBonus: Float,
    val runChance: Float
)

val DUEL_WEAPONS = listOf(
    DuelWeapon(
        name = "Pistol", blurb = "fast and light, 12 bullets",
        soundTag = "gun_pistol", reloadTag = "reload_pistol",
        damage = 16f, magazine = 12, cooldown = 0.35f, reloadSeconds = 1.2f,
        toleranceDeg = 9f, enemyAccuracy = 1.0f, enemyFireFactor = 1.0f, shotgun = false
    ),
    DuelWeapon(
        name = "Assault rifle", blurb = "rapid fire, 30 bullets",
        soundTag = "gun_rifle", reloadTag = "reload_rifle",
        damage = 9f, magazine = 30, cooldown = 0.16f, reloadSeconds = 2.3f,
        toleranceDeg = 9f, enemyAccuracy = 0.9f, enemyFireFactor = 0.5f, shotgun = false
    ),
    DuelWeapon(
        name = "Shotgun", blurb = "huge damage up close, 6 shells",
        soundTag = "gun_shotgun", reloadTag = "reload_shotgun",
        damage = 42f, magazine = 6, cooldown = 0.9f, reloadSeconds = 1.85f,
        toleranceDeg = 14f, enemyAccuracy = 1.0f, enemyFireFactor = 1.0f, shotgun = true
    ),
    DuelWeapon(
        name = "Sniper rifle", blurb = "two hits kill, slow, 5 bullets",
        soundTag = "gun_sniper", reloadTag = "reload_rifle",
        damage = 60f, magazine = 5, cooldown = 1.3f, reloadSeconds = 2.3f,
        toleranceDeg = 7f, enemyAccuracy = 0.6f, enemyFireFactor = 1.0f, shotgun = false
    )
)

val DUEL_DIFFICULTIES = listOf(
    DuelDifficulty(
        name = "Easy", blurb = "slow enemy, often misses",
        reaction = 2.2f, fireGap = 1.6f, hitChance = 0.25f, damageScale = 0.7f, aimBonus = 1.5f, runChance = 0.25f
    ),
    DuelDifficulty(
        name = "Medium", blurb = "balanced",
        reaction = 1.4f, fireGap = 1.1f, hitChance = 0.48f, damageScale = 0.85f, aimBonus = 1.2f, runChance = 0.4f
    ),
    DuelDifficulty(
        name = "Hard", blurb = "fast and deadly",
        reaction = 0.9f, fireGap = 0.75f, hitChance = 0.6f, damageScale = 1.0f, aimBonus = 1.0f, runChance = 0.55f
    )
)

/** Taps seen by the touch handler, consumed by the game loop. */
class DuelControls {
    var fireQueued = false
    var reloadQueued = false
    var statusQueued = false

    fun clear() {
        fireQueued = false
        reloadQueued = false
        statusQueued = false
    }
}

/** One match: rules, bot, sounds and speech. No Compose code in here. */
class GunDuel(
    private val sound: SoundManager,
    private val weapon: DuelWeapon,
    private val difficulty: DuelDifficulty,
    private val onMatchOver: (String, Boolean) -> Unit
) {
    private enum class Phase { INTRO, PREP, COUNTDOWN, FIGHT, ROUND_END, MATCH_END, DONE }

    companion object {
        const val WIN_ROUNDS = 3
        const val START_HEALTH = 100f
        const val LOW_HEALTH = 35f
        const val INTRO_SECONDS = 11f
        const val PREP_SECONDS = 1.3f
        const val COUNTDOWN_SECONDS = 4.0f
        const val ROUND_END_SECONDS = 4.0f
        const val MATCH_END_SECONDS = 5.0f
        const val MIN_DISTANCE = 4f
        const val MAX_DISTANCE = 12f
        const val AMBIENCE_VOLUME = 0.22f
    }

    // shown on screen
    var round: Int = 0
        private set
    var playerWins: Int = 0
        private set
    var enemyWins: Int = 0
        private set
    var playerHealth: Float = START_HEALTH
        private set
    var ammo: Int = 0
        private set

    val magazine: Int
        get() = weapon.magazine

    val phaseLabel: String
        get() = when (phase) {
            Phase.INTRO -> "LISTEN TO THE INSTRUCTIONS"
            Phase.PREP -> "GET READY"
            Phase.COUNTDOWN -> "3 - 2 - 1"
            Phase.FIGHT -> if (reloading) "RELOADING" else "FIGHT"
            Phase.ROUND_END -> "ROUND OVER"
            Phase.MATCH_END -> "MATCH OVER"
            Phase.DONE -> ""
        }

    private var phase = Phase.INTRO
    private var phaseTimer = 0f
    private var heading = 0f

    private var enemyHealth = START_HEALTH
    private var enemyBearing = 0f
    private var enemyDistance = 8f
    private var moveTimer = 0f
    private var moveDir = 1f
    private var radial = 0f
    private var running = false
    private var pauseTimer = 0f
    private var stepTimer = 0f
    private var lastStep = 0
    private var enemyFireTimer = 0f
    private var lockTimer = 0f

    private var reloading = false
    private var reloadLeft = 0f
    private var cooldownLeft = 0f

    private var playerWonMatch = false
    private var summaryText = ""

    private var ambienceStream = 0
    private var heartbeatStream = 0

    // ---------------------------------------------------------------- start / stop

    fun start(withIntro: Boolean) {
        round = 0
        playerWins = 0
        enemyWins = 0
        ensureAmbience()
        if (withIntro) {
            phase = Phase.INTRO
            phaseTimer = INTRO_SECONDS
            MyScreenReader.speak(
                "${weapon.name}, ${difficulty.name}. First to $WIN_ROUNDS rounds wins. " +
                    "Turn your body to face the enemy's footsteps. When he is in front of you a tone beeps, faster when you line up. " +
                    "Tap the middle of the screen to fire. Tap the bottom edge to reload. Tap the top edge for health and ammo."
            )
        } else {
            // The first tick passes the real compass heading, so the enemy is placed relative to where you really face
            phase = Phase.INTRO
            phaseTimer = 0.05f
        }
    }

    fun shutdown() {
        stopHeartbeat()
        sound.stopStream(ambienceStream)
        ambienceStream = 0
        phase = Phase.DONE
    }

    private fun ensureAmbience() {
        if (ambienceStream == 0) {
            ambienceStream = sound.playLoop("warehouse_loop", 0f, AMBIENCE_VOLUME, 1.0f)
        }
    }

    private fun stopHeartbeat() {
        sound.stopStream(heartbeatStream)
        heartbeatStream = 0
    }

    // ---------------------------------------------------------------- main loop

    fun tick(dt: Float, headingDeg: Float, controls: DuelControls) {
        heading = headingDeg
        if (phase == Phase.DONE) return
        ensureAmbience()
        phaseTimer -= dt

        when (phase) {
            Phase.INTRO -> {
                controls.clear()
                if (phaseTimer <= 0f) beginRound()
            }
            Phase.PREP -> {
                controls.clear()
                if (phaseTimer <= 0f) {
                    phase = Phase.COUNTDOWN
                    phaseTimer = COUNTDOWN_SECONDS
                    sound.playSpatial("fight_countdown", pan = 0f, volume = 1.0f)
                }
            }
            Phase.COUNTDOWN -> {
                controls.clear()
                if (phaseTimer <= 0f) {
                    phase = Phase.FIGHT
                    enemyFireTimer = difficulty.reaction
                    lockTimer = 0f
                }
            }
            Phase.FIGHT -> fightTick(dt, controls)
            Phase.ROUND_END -> {
                controls.clear()
                if (phaseTimer <= 0f) afterRound()
            }
            Phase.MATCH_END -> {
                controls.clear()
                if (phaseTimer <= 0f) {
                    phase = Phase.DONE
                    stopHeartbeat()
                    onMatchOver(summaryText, playerWonMatch)
                }
            }
            Phase.DONE -> {
            }
        }
    }

    private fun beginRound() {
        round += 1
        playerHealth = START_HEALTH
        enemyHealth = START_HEALTH
        ammo = weapon.magazine
        reloading = false
        reloadLeft = 0f
        cooldownLeft = 0f

        // The enemy starts beside or behind you, so you have to find him by ear
        val side = if (Random.nextBoolean()) 1f else -1f
        enemyBearing = heading + side * (70f + Random.nextFloat() * 80f)
        enemyDistance = 6f + Random.nextFloat() * 4f
        moveTimer = 0f
        moveDir = 1f
        radial = 0f
        running = false
        pauseTimer = 0f
        stepTimer = 0.3f

        phase = Phase.PREP
        phaseTimer = PREP_SECONDS
        if (round == 1) {
            MyScreenReader.speak("Round 1.")
        } else {
            MyScreenReader.speak("Round $round. You $playerWins, enemy $enemyWins.")
        }
    }

    private fun fightTick(dt: Float, controls: DuelControls) {
        cooldownLeft = max(0f, cooldownLeft - dt)
        if (reloading) {
            reloadLeft -= dt
            if (reloadLeft <= 0f) {
                reloading = false
                ammo = weapon.magazine
            }
        }

        if (controls.statusQueued) {
            controls.statusQueued = false
            speakStatus()
        }
        if (controls.reloadQueued) {
            controls.reloadQueued = false
            startReload()
        }
        if (controls.fireQueued) {
            controls.fireQueued = false
            fire()
        }
        if (phase != Phase.FIGHT) return // a shot may have just ended the round

        moveEnemy(dt)
        lockTone(dt)
        enemyShooting(dt)
        updateHeartbeat()
    }

    // ---------------------------------------------------------------- positions and 3D sound

    /** Angle of the enemy relative to where you face: 0 = straight ahead, +90 = right, -90 = left, 180 = behind. */
    private fun relAngle(): Float {
        var d = (enemyBearing - heading) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    private fun playAt(tag: String, rel: Float, distance: Float, baseVolume: Float, rate: Float) {
        val radians = Math.toRadians(rel.toDouble())
        val pan = sin(radians).toFloat()
        var volume = (1.15f - distance / 12f).coerceIn(0.2f, 1.0f) * baseVolume
        var pitch = rate
        if (cos(radians) < 0.0) {
            // Behind you: quieter and a little duller
            volume *= 0.65f
            pitch *= 0.92f
        }
        sound.playSpatial(tag, pan = pan, volume = volume.coerceIn(0f, 1f), rate = pitch)
    }

    // ---------------------------------------------------------------- the bot

    private fun moveEnemy(dt: Float) {
        if (pauseTimer > 0f) {
            pauseTimer -= dt
            return
        }
        moveTimer -= dt
        if (moveTimer <= 0f) {
            moveDir = if (Random.nextBoolean()) 1f else -1f
            running = Random.nextFloat() < difficulty.runChance
            radial = (Random.nextInt(3) - 1).toFloat()
            moveTimer = 1.0f + Random.nextFloat() * 1.6f
        }

        val speed = if (running) 3.6f else 1.6f
        enemyBearing += moveDir * speed / enemyDistance * 57.2958f * dt
        enemyDistance = (enemyDistance + radial * speed * 0.4f * dt).coerceIn(MIN_DISTANCE, MAX_DISTANCE)

        // Slow footsteps when walking, quick and a bit higher when running
        stepTimer -= dt
        if (stepTimer <= 0f) {
            var index = Random.nextInt(3) + 1
            if (index == lastStep) index = index % 3 + 1
            lastStep = index
            val rate = if (running) 1.2f + Random.nextFloat() * 0.1f else 0.95f + Random.nextFloat() * 0.1f
            val volume = if (running) 1.0f else 0.8f
            playAt("step_$index", relAngle(), enemyDistance, volume, rate)
            stepTimer = if (running) 0.36f else 0.74f
        }
    }

    private fun lockTone(dt: Float) {
        lockTimer -= dt
        val offTarget = abs(relAngle())
        val tolerance = weapon.toleranceDeg * difficulty.aimBonus
        if (offTarget <= tolerance && lockTimer <= 0f) {
            val closeness = 1f - offTarget / tolerance
            sound.playSpatial("lock_tone", pan = 0f, volume = 0.7f, rate = 0.9f + 0.5f * closeness)
            lockTimer = 0.32f - 0.16f * closeness
        }
    }

    private fun enemyShooting(dt: Float) {
        enemyFireTimer -= dt
        if (enemyFireTimer > 0f) return

        val baseGap = if (weapon.enemyFireFactor < 1f) {
            difficulty.fireGap * weapon.enemyFireFactor // automatic weapons: quick bursts
        } else {
            max(difficulty.fireGap, weapon.cooldown * 1.5f)
        }
        enemyFireTimer = baseGap * (0.8f + Random.nextFloat() * 0.5f)
        pauseTimer = minOf(0.35f, enemyFireTimer * 0.8f) // he stands still to shoot

        val rel = relAngle()
        playAt(weapon.soundTag, rel, enemyDistance, 0.9f, 0.95f)

        var chance = difficulty.hitChance * weapon.enemyAccuracy
        if (weapon.shotgun) chance *= (1.4f - enemyDistance / 10f).coerceIn(0.4f, 1.2f)

        if (Random.nextFloat() < chance) {
            hurtPlayer(weapon.damageAt(enemyDistance) * difficulty.damageScale)
        } else {
            // A miss: you hear the bullet fly past on his side
            playAt("bullet_whiz", rel + (Random.nextFloat() - 0.5f) * 40f, max(MIN_DISTANCE, enemyDistance * 0.5f), 1.0f, 1.0f)
        }
    }

    private fun hurtPlayer(damage: Float) {
        val before = playerHealth
        playerHealth = max(0f, playerHealth - damage)
        sound.playSpatial("body_hit", pan = 0f, volume = 0.9f)
        sound.vibrate(150)
        if (playerHealth <= 0f) {
            playerDown()
            return
        }
        val crossedTwoThirds = before > 66f && playerHealth <= 66f
        val crossedOneThird = before > 33f && playerHealth <= 33f
        if (crossedTwoThirds || crossedOneThird) {
            MyScreenReader.speak("Health ${playerHealth.toInt()}.", flush = false)
        }
    }

    private fun updateHeartbeat() {
        if (phase == Phase.FIGHT && playerHealth < LOW_HEALTH) {
            val danger = 1f - playerHealth / LOW_HEALTH
            val volume = 0.35f + 0.65f * danger
            val rate = 1.0f + 0.4f * danger
            if (heartbeatStream == 0) {
                heartbeatStream = sound.playLoop("heartbeat", 0f, volume, rate)
            } else {
                sound.updateStream(heartbeatStream, 0f, volume, rate)
            }
        } else {
            stopHeartbeat()
        }
    }

    // ---------------------------------------------------------------- the player's weapon

    private fun fire() {
        if (phase != Phase.FIGHT) return
        if (reloading || cooldownLeft > 0f) {
            if (reloading) sound.playSpatial("gun_empty", pan = 0f, volume = 0.5f)
            return
        }
        if (ammo <= 0) {
            sound.playSpatial("gun_empty", pan = 0f, volume = 0.9f)
            startReload()
            return
        }

        ammo -= 1
        cooldownLeft = weapon.cooldown
        sound.playSpatial(weapon.soundTag, pan = 0f, volume = 1.0f)
        sound.vibrate(40)

        val rel = relAngle()
        val tolerance = weapon.toleranceDeg * difficulty.aimBonus
        if (abs(rel) <= tolerance) {
            enemyHealth -= weapon.damageAt(enemyDistance)
            playAt("body_hit", rel, enemyDistance, 1.0f, 1.0f)
            if (enemyHealth <= 0f) {
                enemyDown()
                return
            }
        }
        if (ammo == 0) MyScreenReader.speak("Empty. Tap again to reload.", flush = false)
    }

    private fun startReload() {
        if (phase != Phase.FIGHT || reloading || ammo >= weapon.magazine) return
        reloading = true
        reloadLeft = weapon.reloadSeconds
        sound.playSpatial(weapon.reloadTag, pan = 0f, volume = 0.9f)
    }

    private fun speakStatus() {
        val reloadText = if (reloading) ", reloading" else ""
        MyScreenReader.speak("Health ${playerHealth.toInt()}. Ammo $ammo of ${weapon.magazine}$reloadText. You $playerWins, enemy $enemyWins.")
    }

    // ---------------------------------------------------------------- round and match end

    private fun enemyDown() {
        playerWins += 1
        stopHeartbeat()
        playAt("death", relAngle(), enemyDistance, 1.0f, 0.85f)
        phase = Phase.ROUND_END
        phaseTimer = ROUND_END_SECONDS
        MyScreenReader.speak("Enemy down! You win the round. You $playerWins, enemy $enemyWins.")
    }

    private fun playerDown() {
        enemyWins += 1
        stopHeartbeat()
        sound.playSpatial("death", pan = 0f, volume = 1.0f)
        phase = Phase.ROUND_END
        phaseTimer = ROUND_END_SECONDS
        MyScreenReader.speak("You are down. The enemy wins the round. You $playerWins, enemy $enemyWins.")
    }

    private fun afterRound() {
        if (playerWins >= WIN_ROUNDS || enemyWins >= WIN_ROUNDS) {
            endMatch()
        } else {
            beginRound()
        }
    }

    private fun endMatch() {
        playerWonMatch = playerWins > enemyWins
        stopHeartbeat()
        if (playerWonMatch) {
            sound.playSpatial("victory", pan = 0f, volume = 1.0f)
            summaryText = "You win the match, $playerWins to $enemyWins!"
        } else {
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
            summaryText = "You lost the match, $playerWins to $enemyWins."
        }
        MyScreenReader.speak(summaryText)
        phase = Phase.MATCH_END
        phaseTimer = MATCH_END_SECONDS
    }
}

/** Weapon, difficulty and end-of-match menus. They use the app's own screen reader, like Hand Cricket. */
class GunDuelController(
    private val sound: SoundManager,
    private val onExit: () -> Unit
) {
    var game by mutableStateOf<GunDuel?>(null)
    var title by mutableStateOf("GUN FIGHT")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    private var weapon: DuelWeapon = DUEL_WEAPONS[0]
    private var difficulty: DuelDifficulty = DUEL_DIFFICULTIES[1]
    private var introShown = false
    private var lastChangeMs = 0L

    fun begin() {
        showWeapons()
    }

    fun shutdown() {
        game?.shutdown()
        game = null
    }

    private fun tooSoon(): Boolean = System.currentTimeMillis() - lastChangeMs < 800L

    private fun say(text: String, help: String) {
        MyScreenReader.currentHelpContext = help
        MyScreenReader.speak(text)
    }

    private fun setItems(items: List<MyScreenReader.FocusItem>) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        lastChangeMs = System.currentTimeMillis()
        // Nothing focused yet: the first swipe reads the first option and a stray double tap does nothing
        if (items.isNotEmpty()) MyScreenReader.currentFocusIndex.value = -1
    }

    private fun showWeapons() {
        game = null
        title = "GUN FIGHT - 1 VS 1 DUEL"
        line1 = "Choose your weapon"
        line2 = "Swipe left or right, double tap to select"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (w in DUEL_WEAPONS) {
            items.add(MyScreenReader.FocusItem("weapon_${w.name}", w.name, w.blurb, "") { chooseWeapon(w) })
        }
        setItems(items)
        say(
            "Gun Fight, one versus one duel. Choose your weapon. Swipe right or left to hear the options, then double tap to select. " +
                "The back gesture returns to the menu.",
            "Swipe right or left to hear the weapons, then double tap to select."
        )
    }

    private fun chooseWeapon(w: DuelWeapon) {
        if (tooSoon()) return
        weapon = w
        showDifficulty()
    }

    private fun showDifficulty() {
        line1 = "Choose difficulty"
        line2 = weapon.name
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (d in DUEL_DIFFICULTIES) {
            items.add(MyScreenReader.FocusItem("difficulty_${d.name}", d.name, d.blurb, "") { chooseDifficulty(d) })
        }
        setItems(items)
        say(
            "${weapon.name} selected. Now choose the difficulty. Swipe to hear the options, then double tap.",
            "Swipe to hear the difficulty levels, then double tap to select."
        )
    }

    private fun chooseDifficulty(d: DuelDifficulty) {
        if (tooSoon()) return
        difficulty = d
        startMatch()
    }

    private fun startMatch() {
        MyScreenReader.clearItems()
        title = "1 VS 1 DUEL"
        val g = GunDuel(sound, weapon, difficulty) { text, won -> onMatchOver(text, won) }
        game = g
        g.start(!introShown)
        introShown = true
    }

    private fun onMatchOver(text: String, won: Boolean) {
        game?.shutdown()
        game = null
        showEnd(text, won)
    }

    private fun showEnd(text: String, won: Boolean) {
        title = if (won) "YOU WIN" else "YOU LOST"
        line1 = text
        line2 = "${weapon.name}, ${difficulty.name}"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("duel_again", "Play again", "same weapon and difficulty", "") { if (!tooSoon()) startMatch() })
        items.add(MyScreenReader.FocusItem("duel_change", "Change weapon", "button", "") { if (!tooSoon()) showWeapons() })
        items.add(MyScreenReader.FocusItem("duel_menu", "Main menu", "button", "") { if (!tooSoon()) onExit() })
        setItems(items)
        say("$text Swipe to choose Play again, Change weapon or Main menu.", "Swipe to choose, then double tap.")
    }
}

/** Fire in the middle of the screen, reload at the bottom edge, status at the top edge. */
private fun Modifier.duelTouchControls(controls: DuelControls): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        awaitPointerEventScope {
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                for (change in event.changes) {
                    if (change.pressed && !change.previousPressed) {
                        val fraction = change.position.y / size.height.toFloat()
                        if (fraction < 0.18f) {
                            controls.statusQueued = true
                        } else if (fraction > 0.82f) {
                            controls.reloadQueued = true
                        } else {
                            controls.fireQueued = true
                        }
                    }
                }
            }
        }
    }

@Composable
fun GunDuelScreen(soundManager: SoundManager, azimuth: Float, paused: Boolean, onBack: () -> Unit) {
    val controller = remember { GunDuelController(soundManager, onBack) }
    val controls = remember { DuelControls() }
    var uiTick by remember { mutableStateOf(0) }
    val heading by rememberUpdatedState(azimuth)
    val isPaused by rememberUpdatedState(paused)

    LaunchedEffect(Unit) {
        controller.begin()
    }

    DisposableEffect(Unit) {
        onDispose { controller.shutdown() }
    }

    val game = controller.game

    LaunchedEffect(game) {
        if (game == null) return@LaunchedEffect
        var last = System.nanoTime()
        var counter = 0
        while (true) {
            delay(30)
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            if (isPaused) continue
            game.tick(dt, heading, controls)
            counter++
            if (counter % 5 == 0) uiTick++
        }
    }

    val refresh = uiTick

    if (game == null) {
        val spoken = MyScreenReader.currentSpokenTextState.value
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .myScreenReaderGestures()
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text(controller.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(controller.line1, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                    Text(controller.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
                }
                Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
                Text(
                    "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture returns to the menu.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF020617))
                .duelTouchControls(controls)
                .padding(24.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Text("ROUND ${game.round}   You ${game.playerWins} - ${game.enemyWins} Enemy", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(game.phaseLabel, fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                    Text("Health ${game.playerHealth.toInt()}", fontSize = 22.sp, color = Color(0xFF4ADE80))
                    Text("Ammo ${game.ammo} / ${game.magazine}", fontSize = 22.sp, color = Color(0xFFFBBF24))
                }
                Text(
                    "Turn to face the enemy sounds. Tap the middle to fire, bottom edge to reload, top edge for status. Back gesture leaves the match.",
                    fontSize = 13.sp,
                    color = Color(0xFF64748B)
                )
            }
        }
    }
}
