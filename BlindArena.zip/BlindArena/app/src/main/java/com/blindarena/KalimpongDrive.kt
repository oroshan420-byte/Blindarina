package com.blindarena

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.random.Random

// =========================================================================
// LONG DRIVE: 70 kilometres to the Mary Scott Home School for the Blind hostel in Kalimpong.
//
// There are no buildings to crash into. The road is 20 metres wide and 70 km long: a city, a highway,
// a river valley with two bridges, a twisting hill road and finally Kalimpong town.
//  - ONE finger: the car goes while the finger is on the screen. The FURTHER UP you slide, the FASTER it goes.
//    Slide DOWN to reverse. LIFT the finger and the car slows down and stops.
//    Slide LEFT or RIGHT to steer. A quick tap asks the GPS where to go.
//  - The GPS voice tells you every turn well in advance, and every 5 km how far is left.
//  - Beeps on one side tell you the road bends that way: steer towards the beeps.
//  - A rumble on one side means you are at the edge of the road. Leaving the road only slows you down.
//  - Keep to the LEFT half of the road. Oncoming vehicles use the right half.
//  - Cows, dogs, crowds, autos, buses, trucks, bikes and cyclists are on the road. Soft beeps ahead warn you.
//  - A beeping pedestrian signal means a red light in town: stop.
// =========================================================================

class KalimpongGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    private enum class Zone { CITY, HIGHWAY, VALLEY, HILLS, TOWN }
    private enum class Type { COW, DOG, CROWD, BUMP, AUTO, BUS, TRUCK, BIKE, CYCLIST }

    /** One straight piece of the road. The turn at its end is given in degrees: positive = right, negative = left. */
    private class Leg(
        val x0: Float,
        val y0: Float,
        val length: Float,
        val startM: Float,
        val heading: Float,
        val turnAtEnd: Float
    ) {
        val dx: Float = sin(Math.toRadians(heading.toDouble())).toFloat()
        val dy: Float = cos(Math.toRadians(heading.toDouble())).toFloat()
        val endM: Float
            get() = startM + length
    }

    /** Anything on the road. s = distance along the route, lat = sideways from the centre line (right is positive). */
    private class Thing(val type: Type, var s: Float, val lat: Float) {
        var x: Float = 0f
        var y: Float = 0f
        var dir: Float = 0f          // 0 = stands still, +1 = drives the same way as you, -1 = oncoming
        var speed: Float = 0f
        var curSpeed: Float = 0f     // what it really drives now: it slows down for a car in front of it
        var callTimer: Float = 0f
        var stream: Int = 0
        var lastAhead: Float = 1000f
        var passed: Boolean = false
        var crossed: Boolean = false
    }

    private class Light(val s: Float, val x: Float, val y: Float) {
        var timer: Float = 0f
        var red: Boolean = false
        var beepTimer: Float = 0f
        var announced: Boolean = false
        var lastAhead: Float = 1000f
    }

    private class Place(val x: Float, val y: Float, val tag: String, val range: Float, val volume: Float) {
        var stream: Int = 0
    }

    companion object {
        const val DESTINATION = "Mary Scott Home School for the Blind hostel in Kalimpong"

        const val ROUTE_M = 70000f
        const val ROAD_HALF = 10f          // the road is 20 metres wide
        const val VERGE_LIMIT = 24f        // a soft invisible edge beside the road: it never costs a life
        const val START_LAT = -5f          // you start in the left half

        const val TOP_SPEED = 30f          // 108 km/h
        const val REVERSE_TOP = 5f
        const val OFFROAD_TOP = 7f
        const val OFFROAD_BRAKE = 22f      // the grass slows the car quickly
        const val ACCEL = 5f
        const val BRAKE = 12f
        const val WHEELBASE = 2.7f
        const val MAX_STEER = 0.61f
        const val ASSIST_DEG = 14f

        const val START_LIVES = 3
        const val CRASH_COOLDOWN = 3f
        const val SOFT_IMPACT = 5f         // below this speed a collision is only a bump and costs no life
        const val GAME_OVER_SECONDS = 3f
        const val ARRIVE_BEFORE_END = 20f

        const val SPAWN_AHEAD = 520f
        const val DESPAWN_BEHIND = 160f
        const val MAX_LOOPS = 10
        const val MAX_MOVERS = 12
        const val CHECKPOINT_M = 10000f
        const val REPORT_M = 5000f

        const val LIGHT_CYCLE = 18f
        const val LIGHT_RED_SECONDS = 7f

        const val BRIDGE_LENGTH = 300f
        const val RAIN_FROM_M = 47000f
        const val RAIN_TO_M = 57000f

        val LANES = floatArrayOf(-7.5f, -2.5f, 2.5f, 7.5f)
        val VILLAGES = floatArrayOf(9500f, 15200f, 21800f, 33500f, 45000f, 52500f, 60000f)
        val LIGHT_POSITIONS = floatArrayOf(650f, 1500f, 2500f, 3600f, 4500f, 66800f, 67900f, 69000f)
        val BRIDGES = floatArrayOf(31000f, 38500f)
    }

    private val legs = ArrayList<Leg>()
    private val things = ArrayList<Thing>()
    private val lights = ArrayList<Light>()
    private val places = ArrayList<Place>()
    private val tmp = FloatArray(2)
    private val engine = EngineSound(sound)

    // the car: x grows to the east, y to the north. Heading: 0 = north, 90 = east
    private var px = 0f
    private var py = 0f
    private var heading = 0f
    private var hSin = 0f
    private var hCos = 1f
    private var speed = 0f
    private var desired = 0f            // the speed the finger asks for right now (0 when the finger is lifted)
    private var crashCooldown = 0f
    private var skidTimer = 0f
    private var scrapeTimer = 0f
    private var wasFast = false

    // where the car is on the road
    private var legIdx = 0
    private var routeS = 0f
    private var bestS = 0f
    private var lateral = 0f
    private var edgeDist = 0f
    private var nearX = 0f
    private var nearY = 0f

    private var destX = 0f
    private var destY = 0f

    var lives: Int = START_LIVES
        private set
    private var elapsed = 0f

    // spawning
    private var staticSpawnedUpTo = 150f
    private var moverTimer = 6f
    private var loopCount = 0
    private var threatTimer = 0f
    private var bumpTimer = 0f

    // road feedback
    private var rumbleStream = 0
    private var offTime = 0f
    private var offMsgTimer = 0f
    private var wasOff = false
    private var wrongTime = 0f
    private var wrongMsgTimer = 0f
    private var rightTime = 0f
    private var rightMsgTimer = 0f
    private var onRightSide = false
    private var guideTimer = 0f

    // atmosphere
    private var lastZone = Zone.CITY
    private var baseTag = ""
    private var baseStream = 0
    private var baseVolume = 0f
    private var rainStream = 0
    private var rainVolume = 0f
    private var riverStream = 0
    private var riverVolume = 0f
    private var thunderTimer = 10f
    private var owlTimer = 12f
    private var bellTimer = 6f
    private var creakTimer = 0f
    private val bridgeAnnounced = BooleanArray(BRIDGES.size)
    private var reverseStream = 0
    private var indicatorStream = 0

    // GPS and speech
    private var gpsLeg = 0
    private var stageDone = IntArray(0)
    private var nextReportM = REPORT_M
    private var nextCheckpointM = CHECKPOINT_M
    private class Line(val text: String, val kind: String, val born: Float)
    private val pending = ArrayList<Line>()
    private var quiet = 0f
    private var introPlaying = true
    private var flushNext = false
    private var idleTimer = 0f

    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overWon = false
    private var overNotified = false

    // for the automatic tests only
    internal var dbgTraffic = true

    override val title: String
        get() = "LONG DRIVE"
    override val line1: String
        get() = "${(abs(speed) * 3.6f).toInt()} km/h   ${compassName(heading)}"
    override val line2: String
        get() = "Lives $lives   ${kmText(max(0f, ROUTE_M - routeS))} to Kalimpong"
    override val usesStick: Boolean
        get() = true

    init {
        buildRoute()
        buildLights()
        buildPlaces()
        stageDone = IntArray(legs.size)

        val first = legs[0]
        px = first.x0 + first.dy * START_LAT      // the right-hand side of the road direction is (dy, -dx)
        py = first.y0 - first.dx * START_LAT
        heading = first.heading
        updateTrig()
        locate()

        val intro = "Long drive. You are driving 70 kilometres to the $DESTINATION. " +
            "The GPS will guide you. The car is stopped. Put one finger on the screen and slide it up to drive. " +
            "The further up you slide, the faster you go. Slide down to reverse. When you lift your finger the car stops. " +
            "Slide left or right to steer. A quick tap asks the GPS. " +
            "Beeps on one side mean the road bends that way: steer towards the beeps. " +
            "A rumble means you are near the edge of the road. Keep to the left side. " +
            "Do the back gesture twice to leave."
        MyScreenReader.currentHelpContext = "Slide up to drive, the further up the faster. Slide down to reverse. Slide left or right to steer. Lift your finger to stop. Quick tap: GPS."
        MyScreenReader.speak(intro)
        quiet = speechSeconds(intro)
        announceLeg(0)
    }

    // ---------------------------------------------------------------- building the road

    private fun zoneAt(s: Float): Zone {
        return when {
            s < 5000f -> Zone.CITY
            s < 28000f -> Zone.HIGHWAY
            s < 42000f -> Zone.VALLEY
            s < 66000f -> Zone.HILLS
            else -> Zone.TOWN
        }
    }

    private fun legLength(zone: Zone): Float {
        val lo: Float
        val hi: Float
        when (zone) {
            Zone.CITY -> { lo = 500f; hi = 900f }
            Zone.HIGHWAY -> { lo = 2000f; hi = 4200f }
            Zone.VALLEY -> { lo = 1200f; hi = 2600f }
            Zone.HILLS -> { lo = 700f; hi = 1700f }
            Zone.TOWN -> { lo = 400f; hi = 800f }
        }
        return lo + Random.nextFloat() * (hi - lo)
    }

    private fun turnMagnitude(zone: Zone): Float {
        val choices = when (zone) {
            Zone.CITY -> floatArrayOf(30f, 45f, 60f, 80f)
            Zone.HIGHWAY -> floatArrayOf(10f, 15f, 20f, 30f)
            Zone.VALLEY -> floatArrayOf(20f, 30f, 45f, 60f)
            Zone.HILLS -> floatArrayOf(40f, 60f, 80f, 95f)
            Zone.TOWN -> floatArrayOf(30f, 50f, 70f)
        }
        return choices[Random.nextInt(choices.size)]
    }

    private fun buildRoute() {
        var x = 0f
        var y = 0f
        var turned = 0f            // all the turning so far, right is positive, so the road never loops back on itself
        var s = 0f
        while (s < ROUTE_M - 0.5f) {
            val zone = zoneAt(s)
            var length = legLength(zone)
            var last = false
            if (ROUTE_M - (s + length) < 600f) {
                length = ROUTE_M - s
                last = true
            }
            var turn = 0f
            if (!last) {
                var sign = if (Random.nextBoolean()) 1f else -1f
                if (turned > 90f) sign = -1f else if (turned < -90f) sign = 1f
                turn = turnMagnitude(zone) * sign
            }
            val heading = ((turned % 360f) + 360f) % 360f
            val leg = Leg(x, y, length, s, heading, turn)
            legs.add(leg)
            x += leg.dx * length
            y += leg.dy * length
            turned += turn
            s += length
        }
    }

    private fun buildLights() {
        for (base in LIGHT_POSITIONS) {
            val s = base + (Random.nextFloat() - 0.5f) * 120f
            setPoint(s, 0f)
            val light = Light(s, tmp[0], tmp[1])
            light.timer = Random.nextFloat() * LIGHT_CYCLE
            light.red = light.timer < LIGHT_RED_SECONDS
            lights.add(light)
        }
    }

    private fun buildPlaces() {
        for (s in VILLAGES) {
            setPoint(s, 26f)
            places.add(Place(tmp[0], tmp[1], "market_loop", 170f, 0.8f))
        }
        setPoint(ROUTE_M, 0f)
        destX = tmp[0]
        destY = tmp[1]
        // the children of the hostel: heard from far away, getting louder as you arrive
        places.add(Place(destX, destY, "school_loop", 700f, 0.9f))
    }

    private fun legIndexAt(s: Float): Int {
        var lo = 0
        var hi = legs.size - 1
        while (lo < hi) {
            val mid = (lo + hi + 1) / 2
            if (legs[mid].startM <= s) lo = mid else hi = mid - 1
        }
        return lo
    }

    /** World position of a point on the road, written to tmp. */
    private fun setPoint(s: Float, lat: Float) {
        val leg = legs[legIndexAt(s.coerceIn(0f, ROUTE_M))]
        val t = s - leg.startM
        tmp[0] = leg.x0 + leg.dx * t + leg.dy * lat
        tmp[1] = leg.y0 + leg.dy * t - leg.dx * lat
    }

    // ---------------------------------------------------------------- where the car is on the road

    private fun updateTrig() {
        val radians = Math.toRadians(heading.toDouble())
        hSin = sin(radians).toFloat()
        hCos = cos(radians).toFloat()
    }

    private fun locate() {
        var best = legIdx
        var bestD2 = Float.MAX_VALUE
        var bestT = 0f
        val order = intArrayOf(legIdx, legIdx + 1, legIdx - 1)
        for (i in order) {
            if (i < 0 || i >= legs.size) continue
            val leg = legs[i]
            val t = ((px - leg.x0) * leg.dx + (py - leg.y0) * leg.dy).coerceIn(0f, leg.length)
            val cx = leg.x0 + leg.dx * t
            val cy = leg.y0 + leg.dy * t
            val ex = px - cx
            val ey = py - cy
            val d2 = ex * ex + ey * ey
            if (d2 < bestD2 - 0.001f) {
                bestD2 = d2
                best = i
                bestT = t
            }
        }
        legIdx = best
        val leg = legs[best]
        routeS = leg.startM + bestT
        if (routeS > bestS) bestS = routeS
        nearX = leg.x0 + leg.dx * bestT
        nearY = leg.y0 + leg.dy * bestT
        lateral = (px - leg.x0) * leg.dy - (py - leg.y0) * leg.dx
        edgeDist = sqrt(bestD2)
    }

    private fun angleDiff(target: Float, current: Float): Float {
        var d = (target - current) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    /** How far you must turn to follow the road: 0 = lined up, positive = turn right. It looks ahead into the next bend. */
    private fun headingError(): Float {
        val leg = legs[legIdx]
        var target = leg.heading
        if (legIdx < legs.size - 1) {
            val look = 25f + max(0f, speed) * 2f
            val toCorner = leg.endM - routeS
            if (toCorner < look) {
                target += leg.turnAtEnd * (1f - toCorner / look).coerceIn(0f, 1f)
            }
        }
        return angleDiff(target, heading)
    }

    // ---------------------------------------------------------------- geometry and 3D sound

    private fun distanceTo(x: Float, y: Float): Float {
        val dx = x - px
        val dy = y - py
        return sqrt(dx * dx + dy * dy)
    }

    /** Angle of something relative to where the car points: 0 ahead, +90 right, -90 left, 180 behind. */
    private fun relAngle(x: Float, y: Float): Float {
        val bearing = Math.toDegrees(atan2((x - px).toDouble(), (y - py).toDouble())).toFloat()
        return angleDiff(bearing, heading)
    }

    private fun panFor(rel: Float): Float {
        return sin(Math.toRadians(rel.toDouble())).toFloat()
    }

    private fun volumeFor(rel: Float, distance: Float, range: Float, base: Float): Float {
        var volume = (1.1f - distance / range).coerceIn(0f, 1f) * base
        if (abs(rel) > 90f) volume *= 0.65f // behind you: quieter
        return volume.coerceIn(0f, 1f)
    }

    private fun playAt(tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float) {
        val d = distanceTo(x, y)
        if (d >= range) return
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (volume < 0.03f) return
        sound.playSpatial(tag, pan = panFor(rel), volume = volume, rate = rate)
    }

    /** A looping sound at a place: starts when you get close, follows it, stops when you are far. Returns the stream id (0 = not playing). */
    private fun updateLoop(stream: Int, tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float): Int {
        val d = distanceTo(x, y)
        if (d >= range) {
            if (stream != 0) sound.stopStream(stream)
            return 0
        }
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (stream == 0) return sound.playLoop(tag, panFor(rel), volume, rate)
        sound.updateStream(stream, panFor(rel), volume, rate)
        return stream
    }

    // ---------------------------------------------------------------- speech

    private fun speechSeconds(text: String): Float {
        return text.length / (13f * MyScreenReader.speechRate) + 0.4f
    }

    /**
     * priority 0 = wait in line, 1 = go to the front of the line, 2 = say it right now and drop everything else.
     * A new line replaces an older waiting line of the same kind, so old news never piles up.
     */
    private fun say(text: String, priority: Int = 0, kind: String = "") {
        if (priority >= 2) {
            pending.clear()
            MyScreenReader.speak(text)
            quiet = speechSeconds(text)
            introPlaying = false
            return
        }
        if (kind.isNotEmpty()) {
            var i = pending.size - 1
            while (i >= 0) {
                if (pending[i].kind == kind) pending.removeAt(i)
                i -= 1
            }
        }
        val line = Line(text, kind, elapsed)
        if (priority == 1) pending.add(0, line) else pending.add(line)
        while (pending.size > 4) pending.removeAt(pending.size - 1)
    }

    private fun updateNarrator(dt: Float) {
        quiet -= dt
        // the opening instructions are cut short as soon as you start to drive
        if (introPlaying && speed > 2f) {
            introPlaying = false
            quiet = 0f
            flushNext = true
        }
        if (quiet <= 0f) introPlaying = false
        if (quiet <= 0f && pending.isNotEmpty()) {
            var line: Line? = null
            while (pending.isNotEmpty() && line == null) {
                val first = pending.removeAt(0)
                if (elapsed - first.born <= 25f) line = first   // news that is too old is not worth saying
            }
            if (line != null) {
                MyScreenReader.speak(line.text, flush = flushNext)
                flushNext = false
                quiet = speechSeconds(line.text)
            }
        }
    }

    private fun kmText(m: Float): String {
        val tenths = Math.round(m / 100f)
        return "${tenths / 10}.${tenths % 10} km"
    }

    private fun distWord(m: Float): String {
        if (m >= 1000f) {
            val tenths = Math.round(m / 100f)
            return if (tenths == 10) {
                "1 kilometre"
            } else if (tenths % 10 == 0) {
                "${tenths / 10} kilometres"
            } else {
                "${tenths / 10}.${tenths % 10} kilometres"
            }
        }
        if (m < 30f) return "a few meters"
        val rounded = if (m >= 200f) Math.round(m / 100f) * 100 else Math.round(m / 50f) * 50
        return "$rounded meters"
    }

    private fun turnWord(turn: Float): String {
        val a = abs(turn)
        val side = if (turn > 0f) "right" else "left"
        return when {
            a < 30f -> "bear $side"
            a < 60f -> "turn $side"
            a < 85f -> "sharp $side turn"
            else -> "very sharp $side turn"
        }
    }

    private fun capitalised(text: String): String {
        return text.substring(0, 1).uppercase() + text.substring(1)
    }

    // ---------------------------------------------------------------- stopping everything

    override fun shutdown() {
        stopAll()
    }

    private fun stopAll() {
        engine.stop()
        sound.stopStream(baseStream)
        sound.stopStream(rainStream)
        sound.stopStream(riverStream)
        sound.stopStream(rumbleStream)
        sound.stopStream(reverseStream)
        sound.stopStream(indicatorStream)
        baseStream = 0
        rainStream = 0
        riverStream = 0
        rumbleStream = 0
        reverseStream = 0
        indicatorStream = 0
        baseTag = ""
        for (p in places) {
            sound.stopStream(p.stream)
            p.stream = 0
        }
        for (t in things) {
            sound.stopStream(t.stream)
            t.stream = 0
        }
    }

    // ---------------------------------------------------------------- main loop

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                onOver(overText, overWon)
            }
            return
        }

        elapsed += dt
        updateCar(dt, controls)
        if (controls.gpsQueued) {
            controls.gpsQueued = false
            speakGpsNow()
        }
        spawnThings(dt)
        updateThings(dt)
        if (isOver) return
        updateLights(dt)
        if (isOver) return
        updateRoadFeedback(dt)
        updatePlaces(dt)
        updateAtmosphere(dt)
        updateGps()
        updateNarrator(dt)

        if (!isOver && routeS >= ROUTE_M - ARRIVE_BEFORE_END) win()
    }

    // ---------------------------------------------------------------- the car

    private fun updateCar(dt: Float, controls: CarControls) {
        crashCooldown = max(0f, crashCooldown - dt)
        skidTimer = max(0f, skidTimer - dt)
        scrapeTimer = max(0f, scrapeTimer - dt)

        // The car goes while the finger is down: the further up the finger, the faster. Down reverses. Lifting stops.
        var steerCmd = 0f
        var wanted = 0f
        if (controls.stickActive) {
            val sy = controls.stickY
            val sx = controls.stickX
            if (sy > 0.06f) {
                // sliding further, or flicking faster, asks for more speed
                wanted = TOP_SPEED * (sy + 0.45f * controls.stickBoost).coerceIn(0f, 1f)
            } else if (sy < -0.06f) {
                wanted = -REVERSE_TOP * (-sy).coerceIn(0f, 1f)
            }
            steerCmd = if (abs(sx) > 0.08f) sx else 0f
        }
        desired = wanted

        // beside the road the car is slowed down by the grass
        val offRoad = edgeDist > ROAD_HALF + 1f
        val cap = if (offRoad) OFFROAD_TOP else TOP_SPEED
        val target = min(wanted, cap)
        val slowing = abs(target) < abs(speed) || target * speed < 0f
        val boostMultiplier = 1f + 2f * controls.stickBoost
        val rate = if (slowing) (if (offRoad) OFFROAD_BRAKE else BRAKE) else ACCEL * boostMultiplier
        speed = if (speed < target) min(target, speed + rate * dt) else max(target, speed - rate * dt)

        // A handbrake sound when you come to a stop from a good speed
        if (abs(speed) > 5f) wasFast = true
        if (wasFast && abs(speed) < 0.3f) {
            wasFast = false
            sound.playSpatial("handbrake", pan = 0f, volume = 0.7f)
        }

        // Steering like a real car: it only turns while moving, and the faster you go the less the wheels can turn
        val steerAngle = steerCmd * MAX_STEER / (1f + abs(speed) / 5f)
        val yawRate = speed / WHEELBASE * tan(steerAngle)
        heading += yawRate * dt * 57.2958f

        // Lane assist: when no finger is steering, a small difference to the road direction is straightened out gently.
        // Real bends and turns still need you to steer.
        if (steerCmd == 0f && speed > 2f) {
            val err = headingError()
            if (abs(err) <= ASSIST_DEG) heading += err * min(1f, dt * 1.4f)
        }
        heading = ((heading % 360f) + 360f) % 360f
        updateTrig()

        px += hSin * speed * dt
        py += hCos * speed * dt
        locate()

        // The edge of the world beside the road is soft: you slide along it, nothing is hit and no life is lost
        if (edgeDist > VERGE_LIMIT) {
            val k = VERGE_LIMIT / edgeDist
            px = nearX + (px - nearX) * k
            py = nearY + (py - nearY) * k
            edgeDist = VERGE_LIMIT
            speed *= 0.9f
            if (scrapeTimer <= 0f) {
                scrapeTimer = 0.6f
                sound.playSpatial("tire_screech", pan = if (lateral >= 0f) 0.9f else -0.9f, volume = 0.5f)
                sound.vibrate(40)
            }
        }

        // Tyres squeal in a hard fast turn
        if (abs(speed) > 8f && abs(steerCmd) > 0.7f && skidTimer <= 0f) {
            skidTimer = 1.5f
            sound.playSpatial("car_skid", pan = 0f, volume = 0.5f)
        }

        // Engine, reverse beeper, indicator
        engine.update(abs(speed) / TOP_SPEED)
        reverseStream = onOff(reverseStream, "reverse_beep_loop", speed < -0.4f, 0f, 0.5f)
        val indicating = abs(steerCmd) > 0.25f && speed > 0.3f
        indicatorStream = onOff(indicatorStream, "indicator_loop", indicating, if (steerCmd < 0f) -0.4f else 0.4f, 0.45f)

        // Gentle reminder when the car is standing still
        if (abs(speed) < 0.3f && desired == 0f) {
            idleTimer += dt
            if (idleTimer > 15f) {
                idleTimer = 0f
                say("Slide a finger up the screen to drive.", 0, "idle")
            }
        } else {
            idleTimer = 0f
        }
    }

    private fun onOff(stream: Int, tag: String, active: Boolean, pan: Float, volume: Float): Int {
        if (active) {
            if (stream == 0) return sound.playLoop(tag, pan, volume, 1.0f)
            sound.updateStream(stream, pan, volume, 1.0f)
            return stream
        }
        if (stream != 0) sound.stopStream(stream)
        return 0
    }

    // ---------------------------------------------------------------- crashes and the end

    private fun loseLife(reason: String, soundTag: String, glass: Boolean) {
        if (crashCooldown > 0f) return
        crashCooldown = CRASH_COOLDOWN
        lives -= 1
        speed = 0f
        desired = 0f
        sound.playSpatial(soundTag, pan = 0f, volume = 1.0f)
        if (glass) sound.playSpatial("glass_break", pan = 0f, volume = 0.8f)
        sound.vibrate(300)
        clearNear() // so you do not crash into the next thing at once
        if (lives <= 0) {
            isOver = true
            overWon = false
            overTimer = GAME_OVER_SECONDS
            overText = "$reason Game over. You covered ${distWord(bestS)} of the 70 kilometre journey."
            stopAll()
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
        } else {
            val word = if (lives == 1) "life" else "lives"
            say("$reason $lives $word left. Slide up to drive again.", 2)
        }
    }

    private fun win() {
        isOver = true
        overWon = true
        overTimer = 6f
        val minutes = Math.round(elapsed / 60f)
        val word = if (lives == 1) "life" else "lives"
        overText = "You have arrived at the $DESTINATION! The children are waiting at the gate. " +
            "The journey took $minutes minutes. You finished with $lives $word left."
        speed = 0f
        desired = 0f
        stopAll()
        sound.playSpatial("door_open", pan = 0f, volume = 0.9f)
        sound.playSpatial("cheer", pan = 0f, volume = 0.9f)
        sound.playSpatial("victory", pan = 0f, volume = 1.0f)
        MyScreenReader.speak("You have arrived!")
    }

    // ---------------------------------------------------------------- animals, people, vehicles

    private fun nameOf(type: Type): String {
        return when (type) {
            Type.COW -> "cow"
            Type.DOG -> "dog"
            Type.CROWD -> "crowd of people"
            Type.BUMP -> "speed bump"
            Type.AUTO -> "auto rickshaw"
            Type.BUS -> "bus"
            Type.TRUCK -> "truck"
            Type.BIKE -> "motorcycle"
            Type.CYCLIST -> "cyclist"
        }
    }

    private fun radiusOf(type: Type): Float {
        return when (type) {
            Type.COW -> 2.2f
            Type.DOG -> 1.8f
            Type.CROWD -> 2.6f
            Type.BUMP -> 0f
            Type.AUTO -> 2.2f
            Type.BUS -> 3.0f
            Type.TRUCK -> 3.0f
            Type.BIKE -> 1.8f
            Type.CYCLIST -> 1.8f
        }
    }

    private fun nearVillage(s: Float): Boolean {
        for (v in VILLAGES) {
            if (abs(s - v) < 300f) return true
        }
        return false
    }

    private fun staticGap(zone: Zone, village: Boolean): Float {
        val r = Random.nextFloat()
        return when {
            village -> 130f + r * 80f
            zone == Zone.CITY || zone == Zone.TOWN -> 150f + r * 100f
            zone == Zone.HIGHWAY -> 300f + r * 220f
            zone == Zone.VALLEY -> 260f + r * 160f
            else -> 220f + r * 160f
        }
    }

    private fun pickStatic(zone: Zone, village: Boolean): Type {
        val r = Random.nextFloat()
        return if (village || zone == Zone.CITY || zone == Zone.TOWN) {
            if (r < 0.25f) Type.COW else if (r < 0.5f) Type.DOG else if (r < 0.7f) Type.CROWD else Type.BUMP
        } else {
            if (r < 0.45f) Type.COW else if (r < 0.9f) Type.DOG else Type.BUMP
        }
    }

    private fun addStatic(type: Type, s: Float) {
        val lat = if (type == Type.BUMP) 0f else LANES[Random.nextInt(LANES.size)] + (Random.nextFloat() - 0.5f) * 2f
        val thing = Thing(type, s, lat)
        setPoint(s, lat)
        thing.x = tmp[0]
        thing.y = tmp[1]
        thing.callTimer = Random.nextFloat() * 3f
        things.add(thing)
    }

    private fun pickMover(zone: Zone): Type {
        val r = Random.nextFloat()
        return if (zone == Zone.CITY || zone == Zone.TOWN) {
            if (r < 0.30f) Type.AUTO else if (r < 0.55f) Type.BIKE else if (r < 0.75f) Type.CYCLIST else if (r < 0.90f) Type.BUS else Type.TRUCK
        } else if (zone == Zone.HIGHWAY) {
            if (r < 0.30f) Type.TRUCK else if (r < 0.60f) Type.BUS else if (r < 0.70f) Type.AUTO else Type.BIKE
        } else {
            if (r < 0.30f) Type.TRUCK else if (r < 0.55f) Type.BUS else if (r < 0.70f) Type.AUTO else Type.BIKE
        }
    }

    private fun moverSpeed(type: Type, oncoming: Boolean): Float {
        val base = if (oncoming) {
            when (type) {
                Type.AUTO -> 9f
                Type.BUS -> 15f
                Type.TRUCK -> 13f
                Type.BIKE -> 17f
                else -> 4f
            }
        } else {
            when (type) {
                Type.AUTO -> 7f
                Type.BUS -> 11f
                Type.TRUCK -> 9f
                Type.BIKE -> 13f
                else -> 4f
            }
        }
        return base * (0.9f + Random.nextFloat() * 0.2f)
    }

    private fun moverCount(): Int {
        var n = 0
        for (t in things) {
            if (t.dir != 0f) n += 1
        }
        return n
    }

    private fun spawnThings(dt: Float) {
        if (!dbgTraffic) return

        // things that stand on the road are placed ahead of you as you drive
        val horizon = routeS + SPAWN_AHEAD
        while (staticSpawnedUpTo < horizon && staticSpawnedUpTo < ROUTE_M - 80f) {
            val zone = zoneAt(staticSpawnedUpTo)
            val village = nearVillage(staticSpawnedUpTo)
            addStatic(pickStatic(zone, village), staticSpawnedUpTo)
            staticSpawnedUpTo += staticGap(zone, village)
        }

        // vehicles come and go
        moverTimer -= dt
        if (moverTimer <= 0f) {
            val zone = zoneAt(routeS)
            moverTimer = when (zone) {
                Zone.CITY, Zone.TOWN -> 7f + Random.nextFloat() * 5f
                Zone.HIGHWAY -> 9f + Random.nextFloat() * 6f
                else -> 10f + Random.nextFloat() * 6f
            }
            if (moverCount() < MAX_MOVERS) spawnMover(zone)
        }
    }

    private fun spawnMover(zone: Zone) {
        val oncoming = Random.nextFloat() < 0.55f
        val type = pickMover(zone)
        val s = if (oncoming) routeS + 380f + Random.nextFloat() * 140f else routeS + 300f + Random.nextFloat() * 140f
        if (s > ROUTE_M - 100f) return
        // you drive on the left: your half has the lanes -7.5 and -2.5, oncoming vehicles use 2.5 and 7.5
        val lane = if (oncoming) 2 + Random.nextInt(2) else Random.nextInt(2)
        val thing = Thing(type, s, LANES[lane])
        thing.dir = if (oncoming) -1f else 1f
        thing.speed = moverSpeed(type, oncoming)
        thing.curSpeed = thing.speed
        thing.callTimer = 1.5f + Random.nextFloat() * 3f
        setPoint(s, thing.lat)
        thing.x = tmp[0]
        thing.y = tmp[1]
        things.add(thing)
    }

    private fun removeThingAt(index: Int) {
        sound.stopStream(things[index].stream)
        things.removeAt(index)
    }

    /** Takes away what is right around the car after a crash, so you do not crash again at once. */
    private fun clearNear() {
        var i = things.size - 1
        while (i >= 0) {
            if (abs(things[i].s - routeS) < 70f) removeThingAt(i)
            i -= 1
        }
    }

    private fun thingLoop(t: Thing, tag: String, range: Float, base: Float, rate: Float, d: Float, rel: Float) {
        if (d >= range) {
            if (t.stream != 0) {
                sound.stopStream(t.stream)
                t.stream = 0
                loopCount -= 1
            }
            return
        }
        val volume = volumeFor(rel, d, range, base)
        val pan = panFor(rel)
        if (t.stream == 0) {
            if (loopCount >= MAX_LOOPS) return
            t.stream = sound.playLoop(tag, pan, volume, rate)
            if (t.stream != 0) loopCount += 1
        } else {
            sound.updateStream(t.stream, pan, volume, rate)
        }
    }

    /** A vehicle warns you with its horn when it is in your way. */
    private fun horn(t: Thing, tag: String, fwd: Float, side: Float, closing: Float) {
        if (t.callTimer > 0f) return
        if (fwd > 0f && fwd < 60f && abs(side) < radiusOf(t.type) + 2.5f && closing > 2f) {
            playAt(tag, t.x, t.y, 170f, 1.0f, 1.0f)
            t.callTimer = 5f + Random.nextFloat() * 4f
        }
    }

    private fun updateThings(dt: Float) {
        loopCount = 0
        for (t in things) {
            if (t.stream != 0) loopCount += 1
        }

        val warnRange = 40f + max(0f, speed) * 2.5f
        var nearestAhead = Float.MAX_VALUE
        var nearestSide = 0f
        var crashed: Thing? = null
        var crashImpact = 0f

        var i = 0
        while (i < things.size) {
            val t = things[i]

            // Vehicles drive along the road. One that comes up to you in its own lane slows down and hoots instead of driving into you.
            if (t.dir != 0f) {
                var want = t.speed
                val inFront = if (t.dir > 0f) routeS - t.s else t.s - routeS   // how far in front of it you are
                if (inFront > 0f && inFront < 20f + t.curSpeed * 1.5f && abs(lateral - t.lat) < radiusOf(t.type) + 1.2f) {
                    want = if (t.dir > 0f) max(0f, min(t.speed, speed - 1f)) else 0f
                    if (t.callTimer <= 0f && inFront < 25f) {
                        val tag = if (t.type == Type.BUS) "horn_bus" else if (t.type == Type.TRUCK) "horn_truck" else "horn_auto"
                        playAt(tag, t.x, t.y, 170f, 1.0f, 1.0f)
                        t.callTimer = 4f + Random.nextFloat() * 2f
                    }
                }
                t.curSpeed += (want - t.curSpeed).coerceIn(-9f * dt, 3f * dt)
                t.s += t.curSpeed * t.dir * dt
                if (t.s < 0f || t.s > ROUTE_M) {
                    removeThingAt(i)
                    continue
                }
                setPoint(t.s, t.lat)
                t.x = tmp[0]
                t.y = tmp[1]
            }

            // far behind you or far away: gone
            val gap = t.s - routeS
            if ((t.dir == 0f && gap < -DESPAWN_BEHIND) || (t.dir != 0f && abs(gap) > 900f)) {
                removeThingAt(i)
                continue
            }

            val dx = t.x - px
            val dy = t.y - py
            val d = sqrt(dx * dx + dy * dy)
            val fwd = dx * hSin + dy * hCos      // metres in front of the car
            val side = dx * hCos - dy * hSin     // metres to the right of the car
            val rel = relAngle(t.x, t.y)
            val closing = speed + (if (t.dir < 0f) t.curSpeed else -t.curSpeed)
            t.callTimer -= dt

            when (t.type) {
                Type.COW -> {
                    if (t.callTimer <= 0f && d < 100f) {
                        playAt("cow_moo", t.x, t.y, 100f, 1.0f, 1.0f)
                        t.callTimer = 4f + Random.nextFloat() * 3f
                    }
                }
                Type.DOG -> {
                    if (t.callTimer <= 0f && d < 80f) {
                        playAt("dog_bark", t.x, t.y, 80f, 1.0f, 1.0f)
                        t.callTimer = 2.5f + Random.nextFloat() * 2f
                    }
                }
                Type.CROWD -> thingLoop(t, "crowd_town_loop", 90f, 0.9f, 1.0f, d, rel)
                Type.BUMP -> bumpCue(t, dt)
                Type.AUTO -> {
                    thingLoop(t, "rickshaw_loop", 100f, 0.8f, 1.0f, d, rel)
                    horn(t, "horn_auto", fwd, side, closing)
                }
                Type.BUS -> {
                    thingLoop(t, "eng_idle", 110f, 0.8f, 0.7f, d, rel)
                    horn(t, "horn_bus", fwd, side, closing)
                }
                Type.TRUCK -> {
                    thingLoop(t, "eng_idle", 110f, 0.8f, 0.6f, d, rel)
                    horn(t, "horn_truck", fwd, side, closing)
                }
                Type.BIKE -> {
                    thingLoop(t, "eng_high", 90f, 0.6f, 1.25f, d, rel)
                    horn(t, "horn_auto", fwd, side, closing)
                }
                Type.CYCLIST -> {
                    if (t.callTimer <= 0f && d < 45f) {
                        playAt("bicycle_bell", t.x, t.y, 60f, 1.0f, 1.0f)
                        t.callTimer = 4f
                    }
                }
            }

            // a vehicle that you pass by: the whoosh of it going past
            if (t.dir != 0f && !t.passed && t.lastAhead >= 0f && fwd < 0f) {
                t.passed = true
                if (abs(side) < 16f && d < 40f) {
                    val tag = if (t.type == Type.BIKE) "moto_pass" else "car_pass"
                    playAt(tag, t.x, t.y, 60f, 1.0f, 1.0f)
                }
            }
            if (t.type != Type.BUMP) t.lastAhead = fwd

            // the parking sensor: the nearest thing in your way
            val radius = radiusOf(t.type)
            if (radius > 0f && fwd > 0f && fwd < warnRange && abs(side) < radius + 1.8f && fwd < nearestAhead) {
                nearestAhead = fwd
                nearestSide = side
            }

            // running into something
            if (radius > 0f && d < radius && crashCooldown <= 0f && crashed == null && (abs(speed) > 0.5f || t.dir != 0f)) {
                crashed = t
                crashImpact = max(0f, closing)
            }
            i += 1
        }

        // soft beeps that get faster and higher as the nearest thing ahead gets closer. They sit on the side where the thing is.
        if (nearestAhead < warnRange) {
            threatTimer -= dt
            if (threatTimer <= 0f) {
                val closeness = (1f - nearestAhead / warnRange).coerceIn(0f, 1f)
                val pan = (nearestSide / 6f).coerceIn(-0.8f, 0.8f)
                sound.playSpatial("warn_beep", pan = pan, volume = 0.45f + 0.45f * closeness, rate = 1.0f + 0.7f * closeness)
                threatTimer = 0.10f + 0.45f * (1f - closeness)
            }
        } else {
            threatTimer = 0f
        }

        val hit = crashed
        if (hit != null) {
            val name = nameOf(hit.type)
            val index = things.indexOf(hit)
            if (index >= 0) removeThingAt(index)
            if (crashImpact < SOFT_IMPACT) {
                // a gentle touch at walking pace: the car stops, nobody is hurt, no life is lost
                crashCooldown = 1.5f
                speed = 0f
                desired = 0f
                sound.playSpatial("wall_thud", pan = 0f, volume = 0.9f)
                sound.vibrate(80)
                say("You bumped a $name. Go slowly.", 2)
            } else {
                loseLife("You hit a $name.", "collision_hit", hit.type == Type.BUS || hit.type == Type.TRUCK)
            }
        }
    }

    /** Low beeps when a speed bump is ahead, and a thump when you cross it. A bump goes right across the road. */
    private fun bumpCue(t: Thing, dt: Float) {
        val ahead = t.s - routeS
        val range = 30f + max(0f, speed) * 1.5f
        if (ahead > 0f && ahead < range && speed > 1f) {
            // low beeps, faster and a little higher as the bump comes closer (its own timer, so it does not mix with the parking sensor)
            bumpTimer -= dt
            if (bumpTimer <= 0f) {
                val closeness = (1f - ahead / range).coerceIn(0f, 1f)
                sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.4f * closeness, rate = 0.6f + 0.4f * closeness)
                bumpTimer = 0.12f + 0.4f * (1f - closeness)
            }
        }
        if (!t.crossed && ahead <= 0f && ahead > -15f && t.lastAhead > 0f) {
            t.crossed = true
            sound.playSpatial("bump_thud", pan = 0f, volume = 1.0f)
            if (speed > 10f) {
                sound.vibrate(100)
                speed *= 0.5f
            }
        }
        t.lastAhead = ahead
    }

    // ---------------------------------------------------------------- traffic lights

    private fun updateLights(dt: Float) {
        for (l in lights) {
            val d = distanceTo(l.x, l.y)
            val ahead = l.s - routeS
            l.timer += dt
            if (l.timer >= LIGHT_CYCLE) {
                // Fair play: a light never turns red under the nose of a car that can no longer stop for it
                val canNotStop = (ahead > 0f || l.lastAhead > 0f) && speed > 2.5f && ahead < speed * speed / (2f * BRAKE) + speed * 1.5f + 10f
                if (canNotStop) l.timer = LIGHT_CYCLE - 0.001f else l.timer -= LIGHT_CYCLE
            }
            val red = l.timer < LIGHT_RED_SECONDS

            if (red != l.red) {
                l.red = red
                // a soft chime when the light turns green and you are waiting at it
                if (!red && d < 120f) sound.playSpatial("ui_select", pan = panFor(relAngle(l.x, l.y)), volume = 0.5f)
            }
            // The beeping pedestrian signal is the sound of a RED light for cars
            if (red && d < 140f) {
                l.beepTimer -= dt
                if (l.beepTimer <= 0f) {
                    playAt("ped_beep", l.x, l.y, 150f, 0.9f, 1.0f)
                    l.beepTimer = 0.55f
                }
            }
            if (!l.announced && ahead > 0f && ahead < 200f) {
                l.announced = true
                say("Traffic signal ahead.", 1, "light")
            }
            if (l.red && l.lastAhead > 0f && ahead <= 0f && speed > 2.5f && crashCooldown <= 0f) {
                l.lastAhead = ahead
                loseLife("You ran a red light.", "police_whistle", false)
                if (isOver) return
            }
            l.lastAhead = ahead
        }
    }

    // ---------------------------------------------------------------- feedback about the road: rumble, guide beeps, off the road

    private fun updateRoadFeedback(dt: Float) {
        val fraction = (abs(speed) / TOP_SPEED).coerceIn(0f, 1f)

        // Rumble on the side of the road you are drifting towards
        val nearEdge = ((edgeDist - (ROAD_HALF - 3f)) / 5f).coerceIn(0f, 1f)
        val rumble = nearEdge * (abs(speed) / 8f).coerceIn(0f, 1f) * 0.6f
        if (rumble > 0.02f) {
            val pan = if (lateral >= 0f) 0.9f else -0.9f
            val rate = 0.8f + 0.4f * fraction
            if (rumbleStream == 0) {
                rumbleStream = sound.playLoop("dirt_loop", pan, rumble, rate)
            } else {
                sound.updateStream(rumbleStream, pan, rumble, rate)
            }
        } else if (rumbleStream != 0) {
            sound.stopStream(rumbleStream)
            rumbleStream = 0
        }

        // Off the road: the GPS says where the road is
        offMsgTimer = max(0f, offMsgTimer - dt)
        if (edgeDist > ROAD_HALF + 1f) {
            offTime += dt
            if (offTime > 1.2f && offMsgTimer <= 0f) {
                offMsgTimer = 9f
                val rel = relAngle(nearX, nearY)
                val where = if (abs(rel) > 135f) "behind you" else if (rel > 0f) "on your right" else "on your left"
                say("Off the road. The road is $where.", 1, "off")
                wasOff = true
            }
            if (abs(speed) > 1f && (offTime * 2f) % 1f < dt * 2f) sound.vibrate(25)
        } else {
            if (wasOff && edgeDist < ROAD_HALF) {
                wasOff = false
                sound.playSpatial("ui_select", pan = 0f, volume = 0.5f)
                say("Back on the road.", 1, "off")
            }
            if (edgeDist < ROAD_HALF) {
                offTime = 0f
                offMsgTimer = 0f
            }
        }

        // Wrong way
        wrongMsgTimer = max(0f, wrongMsgTimer - dt)
        val leg = legs[legIdx]
        if (speed > 3f && abs(angleDiff(leg.heading, heading)) > 125f) {
            wrongTime += dt
            if (wrongTime > 3f && wrongMsgTimer <= 0f) {
                wrongMsgTimer = 12f
                say("You are going the wrong way. Turn around.", 1, "wrong")
            }
        } else {
            wrongTime = 0f
        }

        // Keep left: oncoming traffic uses the right half
        rightMsgTimer = max(0f, rightMsgTimer - dt)
        if (lateral > 1f && !onRightSide) {
            onRightSide = true
            if (speed > 3f) sound.playSpatial("ui_detent", pan = 0.6f, volume = 0.7f)
        } else if (lateral < -1f && onRightSide) {
            onRightSide = false
            if (speed > 3f) sound.playSpatial("ui_detent", pan = -0.6f, volume = 0.7f)
        }
        if (onRightSide && speed > 6f && edgeDist < ROAD_HALF) {
            rightTime += dt
            if (rightTime > 5f && rightMsgTimer <= 0f) {
                rightMsgTimer = 14f
                say("You are on the oncoming side of the road. Keep left.", 1, "right")
            }
        } else {
            rightTime = 0f
        }

        // Guide beeps: they sit on the side the road bends to. Steer towards them; when you are lined up they stop.
        val err = headingError()
        guideTimer -= dt
        if (speed > 2f && abs(err) > 9f) {
            if (guideTimer <= 0f) {
                val amount = (abs(err) / 60f).coerceIn(0f, 1f)
                sound.playSpatial("beep", pan = (err / 40f).coerceIn(-1f, 1f), volume = 0.45f, rate = 1.0f + 0.5f * amount)
                guideTimer = 0.5f - 0.32f * amount
            }
        } else {
            guideTimer = 0f
        }
    }

    // ---------------------------------------------------------------- places you can hear, and the weather

    private fun updatePlaces(dt: Float) {
        for (p in places) {
            p.stream = updateLoop(p.stream, p.tag, p.x, p.y, p.range, p.volume, 1.0f)
        }
        // a bell from Kalimpong, faint from far away
        bellTimer -= dt
        if (bellTimer <= 0f) {
            playAt("temple_bell", destX, destY, 3500f, 0.9f, 1.0f)
            bellTimer = 16f + Random.nextFloat() * 10f
        }
    }

    private fun baseTagFor(zone: Zone): String {
        return when (zone) {
            Zone.CITY, Zone.TOWN -> "crowd_town_loop"
            Zone.HIGHWAY, Zone.VALLEY -> "road_ambience"
            Zone.HILLS -> "jungle_loop"
        }
    }

    private fun baseVolumeFor(zone: Zone): Float {
        return when (zone) {
            Zone.CITY, Zone.TOWN -> 0.14f
            Zone.HIGHWAY -> 0.12f
            Zone.VALLEY -> 0.10f
            Zone.HILLS -> 0.28f
        }
    }

    private fun announceZone(zone: Zone) {
        when (zone) {
            Zone.HIGHWAY -> say("You are out of the city, on the highway. Keep left and watch for oncoming traffic.", 0, "zone")
            Zone.VALLEY -> say("The road follows the river valley.", 0, "zone")
            Zone.HILLS -> say("The hill road begins. Sharp bends ahead. Slow down.", 0, "zone")
            Zone.TOWN -> say("You are entering Kalimpong.", 0, "zone")
            Zone.CITY -> {
            }
        }
    }

    private fun updateAtmosphere(dt: Float) {
        val zone = zoneAt(routeS)
        if (zone != lastZone) {
            if (zone.ordinal > lastZone.ordinal) announceZone(zone)
            lastZone = zone
        }

        // the sound of the surroundings changes with the place
        val tag = baseTagFor(zone)
        if (tag != baseTag) {
            sound.stopStream(baseStream)
            baseStream = 0
            baseTag = tag
            baseVolume = 0f
        }
        baseVolume += (baseVolumeFor(zone) - baseVolume) * min(1f, dt * 0.6f)
        if (baseStream == 0) {
            baseStream = sound.playLoop(baseTag, 0f, baseVolume, 1.0f)
        } else {
            sound.updateStream(baseStream, 0f, baseVolume, 1.0f)
        }

        // rain in the hills, with thunder
        val rainTarget = if (routeS in RAIN_FROM_M..RAIN_TO_M) 0.45f else 0f
        rainVolume += (rainTarget - rainVolume) * min(1f, dt * 0.5f)
        if (rainVolume > 0.02f) {
            if (rainStream == 0) {
                rainStream = sound.playLoop("rain_loop", 0f, rainVolume, 1.0f)
            } else {
                sound.updateStream(rainStream, 0f, rainVolume, 1.0f)
            }
        } else if (rainStream != 0) {
            sound.stopStream(rainStream)
            rainStream = 0
        }
        if (rainVolume > 0.2f) {
            thunderTimer -= dt
            if (thunderTimer <= 0f) {
                sound.playSpatial("thunder_roll", pan = (Random.nextFloat() - 0.5f) * 1.6f, volume = 0.7f)
                thunderTimer = 20f + Random.nextFloat() * 25f
            }
        }

        // owls in the dark hills
        if (zone == Zone.HILLS) {
            owlTimer -= dt
            if (owlTimer <= 0f) {
                sound.playSpatial("owl_hoot", pan = (Random.nextFloat() - 0.5f) * 1.8f, volume = 0.5f)
                owlTimer = 14f + Random.nextFloat() * 16f
            }
        }

        // two bridges over the river: it gets louder as you near, and the planks creak
        var riverTarget = 0f
        var onBridge = false
        for (k in BRIDGES.indices) {
            val centre = BRIDGES[k]
            val d = abs(routeS - centre)
            riverTarget = max(riverTarget, 0.5f * (1f - d / 400f).coerceIn(0f, 1f))
            if (d < BRIDGE_LENGTH / 2f) {
                onBridge = true
                if (!bridgeAnnounced[k]) {
                    bridgeAnnounced[k] = true
                    say("Crossing a bridge over the river.", 1, "bridge")
                }
            }
        }
        riverVolume += (riverTarget - riverVolume) * min(1f, dt * 2f)
        if (riverVolume > 0.02f) {
            if (riverStream == 0) {
                riverStream = sound.playLoop("river_loop", 0f, riverVolume, 1.0f)
            } else {
                sound.updateStream(riverStream, 0f, riverVolume, 1.0f)
            }
        } else if (riverStream != 0) {
            sound.stopStream(riverStream)
            riverStream = 0
        }
        if (onBridge && speed > 1f) {
            creakTimer -= dt
            if (creakTimer <= 0f) {
                sound.playSpatial("bridge_creak", pan = 0f, volume = 0.4f)
                creakTimer = 3f
            }
        }
    }

    // ---------------------------------------------------------------- GPS

    private fun announceLeg(index: Int) {
        val leg = legs[index]
        val distance = max(0f, leg.endM - routeS)
        if (index >= legs.size - 1) {
            say("Continue straight for ${distWord(distance)} to the $DESTINATION.", 0, "leg")
        } else {
            say("Continue for ${distWord(distance)}, then ${turnWord(leg.turnAtEnd)}.", 0, "leg")
        }
    }

    private fun announceStage(stage: Int, leg: Leg, distance: Float) {
        val word = turnWord(leg.turnAtEnd)
        val slow = if (abs(leg.turnAtEnd) >= 60f) " Slow down." else ""
        when (stage) {
            0 -> say("In ${distWord(distance)}, $word.$slow", 0, "turn")
            1 -> say("In ${distWord(distance)}, $word.$slow", 1, "turn")
            2 -> say("In ${distWord(distance)}, $word.$slow", 1, "turn")
            else -> say("${capitalised(word)} now.", 2)
        }
    }

    private fun speakGpsNow() {
        val leg = legs[legIdx]
        val left = max(0f, ROUTE_M - routeS)
        val text = if (legIdx >= legs.size - 1) {
            "Continue straight. ${distWord(left)} to the $DESTINATION."
        } else {
            "Next, ${turnWord(leg.turnAtEnd)} in ${distWord(max(0f, leg.endM - routeS))}. ${distWord(left)} to go."
        }
        say(text, 2)
    }

    private fun updateGps() {
        // you came to the next straight piece of road
        if (legIdx != gpsLeg) {
            val forward = legIdx > gpsLeg
            gpsLeg = legIdx
            if (forward) {
                announceLeg(legIdx)
                if (abs(angleDiff(legs[legIdx].heading, heading)) < 35f) sound.playSpatial("ui_select", pan = 0f, volume = 0.5f)
            }
        }

        // warnings about the next turn, further ahead and then closer
        if (legIdx < legs.size - 1) {
            val leg = legs[legIdx]
            val distance = leg.endM - routeS
            val nowDistance = (max(0f, speed) * 2.2f).coerceIn(40f, 90f)
            var reached = 0
            if (distance <= 1000f) reached = 1
            if (distance <= 400f) reached = 2
            if (distance <= 150f) reached = 3
            if (distance <= nowDistance) reached = 4
            if (reached > stageDone[legIdx]) {
                stageDone[legIdx] = reached
                announceStage(reached - 1, leg, distance)
            }
        }

        // how far is left, and checkpoints
        if (bestS >= nextReportM && nextReportM < ROUTE_M - 1000f) {
            val left = ROUTE_M - nextReportM
            var text = "${distWord(left)} to go."
            if (bestS >= nextCheckpointM) {
                text = "Checkpoint. $text"
                if (lives < START_LIVES) {
                    lives += 1
                    text += " A life is restored. You have $lives."
                }
                nextCheckpointM += CHECKPOINT_M
            }
            say(text, 0, "report")
            nextReportM += REPORT_M
        }
    }

    // ---------------------------------------------------------------- hooks for the automatic tests

    internal fun dbgRouteS(): Float = routeS
    internal fun dbgLateral(): Float = lateral
    internal fun dbgEdge(): Float = edgeDist
    internal fun dbgSpeed(): Float = speed
    internal fun dbgDesired(): Float = desired
    internal fun dbgHeading(): Float = heading
    internal fun dbgGuideError(): Float = headingError()
    internal fun dbgLegCount(): Int = legs.size
    internal fun dbgLegTurns(): List<Float> = legs.map { it.turnAtEnd }
    internal fun dbgLegLengths(): List<Float> = legs.map { it.length }
    internal fun dbgThingCount(): Int = things.size
    internal fun dbgLives(): Int = lives
    internal fun dbgIsOver(): Boolean = isOver
    /** Things ahead: [metres ahead along the road, lat, radius, speed along the road (negative = oncoming), 1 if a speed bump]. */
    internal fun dbgThreats(): List<FloatArray> {
        val out = ArrayList<FloatArray>()
        for (t in things) {
            val ahead = t.s - routeS
            if (ahead > -10f && ahead < 300f) {
                out.add(floatArrayOf(ahead, t.lat, radiusOf(t.type), t.dir * t.curSpeed, if (t.type == Type.BUMP) 1f else 0f))
            }
        }
        return out
    }
    /** The next traffic signal ahead: [metres ahead, 1 if red]. Null if there is none within 300 m. */
    internal fun dbgNextLight(): FloatArray? {
        var best: Light? = null
        for (l in lights) {
            val ahead = l.s - routeS
            if (ahead > 0f && ahead < 300f && (best == null || ahead < best.s - routeS)) best = l
        }
        val b = best ?: return null
        return floatArrayOf(b.s - routeS, if (b.red) 1f else 0f)
    }
    internal fun dbgPlace(x: Float, y: Float, headingDeg: Float) {
        px = x
        py = y
        heading = headingDeg
        updateTrig()
        locate()
    }
    internal fun dbgBoundingBox(): FloatArray {
        var minX = Float.MAX_VALUE
        var maxX = -Float.MAX_VALUE
        var minY = Float.MAX_VALUE
        var maxY = -Float.MAX_VALUE
        for (leg in legs) {
            minX = min(minX, min(leg.x0, leg.x0 + leg.dx * leg.length))
            maxX = max(maxX, max(leg.x0, leg.x0 + leg.dx * leg.length))
            minY = min(minY, min(leg.y0, leg.y0 + leg.dy * leg.length))
            maxY = max(maxY, max(leg.y0, leg.y0 + leg.dy * leg.length))
        }
        return floatArrayOf(minX, maxX, minY, maxY)
    }
}
