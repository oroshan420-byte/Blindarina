package com.blindarena

import android.content.Context
import java.util.TimeZone

// =========================================================================
// RECORDS AND THE DAILY CHALLENGE
//
//  - Records: the best result of every game is saved in the phone, so it is still there tomorrow.
//    The games say "Your best is ..." when they start and "New record!" when you beat it.
//  - Daily challenge: one small goal per day ("In Arcade Rush, reach level 4"). It is chosen from the date, so it is
//    the same all day and changes at midnight. The games tell you when you have done it, and the number of days in a row is counted.
//  - Only the sounds that were already in the app are used (no new sound files).
// =========================================================================

/** Where the numbers are kept. The phone uses PrefsStore; the automatic tests use MemoryStore. */
interface KeyValueStore {
    fun getInt(key: String, default: Int): Int
    fun putInt(key: String, value: Int)
}

class MemoryStore : KeyValueStore {
    private val map = HashMap<String, Int>()

    override fun getInt(key: String, default: Int): Int = map[key] ?: default

    override fun putInt(key: String, value: Int) {
        map[key] = value
    }
}

/** Saves the numbers in the app's private settings file, so they stay after the app is closed. */
class PrefsStore(context: Context) : KeyValueStore {
    private val prefs = context.getSharedPreferences("blindarena_records", Context.MODE_PRIVATE)

    override fun getInt(key: String, default: Int): Int {
        return try {
            prefs.getInt(key, default)
        } catch (e: Exception) {
            default
        }
    }

    override fun putInt(key: String, value: Int) {
        try {
            prefs.edit().putInt(key, value).apply()
        } catch (e: Exception) {
            // saving is a bonus: the game goes on without it
        }
    }
}

/** What to add to the end of a game's last message, and whether to play the "new record" sound. */
class Outcome(val text: String, val newRecord: Boolean)

fun timesWord(n: Int): String = if (n == 1) "1 time" else "$n times"

/** 850 -> "850 meters", 12300 -> "12.3 kilometres". */
fun distanceText(meters: Int): String {
    if (meters < 1000) return if (meters == 1) "1 meter" else "$meters meters"
    val tenths = Math.round(meters / 100f)
    return if (tenths == 10) {
        "1 kilometre"
    } else if (tenths % 10 == 0) {
        "${tenths / 10} kilometres"
    } else {
        "${tenths / 10}.${tenths % 10} kilometres"
    }
}

fun minutesText(seconds: Int): String {
    val m = Math.max(1, (seconds + 30) / 60)
    return if (m == 1) "1 minute" else "$m minutes"
}

object Records {
    const val RUSH_SCORE = "rush_score"
    const val RUSH_RUNS = "rush_runs"
    const val HIGHWAY_M = "highway_m"
    const val HIGHWAY_RUNS = "highway_runs"
    const val JUNGLE_M = "jungle_m"
    const val JUNGLE_WINS = "jungle_wins"
    const val KALIMPONG_M = "kalimpong_m"
    const val KALIMPONG_ARRIVALS = "kalimpong_arrivals"
    const val KALIMPONG_FASTEST_S = "kalimpong_fastest_s"

    val CRICKET_OVERS = listOf(1, 2, 3, 5, 10)

    var store: KeyValueStore = MemoryStore()

    /** The number of today (days since 1970 in the phone's own time zone). The tests replace it. */
    var dayProvider: () -> Int = { systemDay() }

    /** The day number of a moment in time (milliseconds since 1970 in UTC), seen from a time zone with this offset. */
    fun dayOf(utcMillis: Long, zoneOffsetMillis: Int): Int {
        return Math.floorDiv(utcMillis + zoneOffsetMillis, 86_400_000L).toInt()
    }

    private fun systemDay(): Int {
        val now = System.currentTimeMillis()
        return dayOf(now, TimeZone.getDefault().getOffset(now))
    }

    fun today(): Int = dayProvider()

    fun get(key: String): Int = store.getInt(key, 0)

    fun set(key: String, value: Int) {
        store.putInt(key, value)
    }

    fun add(key: String, by: Int = 1): Int {
        val v = get(key) + by
        set(key, v)
        return v
    }

    /** Saves the value when it is higher than the best. True only when it beat an EARLIER result (the very first result is not a "record"). */
    fun submitHigher(key: String, value: Int): Boolean {
        val old = get(key)
        if (value > old) {
            set(key, value)
            return old > 0
        }
        return false
    }

    /** Same for results where LOWER is better (a time). 0 means "no result yet". */
    fun submitLower(key: String, value: Int): Boolean {
        val old = get(key)
        if (value > 0 && (old == 0 || value < old)) {
            set(key, value)
            return old > 0
        }
        return false
    }

    /** Saves a "higher is better" result and says what to add to the end text. */
    fun saveHigher(key: String, value: Int, describe: (Int) -> String): Outcome {
        val prev = get(key)
        val better = submitHigher(key, value)
        return when {
            better -> Outcome(" New record! Your old best was ${describe(prev)}.", true)
            prev == 0 && value > 0 -> Outcome(" Your first result is saved. Try to beat it.", false)
            prev > 0 -> Outcome(" Your best is ${describe(prev)}.", false)
            else -> Outcome("", false)
        }
    }

    fun playNewRecord(sound: SoundManager) {
        sound.playSpatial("crowd_applause", pan = 0f, volume = 0.9f)
    }

    // ---------------------------------------------------------------- what each game says at the start

    fun rushNote(): String {
        val best = get(RUSH_SCORE)
        return if (best > 0) "Your best score is $best. " else ""
    }

    fun highwayNote(): String {
        val best = get(HIGHWAY_M)
        return if (best > 0) "Your best is ${distanceText(best)}. " else ""
    }

    fun jungleNote(): String {
        val best = get(JUNGLE_M)
        val wins = get(JUNGLE_WINS)
        var text = ""
        if (best > 0) text += "Your furthest is ${distanceText(best)}. "
        if (wins > 0) text += "You have reached the village ${timesWord(wins)}. "
        return text
    }

    fun kalimpongNote(): String {
        val best = get(KALIMPONG_M)
        val arrivals = get(KALIMPONG_ARRIVALS)
        var text = ""
        if (arrivals > 0) {
            text += "You have arrived ${timesWord(arrivals)}. Your fastest drive took ${minutesText(get(KALIMPONG_FASTEST_S))}. "
        } else if (best > 0) {
            text += "Your furthest is ${distanceText(best)}. "
        }
        return text
    }

    // ---------------------------------------------------------------- what each game says at the end

    fun rushFinished(score: Int): Outcome {
        add(RUSH_RUNS)
        return saveHigher(RUSH_SCORE, score) { "$it" }
    }

    fun highwayFinished(meters: Int): Outcome {
        add(HIGHWAY_RUNS)
        return saveHigher(HIGHWAY_M, meters) { distanceText(it) }
    }

    fun jungleLost(meters: Int): Outcome = saveHigher(JUNGLE_M, meters) { distanceText(it) }

    fun jungleWon(goalMeters: Int): Outcome {
        val wins = add(JUNGLE_WINS)
        submitHigher(JUNGLE_M, goalMeters)
        return Outcome(" You have reached the village ${timesWord(wins)}.", false)
    }

    fun kalimpongLost(meters: Int): Outcome = saveHigher(KALIMPONG_M, meters) { distanceText(it) }

    fun kalimpongWon(routeMeters: Int, seconds: Int): Outcome {
        val arrivals = add(KALIMPONG_ARRIVALS)
        submitHigher(KALIMPONG_M, routeMeters)
        val prev = get(KALIMPONG_FASTEST_S)
        val faster = submitLower(KALIMPONG_FASTEST_S, seconds)
        return if (faster) {
            Outcome(" New record! Your fastest drive was ${minutesText(prev)} before. You have arrived ${timesWord(arrivals)}.", true)
        } else {
            Outcome(" You have arrived ${timesWord(arrivals)}. Your fastest drive took ${minutesText(get(KALIMPONG_FASTEST_S))}.", false)
        }
    }

    /** Hand Cricket: the best innings of the player for this number of overs. Empty text when it is not a best. */
    fun cricketInnings(overs: Int, runs: Int): Outcome {
        val key = "cricket_best_o$overs"
        val prev = get(key)
        val better = submitHigher(key, runs)
        return if (better) {
            Outcome(" That is your best score for ${if (overs == 1) "1 over" else "$overs overs"}! The old best was $prev.", true)
        } else {
            Outcome("", false)
        }
    }

    fun seasonFinishName(finish: Int): String = when (finish) {
        FINISH_LEAGUE -> "the league stage"
        FINISH_PLAYOFFS -> "the playoffs"
        FINISH_RUNNER_UP -> "runner-up"
        FINISH_CHAMPION -> "champion"
        else -> "none yet"
    }

    /** A Premier League season is over for the player: how far he got (a FINISH_ constant of Season.kt). */
    fun seasonFinished(finish: Int): Outcome {
        add("season_played")
        val titles = if (finish == FINISH_CHAMPION) add("season_titles") else get("season_titles")
        val prev = get("season_best")
        val better = submitHigher("season_best", finish)
        var text = ""
        if (better) text += " New record! Your best finish before was ${seasonFinishName(prev)}."
        if (finish == FINISH_CHAMPION) text += " You have now won the Premier League ${timesWord(titles)}."
        return Outcome(text, better)
    }

    /** A match of Hand Cricket ("cricket") or a duel of Gun Fight ("gun") is over: games played, games won, wins in a row. */
    fun matchFinished(game: String, noun: String, won: Boolean, tied: Boolean): Outcome {
        val played = add("${game}_played")
        var text = ""
        var record = false
        if (won) {
            add("${game}_won")
            val streak = add("${game}_streak")
            if (streak > get("${game}_best_streak")) {
                set("${game}_best_streak", streak)
                if (streak >= 2) {
                    text = " New record! $streak wins in a row."
                    record = true
                }
            } else if (streak >= 2) {
                text = " $streak wins in a row."
            }
        } else if (!tied) {
            set("${game}_streak", 0)
        }
        val wonTotal = get("${game}_won")
        val nounWord = if (played == 1) (if (noun == "matches") "match" else if (noun == "duels") "duel" else noun) else noun
        return Outcome(" You have won $wonTotal of $played $nounWord.$text", record)
    }

    // ---------------------------------------------------------------- the records screen

    fun rushLine(): String {
        val runs = get(RUSH_RUNS)
        if (runs == 0) return "You have not played this yet."
        return "Best score ${get(RUSH_SCORE)}. Played ${timesWord(runs)}."
    }

    fun highwayLine(): String {
        val runs = get(HIGHWAY_RUNS)
        if (runs == 0) return "You have not played this yet."
        return "Best ${distanceText(get(HIGHWAY_M))}. Played ${timesWord(runs)}."
    }

    fun jungleLine(): String {
        val best = get(JUNGLE_M)
        if (best == 0) return "You have not played this yet."
        return "Furthest ${distanceText(best)}. Reached the village ${timesWord(get(JUNGLE_WINS))}."
    }

    fun kalimpongLine(): String {
        val best = get(KALIMPONG_M)
        if (best == 0) return "You have not played this yet."
        val arrivals = get(KALIMPONG_ARRIVALS)
        return if (arrivals > 0) {
            "Arrived ${timesWord(arrivals)}. Fastest drive ${minutesText(get(KALIMPONG_FASTEST_S))}."
        } else {
            "Furthest ${distanceText(best)}. You have not arrived yet."
        }
    }

    fun cricketLine(): String {
        val played = get("cricket_played")
        if (played == 0) return "You have not played this yet."
        var text = "Won ${get("cricket_won")} of $played ${if (played == 1) "match" else "matches"}. Best winning streak ${get("cricket_best_streak")}."
        val bests = ArrayList<String>()
        for (o in CRICKET_OVERS) {
            val b = get("cricket_best_o$o")
            if (b > 0) bests.add("$b in ${if (o == 1) "1 over" else "$o overs"}")
        }
        if (bests.isNotEmpty()) text += " Best scores: ${bests.joinToString(", ")}."
        val seasons = get("season_played")
        if (seasons > 0) {
            text += " Premier League: ${if (seasons == 1) "1 season" else "$seasons seasons"}, champion ${timesWord(get("season_titles"))}, best finish ${seasonFinishName(get("season_best"))}."
        }
        return text
    }

    fun gunLine(): String {
        val played = get("gun_played")
        if (played == 0) return "You have not played this yet."
        var text = "Won ${get("gun_won")} of $played ${if (played == 1) "duel" else "duels"}. Best winning streak ${get("gun_best_streak")}."
        val parts = ArrayList<String>()
        for (d in DUEL_DIFFICULTIES) {
            val w = get("gun_wins_${d.name}")
            if (w > 0) parts.add("${d.name} $w")
        }
        if (parts.isNotEmpty()) text += " Wins by difficulty: ${parts.joinToString(", ")}."
        return text
    }

    /** Label and spoken line of every entry of the records screen. */
    fun allLines(): List<Pair<String, String>> {
        return listOf(
            "Daily challenge" to Daily.describe(),
            "Arcade Rush" to rushLine(),
            "Highway" to highwayLine(),
            "Jungle road" to jungleLine(),
            "Long drive to Kalimpong" to kalimpongLine(),
            "Hand Cricket" to cricketLine(),
            "Gun Fight" to gunLine()
        )
    }
}

/** One small goal for the day. metric says what is measured, target how much is needed. */
class Challenge(val metric: String, val target: Int, val text: String)

object Daily {
    const val RUSH_LEVEL = "rush_level"
    const val RUSH_BELLS = "rush_bells"
    const val RUSH_PASSES = "rush_passes"
    const val HIGHWAY_M = "highway_m"
    const val JUNGLE_M = "jungle_m"
    const val KALIMPONG_M = "kalimpong_m"
    const val CRICKET_WIN = "cricket_win"
    const val CRICKET_RUNS = "cricket_runs"
    const val GUN_WIN = "gun_win"

    /** The challenges come round in this order, one a day. */
    val all: List<Challenge> = listOf(
        Challenge(RUSH_LEVEL, 4, "In Arcade Rush, reach level 4."),
        Challenge(CRICKET_WIN, 1, "Win a Hand Cricket match."),
        Challenge(HIGHWAY_M, 1000, "On the Highway, drive 1000 meters."),
        Challenge(GUN_WIN, 2, "Win a Gun Fight duel on Medium or Hard."),
        Challenge(RUSH_BELLS, 3, "In Arcade Rush, catch 3 bells in one run."),
        Challenge(JUNGLE_M, 2500, "On the Jungle road, drive 2500 meters."),
        Challenge(CRICKET_RUNS, 15, "In Hand Cricket, score 15 runs in one innings of 2 or more overs."),
        Challenge(KALIMPONG_M, 5000, "On the long drive to Kalimpong, drive 5 kilometres."),
        Challenge(RUSH_PASSES, 30, "In Arcade Rush, pass 30 vehicles in one run.")
    )

    // The day number is stored plus one, so that 0 can mean "never"
    private const val KEY_DONE = "daily_done_day"
    private const val KEY_STREAK = "daily_streak"
    private const val KEY_TOTAL = "daily_total"

    private var menuMentioned = false

    fun today(): Challenge = all[Math.floorMod(Records.today(), all.size)]

    fun isDoneToday(): Boolean = Records.get(KEY_DONE) == Records.today() + 1

    /** How many days in a row the challenge was done, counting today if it is done. 0 when yesterday was missed. */
    fun streak(): Int {
        val last = Records.get(KEY_DONE)
        val day = Records.today() + 1
        return if (last == day || last == day - 1) Records.get(KEY_STREAK) else 0
    }

    /**
     * A game tells what it measured. Returns true exactly once a day: when this result completes today's challenge.
     * The game then calls announce (or says completionText itself).
     */
    fun report(metric: String, value: Int): Boolean {
        val c = today()
        if (c.metric != metric || value < c.target) return false
        if (isDoneToday()) return false
        val day = Records.today() + 1
        val last = Records.get(KEY_DONE)
        val streak = if (last == day - 1) Records.get(KEY_STREAK) + 1 else 1
        Records.set(KEY_DONE, day)
        Records.set(KEY_STREAK, streak)
        Records.add(KEY_TOTAL)
        return true
    }

    fun completionText(): String {
        val s = streak()
        val more = if (s >= 2) "That is $s days in a row." else "Come back tomorrow for a new one."
        return "Daily challenge complete! $more"
    }

    fun playSound(sound: SoundManager) {
        sound.playSpatial("cheer", pan = 0f, volume = 0.9f)
        sound.playSpatial("temple_bell", pan = 0f, volume = 0.8f)
    }

    /**
     * Sound and words together. The words wait for the sentence that is being spoken, unless the game has a voice queue
     * of its own: then it passes it as speak.
     */
    fun announce(sound: SoundManager, speak: ((String) -> Unit)? = null) {
        playSound(sound)
        val text = completionText()
        if (speak != null) speak(text) else MyScreenReader.speak(text, flush = false)
    }

    /** "Today's challenge: ..." when today's challenge belongs to this game and is not done yet. Empty otherwise. */
    fun hint(vararg metrics: String): String {
        val c = today()
        if (isDoneToday()) return ""
        for (m in metrics) {
            if (c.metric == m) return "Today's challenge: ${c.text} "
        }
        return ""
    }

    /** Said once when the app starts, on the main menu, until the challenge is done. */
    fun menuHint(): String {
        if (menuMentioned || isDoneToday()) return ""
        menuMentioned = true
        return " Today's challenge: ${today().text}"
    }

    /** Everything about today's challenge, for the records screen. */
    fun describe(): String {
        val c = today()
        val s = streak()
        var text = c.text
        text += if (isDoneToday()) " Done today!" else " Not done yet."
        if (s >= 1) text += " $s ${if (s == 1) "day" else "days"} in a row."
        val total = Records.get(KEY_TOTAL)
        if (total > 0) text += " Done ${timesWord(total)} in all."
        return text
    }

    /** For the tests. */
    internal fun resetMenuHint() {
        menuMentioned = false
    }
}
