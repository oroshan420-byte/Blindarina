package com.blindarena

import kotlin.random.Random

// =========================================================================
// THE NUMBER HABITS OF THE COMPUTER PLAYERS
//
// Every number the computer picks comes from here. A normal match uses the plain "random" player (every number the same chance).
// In the Premier League season (Season.kt) each team has a star with his own habits:
//  - weights: how much he likes each number 1 to 6 (a big hitter likes 5 and 6, a careful player likes 1 to 3)
//  - copyChance: how often he repeats the number you showed last (when he bowls, to try to get you out)
//  - learnChance: how often he uses what he has seen of YOU (your favourite numbers) instead of his own habit
// The computer never looks at the number you pick for the ball that is being played: it only remembers earlier balls.
// A player who picks numbers at random cannot be read by anyone, so the habits only help against predictable people.
// =========================================================================

class CricketBot(
    val name: String,
    /** How much he likes the numbers 1, 2, 3, 4, 5, 6. */
    val weights: IntArray,
    val copyChance: Float,
    val learnChance: Float
)

object CricketBots {
    /** Used in a normal match: every number has the same chance. */
    val random = CricketBot("The computer", intArrayOf(1, 1, 1, 1, 1, 1), 0f, 0f)
}

/** The mind of one computer player for one match: it remembers what the other side picked in the earlier balls. */
class BotBrain(val bot: CricketBot, private val rnd: Random = Random) {

    private val batPicks = IntArray(7)    // the numbers the other side picked while it was batting
    private val bowlPicks = IntArray(7)   // the numbers the other side picked while it was bowling
    private var lastOther = 0

    /** Tell the brain what the other side picked, AFTER the ball is played. */
    fun observe(otherNumber: Int, otherBatting: Boolean) {
        if (otherNumber < 1 || otherNumber > 6) return
        if (otherBatting) batPicks[otherNumber] += 1 else bowlPicks[otherNumber] += 1
        lastOther = otherNumber
    }

    /** The number for the next ball. otherBatting: the other side is batting, so this player bowls and wants the same number. */
    fun pick(otherBatting: Boolean): Int {
        if (otherBatting) {
            if (lastOther != 0 && rnd.nextFloat() < bot.copyChance) return lastOther
            if (rnd.nextFloat() < bot.learnChance) {
                val n = sampleFrom(batPicks)
                if (n != 0) return n
            }
        } else {
            // this player bats: he wants runs and does not want the number that the bowler is likely to pick
            if (rnd.nextFloat() < bot.learnChance) {
                val n = bestAvoiding(bowlPicks)
                if (n != 0) return n
            }
        }
        return fromWeights()
    }

    private fun fromWeights(): Int {
        var total = 0
        for (w in bot.weights) total += w
        var r = rnd.nextInt(total)
        for (i in bot.weights.indices) {
            r -= bot.weights[i]
            if (r < 0) return i + 1
        }
        return 6
    }

    /** One of the numbers the other side picked, the more often it picked it the more likely. 0 when there is too little to go on. */
    private fun sampleFrom(counts: IntArray): Int {
        var total = 0
        for (i in 1..6) total += counts[i]
        if (total < 3) return 0
        var r = rnd.nextInt(total)
        for (i in 1..6) {
            r -= counts[i]
            if (r < 0) return i
        }
        return 0
    }

    /** A high number (4, 5 or 6) that the bowler has picked the least. 0 when there is too little to go on. */
    private fun bestAvoiding(counts: IntArray): Int {
        var total = 0
        for (i in 1..6) total += counts[i]
        if (total < 3) return 0
        var fewest = Int.MAX_VALUE
        for (i in 4..6) if (counts[i] < fewest) fewest = counts[i]
        val candidates = ArrayList<Int>()
        for (i in 4..6) if (counts[i] == fewest) candidates.add(i)
        return candidates[rnd.nextInt(candidates.size)]
    }
}
