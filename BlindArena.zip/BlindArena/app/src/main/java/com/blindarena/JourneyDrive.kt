package com.blindarena

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan
import kotlin.random.Random

// =========================================================================
// JOURNEY: Siliguri to Kalimpong, 70 kilometres, to the hostel of the
// Mary Scott Home School for the Blind. To keep the game playable the road is
// 6 times shorter than the real one (about 15 minutes of driving); the GPS and
// the screen talk in real kilometres.
//
// You drive with ONE finger (drag up = forward, down = reverse, sideways = steer,
// lift = stop). The GPS tells you where to turn. The road goes through:
//  - Siliguri city: traffic, crowds, cows, speed bumps, traffic lights (beeping signal = RED)
//  - Sevoke forest: deer, monkeys, elephants, fallen trees, potholes
//  - Coronation Bridge: very narrow, with the Teesta river below
//  - Teesta valley: trucks, landslide rocks, rain and thunder
//  - the hill road: many hairpin bends
//  - Kalimpong: market, crowds, children at the hostel
// =========================================================================

private val JOURNEY_ROUTE = listOf(
    "F200", "SL", "F150", "F150", "T8", "F150", "F150", "T-9", "F100", "SR",
    "F150", "F150", "T-8", "F150", "F50", "F160", "T-12", "F160", "T23", "F160",
    "T18", "F20", "XL", "F160", "T-10", "F160", "T-16", "F160", "T-24", "F160",
    "T12", "F60", "SR", "F160", "T-12", "F160", "T12", "F160", "T-25", "F160",
    "T-13", "F60", "F300", "B200", "F200", "F140", "T-34", "F140", "T-32", "F140",
    "T21", "F140", "T-25", "F140", "T-18", "F140", "T-34", "F140", "T20", "F140",
    "T23", "F80", "XR", "F140", "T-20", "F140", "T20", "F140", "T-27", "F140",
    "T15", "F140", "T31", "F140", "T29", "F140", "T-24", "F20", "SL", "F140",
    "T-15", "F140", "T-34", "F140", "T32", "F140", "T-26", "F140", "T22", "F140",
    "T-24", "F140", "T-27", "F140", "T-16", "F140", "T-34", "F40", "F220", "HR",
    "F220", "HL", "F220", "HR", "F220", "HL", "F220", "HR", "F160", "XL",
    "F100", "F220", "HL", "F220", "HR", "F220", "HL", "F220", "HR", "F220",
    "HL", "F90", "F200", "SR", "F120", "F120", "T7", "F120", "F40", "XR",
    "F120", "F120", "T11", "F120", "F87", "F120",
)

class JourneyGame(
    private val sound: SoundManager,
    private val onOver: (String, Boolean) -> Unit
) : DriveGame {

    private enum class Type { COW, DOG, CROWD, BUMP, AUTO, BUS, TRUCK, BIKE, CYCLIST, DEER, MONKEY, ELEPHANT, TREE, ROCK, POTHOLE }

    private class Seg(val ax: Float, val ay: Float, val x2: Float, val y2: Float, val half: Float, val main: Boolean, val s0: Float) {
        val len: Float = sqrt((x2 - ax) * (x2 - ax) + (y2 - ay) * (y2 - ay))
        val dx: Float = (x2 - ax) / len
        val dy: Float = (y2 - ay) / len
    }

    // kind: 0 side road, 1 turn right, 2 turn left, 3 hairpin right, 4 hairpin left, 5 bridge
    private class Event(val s: Float, val kind: Int) {
        var announced: Boolean = false
        var nowSpoken: Boolean = false
    }

    private class Thing(val type: Type, var x: Float, var y: Float) {
        var s: Float = 0f
        var lateral: Float = 0f
        var dirSign: Float = 1f
        var speed: Float = 0f
        var mover: Boolean = false
        var callTimer: Float = 0f
        var beepTimer: Float = 0f
        var leaveTimer: Float = 0f
        var stream: Int = 0
        var gone: Boolean = false
        var heard: Boolean = false
        var crossed: Boolean = false
    }

    private class Light(val x: Float, val y: Float) {
        var timer: Float = 0f
        var red: Boolean = false
        var beepTimer: Float = 0f
        var fined: Boolean = false
    }

    private class Source(val x: Float, val y: Float, val tag: String, val range: Float, val volume: Float) {
        var stream: Int = 0
    }

    private class Ambient(val tag: String) {
        var volume: Float = 0f
        var stream: Int = 0
    }

    companion object {
        const val SCALE = 6f              // 1 game metre = 6 real metres
        const val ROAD_HALF = 9f
        const val BRIDGE_HALF = 4.5f
        const val TOP_SPEED = 20f
        const val REVERSE_TOP = 6f
        const val ACCEL = 5f
        const val BRAKE = 10f
        const val WHEELBASE = 2.7f
        const val MAX_STEER = 0.61f
        const val START_LIVES = 5
        const val MAX_LIVES = 5
        const val GAME_OVER_SECONDS = 3.0f
        const val LIGHT_CYCLE = 16f
        const val LIGHT_RED_SECONDS = 6f
        const val ARRIVE_DISTANCE = 30f
        const val SPAWN_AHEAD = 260f
    }

    // the road map
    private val segs = ArrayList<Seg>()
    private val events = ArrayList<Event>()
    private var totalS = 0f
    private var lastMainSeg: Seg? = null
    private var hostelX = 0f
    private var hostelY = 0f
    private var curX = 0f
    private var curY = 0f
    private var curH = 0f
    private var curS = 0f

    // the car: x grows to the east, y to the north. Heading: 0 = north, 90 = east
    private var px = 0f
    private var py = 30f
    private var heading = 0f
    private var speed = 0f
    private var crashCooldown = 0f
    private var bumpTimer = 0f
    private var skidTimer = 0f
    private var wasFast = false

    // where you are on the main road
    private var routeS = 30f
    private var mainDistance = 0f
    private var routeDx = 0f
    private var routeDy = 1f

    var lives: Int = START_LIVES
        private set

    override val title: String
        get() = "SILIGURI TO KALIMPONG"
    override val line1: String
        get() = "${(abs(speed) * 3.6f).toInt()} km/h   ${compassName(heading)}"
    override val line2: String
        get() = "Lives $lives   ${Math.round(routeS * SCALE / 100f) / 10f} of ${Math.round(totalS * SCALE / 1000f)} km"
    override val usesStick: Boolean
        get() = true

    private val engine = EngineSound(sound)
    private val things = ArrayList<Thing>()
    private val lights = ArrayList<Light>()
    private val sources = ArrayList<Source>()
    private val jungleAmbient = Ambient("jungle_loop")
    private val townAmbient = Ambient("crowd_town_loop")
    private val riverAmbient = Ambient("river_loop")
    private val rainAmbient = Ambient("rain_loop")
    private var reverseStream = 0
    private var indicatorStream = 0
    private var frontBeepTimer = 0f
    private var leftBeepTimer = 0f
    private var rightBeepTimer = 0f
    private var templeTimer = 10f
    private var thunderTimer = 10f
    private var creakTimer = 0f

    private var nextSpawnS = 150f
    private var eventIndex = 0
    private var stageIndex = 0
    private var nextKmMark = 1
    private var offRouteTimer = 0f
    private var wrongWayTimer = 0f
    private var lastWarnAt = -99f
    private var clock = 0f

    private var isOver = false
    private var overTimer = 0f
    private var overText = ""
    private var overWon = false
    private var overNotified = false

    private val stageStarts = floatArrayOf(1400f, 3300f, 4200f, 4800f, 7500f, 10500f)
    private val stageTexts = arrayOf(
        "Leaving Siliguri. The Sevoke forest road begins. Watch out for animals.",
        "The Teesta river and Coronation Bridge are ahead.",
        "Teesta valley road.",
        "It starts to rain.",
        "The hill road to Kalimpong begins. Many hairpin bends. Slow down.",
        "Welcome to Kalimpong. The Mary Scott Home hostel is close. Listen for the children."
    )

    init {
        buildRoad()
        buildWorld()
        sound.playSpatial("door_close", pan = 0f, volume = 0.9f)
        MyScreenReader.currentHelpContext = "One finger: drag up to drive forward, down to reverse, left or right to steer. Lift the finger to stop. Follow the GPS."
        MyScreenReader.speak(
            "Siliguri to Kalimpong. 70 kilometres. You are driving to the hostel of the Mary Scott Home School for the Blind. " +
                "To keep the game playable the journey is shortened, so it takes about 15 minutes. The GPS speaks in real kilometres. " +
                "Touch the screen with one finger and drag up to drive. Drag further and faster to go quicker. Drag down to reverse. Slide left or right to steer. Lift your finger to stop. " +
                "A beeping pedestrian signal means a red light: stop. Do the back gesture twice to leave."
        )
    }

    // ---------------------------------------------------------------- building the road and the world

    private fun addForward(length: Float, half: Float, main: Boolean, advance: Boolean) {
        val radians = Math.toRadians(curH.toDouble()).toFloat()
        val nx = curX + sin(radians) * length
        val ny = curY + cos(radians) * length
        val seg = Seg(curX, curY, nx, ny, half, main, curS)
        segs.add(seg)
        if (main) lastMainSeg = seg
        if (advance && main) curS += length
        curX = nx
        curY = ny
    }

    private fun buildRoad() {
        for (token in JOURNEY_ROUTE) {
            when (token[0]) {
                'F' -> addForward(token.substring(1).toFloat(), ROAD_HALF, true, true)
                'B' -> {
                    events.add(Event(curS, 5))
                    addForward(token.substring(1).toFloat(), BRIDGE_HALF, true, true)
                }
                'T' -> curH += token.substring(1).toFloat()
                'S' -> {
                    // a side road: a dead end, the main road goes straight on
                    val sx = curX
                    val sy = curY
                    val sh = curH
                    val ss = curS
                    curH += if (token[1] == 'L') -90f else 90f
                    addForward(300f, ROAD_HALF, false, false)
                    curX = sx
                    curY = sy
                    curH = sh
                    curS = ss
                    events.add(Event(curS, 0))
                }
                'X' -> {
                    // a junction where the main road turns and straight on is a dead end
                    events.add(Event(curS, if (token[1] == 'L') 2 else 1))
                    val sx = curX
                    val sy = curY
                    val ss = curS
                    val sh = curH
                    addForward(400f, ROAD_HALF, false, false)
                    curX = sx
                    curY = sy
                    curS = ss
                    curH = sh + (if (token[1] == 'L') -90f else 90f)
                }
                'H' -> {
                    // a hairpin: a U-turn
                    val d = if (token[1] == 'R') 90f else -90f
                    events.add(Event(curS, if (token[1] == 'R') 3 else 4))
                    curH += d
                    addForward(45f, ROAD_HALF, true, true)
                    curH += d
                }
            }
        }
        totalS = curS
    }

    private fun buildWorld() {
        // traffic lights in the two cities
        val lightPositions = floatArrayOf(400f, 900f, 1250f, 10650f, 11000f, 11350f)
        for (s in lightPositions) {
            val p = pointAt(s, 0f)
            val light = Light(p[0], p[1])
            light.timer = Random.nextFloat() * LIGHT_CYCLE
            light.red = light.timer < LIGHT_RED_SECONDS
            lights.add(light)
        }

        // places you can hear from the road
        val cityMarket = pointAt(700f, 35f)
        sources.add(Source(cityMarket[0], cityMarket[1], "market_loop", 150f, 0.9f))
        val hillMarket = pointAt(10800f, -35f)
        sources.add(Source(hillMarket[0], hillMarket[1], "market_loop", 150f, 0.9f))
        val hostel = pointAt(totalS, 0f)
        hostelX = hostel[0]
        hostelY = hostel[1]
        sources.add(Source(hostelX, hostelY, "school_loop", 500f, 0.45f))
    }

    // ---------------------------------------------------------------- road geometry

    private fun distanceToSeg(seg: Seg, x: Float, y: Float): Float {
        val t = ((x - seg.ax) * seg.dx + (y - seg.ay) * seg.dy).coerceIn(0f, seg.len)
        val ex = x - (seg.ax + seg.dx * t)
        val ey = y - (seg.ay + seg.dy * t)
        return sqrt(ex * ex + ey * ey)
    }

    private fun onRoad(x: Float, y: Float): Boolean {
        for (seg in segs) {
            if (distanceToSeg(seg, x, y) < seg.half) return true
        }
        return false
    }

    /** A point on the main road, s metres from the start, moved sideways curY lateral metres (positive = right). Returns x, y, direction x, direction y. */
    private fun pointAt(s: Float, lateral: Float): FloatArray {
        val target = s.coerceIn(0f, totalS)
        var found: Seg? = null
        for (seg in segs) {
            if (seg.main && target >= seg.s0 && target <= seg.s0 + seg.len + 0.01f) {
                found = seg
                break
            }
        }
        val seg = found ?: lastMainSeg ?: return floatArrayOf(0f, 0f, 0f, 1f)
        val t = (target - seg.s0).coerceIn(0f, seg.len)
        val x = seg.ax + seg.dx * t + seg.dy * lateral
        val y = seg.ay + seg.dy * t - seg.dx * lateral
        return floatArrayOf(x, y, seg.dx, seg.dy)
    }

    /** Finds where the car is along the main road. */
    private fun updateProgress() {
        var best = Float.MAX_VALUE
        var bestS = routeS
        var bestDx = routeDx
        var bestDy = routeDy
        for (seg in segs) {
            if (!seg.main) continue
            val t = ((px - seg.ax) * seg.dx + (py - seg.ay) * seg.dy).coerceIn(0f, seg.len)
            val ex = px - (seg.ax + seg.dx * t)
            val ey = py - (seg.ay + seg.dy * t)
            val d = sqrt(ex * ex + ey * ey)
            if (d < best) {
                best = d
                bestS = seg.s0 + t
                bestDx = seg.dx
                bestDy = seg.dy
            }
        }
        mainDistance = best
        if (best < 40f) {
            routeS = bestS
            routeDx = bestDx
            routeDy = bestDy
        }
    }

    private fun zoneAt(s: Float): Int {
        return when {
            s < 1400f -> 0
            s < 3300f -> 1
            s < 4200f -> 2
            s < 7500f -> 3
            s < 10500f -> 4
            else -> 5
        }
    }

    // ---------------------------------------------------------------- 3D sound

    private fun distanceTo(x: Float, y: Float): Float {
        val dx = x - px
        val dy = y - py
        return sqrt(dx * dx + dy * dy)
    }

    private fun relAngle(x: Float, y: Float): Float {
        val bearing = Math.toDegrees(atan2((x - px).toDouble(), (y - py).toDouble())).toFloat()
        var d = (bearing - heading) % 360f
        if (d > 180f) d -= 360f
        if (d < -180f) d += 360f
        return d
    }

    private fun panFor(rel: Float): Float {
        return sin(Math.toRadians(rel.toDouble())).toFloat()
    }

    private fun volumeFor(rel: Float, distance: Float, range: Float, base: Float): Float {
        var volume = (1.1f - distance / range).coerceIn(0f, 1f) * base
        if (abs(rel) > 90f) volume *= 0.65f
        return volume.coerceIn(0f, 1f)
    }

    private fun playAt(tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float) {
        val d = distanceTo(x, y)
        if (d >= range) return
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (volume < 0.03f) return
        sound.playSpatial(tag, pan = panFor(rel), volume = volume, rate = rate)
    }

    private fun updateLoop(stream: Int, tag: String, x: Float, y: Float, range: Float, base: Float, rate: Float): Int {
        val d = distanceTo(x, y)
        if (d >= range) {
            if (stream != 0) sound.stopStream(stream)
            return 0
        }
        val rel = relAngle(x, y)
        val volume = volumeFor(rel, d, range, base)
        if (stream == 0) return sound.playLoop(tag, panFor(rel), volume, rate)
        sound.updateStream(stream, panFor(rel), volume, rate)
        return stream
    }

    private fun onOff(stream: Int, tag: String, active: Boolean, pan: Float, volume: Float): Int {
        if (active) {
            if (stream == 0) return sound.playLoop(tag, pan, volume, 1.0f)
            sound.updateStream(stream, pan, volume, 1.0f)
            return stream
        }
        if (stream != 0) sound.stopStream(stream)
        return 0
    }

    private fun ambient(a: Ambient, target: Float, dt: Float) {
        a.volume += (target - a.volume) * min(1f, dt * 0.6f)
        if (a.volume > 0.02f) {
            if (a.stream == 0) {
                a.stream = sound.playLoop(a.tag, 0f, a.volume, 1.0f)
            } else {
                sound.updateStream(a.stream, 0f, a.volume, 1.0f)
            }
        } else if (a.stream != 0) {
            sound.stopStream(a.stream)
            a.stream = 0
        }
    }

    // ---------------------------------------------------------------- main loop

    override fun shutdown() {
        stopAll()
    }

    private fun stopAll() {
        engine.stop()
        sound.stopStream(reverseStream)
        sound.stopStream(indicatorStream)
        reverseStream = 0
        indicatorStream = 0
        for (a in listOf(jungleAmbient, townAmbient, riverAmbient, rainAmbient)) {
            sound.stopStream(a.stream)
            a.stream = 0
            a.volume = 0f
        }
        for (s in sources) {
            sound.stopStream(s.stream)
            s.stream = 0
        }
        for (t in things) {
            sound.stopStream(t.stream)
            t.stream = 0
        }
    }

    override fun tick(dt: Float, controls: CarControls) {
        if (isOver) {
            overTimer -= dt
            if (overTimer <= 0f && !overNotified) {
                overNotified = true
                onOver(overText, overWon)
            }
            return
        }
        clock += dt

        updateCar(dt, controls)
        if (isOver) return
        updateProgress()
        updateBuildingCues(dt)
        spawnThings()
        updateThings(dt)
        if (isOver) return
        updateLights(dt)
        if (isOver) return
        updateAtmosphere(dt)
        updateGps(dt)
        updateStages()
        if (!isOver && distanceTo(hostelX, hostelY) < ARRIVE_DISTANCE) win()
    }

    // ---------------------------------------------------------------- the car

    private fun updateCar(dt: Float, controls: CarControls) {
        crashCooldown = max(0f, crashCooldown - dt)
        bumpTimer = max(0f, bumpTimer - dt)
        skidTimer = max(0f, skidTimer - dt)

        var target = 0f
        var steerCmd = 0f
        if (controls.stickActive) {
            val sy = controls.stickY
            val sx = controls.stickX
            if (sy > 0.06f) {
                target = TOP_SPEED * (sy + 0.45f * controls.stickBoost).coerceIn(0f, 1f)
            } else if (sy < -0.06f) {
                target = -REVERSE_TOP * (-sy).coerceIn(0f, 1f)
            }
            steerCmd = if (abs(sx) > 0.08f) sx else 0f
        }

        val boostMultiplier = 1f + 2f * controls.stickBoost
        val slowing = abs(target) < abs(speed) || target * speed < 0f
        val rate = if (slowing) BRAKE else ACCEL * boostMultiplier
        speed = if (speed < target) min(target, speed + rate * dt) else max(target, speed - rate * dt)

        if (abs(speed) > 5f) wasFast = true
        if (wasFast && abs(speed) < 0.3f) {
            wasFast = false
            sound.playSpatial("handbrake", pan = 0f, volume = 0.7f)
        }

        // Steering like a real car: it only turns while moving, and the faster you go the less the wheels can turn
        val steerAngle = steerCmd * MAX_STEER / (1f + abs(speed) / 5f)
        val yawRate = speed / WHEELBASE * tan(steerAngle)
        heading += yawRate * dt * 57.2958f
        heading = ((heading % 360f) + 360f) % 360f

        val radians = Math.toRadians(heading.toDouble()).toFloat()
        val nx = px + sin(radians) * speed * dt
        val ny = py + cos(radians) * speed * dt
        if (onRoad(nx, ny)) {
            px = nx
            py = ny
        } else if (abs(speed) > 0.2f) {
            hitBuilding()
        }

        if (abs(speed) > 8f && abs(steerCmd) > 0.7f && skidTimer <= 0f) {
            skidTimer = 1.5f
            sound.playSpatial("car_skid", pan = 0f, volume = 0.5f)
        }

        engine.update(abs(speed) / TOP_SPEED)
        reverseStream = onOff(reverseStream, "reverse_beep_loop", speed < -0.4f, 0f, 0.5f)
        val indicating = abs(steerCmd) > 0.25f && speed > 0.3f
        indicatorStream = onOff(indicatorStream, "indicator_loop", indicating, if (steerCmd < 0f) -0.4f else 0.4f, 0.45f)
    }

    private fun hitBuilding() {
        if (abs(speed) > 6f && crashCooldown <= 0f) {
            loseLife("You left the road.", "collision_hit", abs(speed) > 12f)
        } else if (bumpTimer <= 0f) {
            bumpTimer = 0.6f
            sound.playSpatial("wall_thud", pan = 0f, volume = 0.8f)
            sound.vibrate(40)
        }
        speed = 0f
    }

    /** Metres until the road ends along a direction (relative to where the car points), or the limit if the road goes on. */
    private fun distanceToBuilding(offsetDegrees: Float, limit: Float, backwards: Boolean): Float {
        val angle = heading + offsetDegrees + (if (backwards) 180f else 0f)
        val radians = Math.toRadians(angle.toDouble()).toFloat()
        val sx = sin(radians)
        val cy = cos(radians)
        var d = 1f
        while (d <= limit) {
            if (!onRoad(px + sx * d, py + cy * d)) return d
            d += 1f
        }
        return limit
    }

    /** Like parking sensors: beeps ahead (or behind when reversing) as the edge of the road nears, and at the sides when you drive close to the edge. */
    private fun updateBuildingCues(dt: Float) {
        if (abs(speed) < 0.5f) {
            frontBeepTimer = 0f
            leftBeepTimer = 0f
            rightBeepTimer = 0f
            return
        }

        val ahead = distanceToBuilding(0f, 35f, speed < 0f)
        if (ahead < 35f) {
            frontBeepTimer -= dt
            if (frontBeepTimer <= 0f) {
                val closeness = (1f - ahead / 35f).coerceIn(0f, 1f)
                sound.playSpatial("wall_beep", pan = 0f, volume = 0.5f + 0.45f * closeness, rate = 0.8f + 0.8f * closeness)
                frontBeepTimer = 0.08f + 0.5f * (1f - closeness)
            }
        } else {
            frontBeepTimer = 0f
        }

        val left = distanceToBuilding(-90f, 4f, false)
        if (left < 4f) {
            leftBeepTimer -= dt
            if (leftBeepTimer <= 0f) {
                val closeness = (1f - left / 4f).coerceIn(0f, 1f)
                sound.playSpatial("wall_beep", pan = -0.9f, volume = 0.35f + 0.4f * closeness, rate = 0.7f + 0.5f * closeness)
                leftBeepTimer = 0.12f + 0.35f * (1f - closeness)
            }
        } else {
            leftBeepTimer = 0f
        }

        val right = distanceToBuilding(90f, 4f, false)
        if (right < 4f) {
            rightBeepTimer -= dt
            if (rightBeepTimer <= 0f) {
                val closeness = (1f - right / 4f).coerceIn(0f, 1f)
                sound.playSpatial("wall_beep", pan = 0.9f, volume = 0.35f + 0.4f * closeness, rate = 0.7f + 0.5f * closeness)
                rightBeepTimer = 0.12f + 0.35f * (1f - closeness)
            }
        } else {
            rightBeepTimer = 0f
        }
    }

    // ---------------------------------------------------------------- crashes and the end

    private fun loseLife(reason: String, soundTag: String, glass: Boolean) {
        if (crashCooldown > 0f) return
        crashCooldown = 2.0f
        lives -= 1
        speed = 0f
        sound.playSpatial(soundTag, pan = 0f, volume = 1.0f)
        if (glass) sound.playSpatial("glass_break", pan = 0f, volume = 0.8f)
        sound.vibrate(300)
        if (lives <= 0) {
            isOver = true
            overWon = false
            overTimer = GAME_OVER_SECONDS
            overText = "$reason Game over. You drove ${Math.round(routeS * SCALE / 1000f)} of ${Math.round(totalS * SCALE / 1000f)} kilometres."
            stopAll()
            sound.playSpatial("game_over", pan = 0f, volume = 1.0f)
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("$reason $lives $word left.")
        }
    }

    private fun win() {
        isOver = true
        overWon = true
        overTimer = 5f
        overText = "You reached the Mary Scott Home School for the Blind, Kalimpong. Welcome to the hostel! You finished with $lives ${if (lives == 1) "life" else "lives"} left."
        stopAll()
        sound.playSpatial("door_open", pan = 0f, volume = 0.9f)
        sound.playSpatial("victory", pan = 0f, volume = 1.0f)
        MyScreenReader.speak("You reached the hostel!")
    }

    // ---------------------------------------------------------------- things on the road

    private fun pickType(zone: Int): Type {
        val roll = Random.nextInt(100)
        return when (zone) {
            0 -> when {
                roll < 15 -> Type.COW
                roll < 25 -> Type.DOG
                roll < 45 -> Type.CROWD
                roll < 60 -> Type.BUMP
                roll < 80 -> Type.AUTO
                roll < 90 -> Type.BUS
                roll < 95 -> Type.BIKE
                else -> Type.CYCLIST
            }
            1 -> when {
                roll < 25 -> Type.DEER
                roll < 45 -> Type.MONKEY
                roll < 55 -> Type.ELEPHANT
                roll < 70 -> Type.TREE
                else -> Type.POTHOLE
            }
            2 -> when {
                roll < 30 -> Type.POTHOLE
                roll < 55 -> Type.TRUCK
                roll < 75 -> Type.BIKE
                else -> Type.MONKEY
            }
            3 -> when {
                roll < 20 -> Type.TRUCK
                roll < 30 -> Type.BUS
                roll < 50 -> Type.POTHOLE
                roll < 65 -> Type.ROCK
                roll < 75 -> Type.MONKEY
                roll < 85 -> Type.COW
                roll < 95 -> Type.BIKE
                else -> Type.DEER
            }
            4 -> when {
                roll < 25 -> Type.ROCK
                roll < 40 -> Type.TRUCK
                roll < 50 -> Type.BUS
                roll < 65 -> Type.POTHOLE
                roll < 80 -> Type.MONKEY
                roll < 90 -> Type.BIKE
                else -> Type.COW
            }
            else -> when {
                roll < 25 -> Type.CROWD
                roll < 40 -> Type.COW
                roll < 55 -> Type.DOG
                roll < 70 -> Type.AUTO
                roll < 80 -> Type.BIKE
                roll < 90 -> Type.BUMP
                else -> Type.CYCLIST
            }
        }
    }

    private fun gapFor(zone: Int): Float {
        return when (zone) {
            0, 5 -> 90f + Random.nextFloat() * 60f
            else -> 140f + Random.nextFloat() * 80f
        }
    }

    private fun spawnThings() {
        while (nextSpawnS < routeS + SPAWN_AHEAD && nextSpawnS < totalS - 150f) {
            spawnThing(nextSpawnS)
            nextSpawnS += gapFor(zoneAt(nextSpawnS))
        }
    }

    private fun spawnThing(s: Float) {
        val type = pickType(zoneAt(s))
        val lateral = (Random.nextFloat() - 0.5f) * 8f
        val p = pointAt(s, lateral)
        val thing = Thing(type, p[0], p[1])
        thing.s = s
        thing.lateral = lateral
        when (type) {
            Type.AUTO, Type.BUS, Type.TRUCK, Type.BIKE, Type.CYCLIST -> {
                thing.mover = true
                thing.dirSign = if (Random.nextBoolean()) 1f else -1f
                thing.speed = when (type) {
                    Type.AUTO -> 5f
                    Type.BUS -> 4f
                    Type.TRUCK -> 4.5f
                    Type.BIKE -> 8f
                    else -> 3f
                }
                thing.lateral = thing.dirSign * 4f
                val q = pointAt(s, thing.lateral)
                thing.x = q[0]
                thing.y = q[1]
                thing.callTimer = 2f + Random.nextFloat() * 4f
            }
            Type.DEER, Type.MONKEY, Type.ELEPHANT -> {
                thing.leaveTimer = 12f + Random.nextFloat() * 6f
                thing.callTimer = 0.5f
            }
            else -> {
            }
        }
        things.add(thing)
    }

    private fun nameOf(type: Type): String {
        return when (type) {
            Type.COW -> "cow"
            Type.DOG -> "dog"
            Type.CROWD -> "crowd of people"
            Type.BUMP -> "speed bump"
            Type.AUTO -> "auto rickshaw"
            Type.BUS -> "bus"
            Type.TRUCK -> "truck"
            Type.BIKE -> "motorcycle"
            Type.CYCLIST -> "cyclist"
            Type.DEER -> "deer"
            Type.MONKEY -> "monkey"
            Type.ELEPHANT -> "elephant"
            Type.TREE -> "fallen tree"
            Type.ROCK -> "landslide rocks"
            Type.POTHOLE -> "pothole"
        }
    }

    private fun radiusOf(type: Type): Float {
        return when (type) {
            Type.COW -> 2.5f
            Type.DOG -> 2.0f
            Type.CROWD -> 3.0f
            Type.BUMP -> 0f
            Type.AUTO -> 2.5f
            Type.BUS -> 4.0f
            Type.TRUCK -> 3.5f
            Type.BIKE -> 2.0f
            Type.CYCLIST -> 2.0f
            Type.DEER -> 2.0f
            Type.MONKEY -> 1.2f
            Type.ELEPHANT -> 3.5f
            Type.TREE -> 5.0f
            Type.ROCK -> 5.0f
            Type.POTHOLE -> 2.2f
        }
    }

    private fun updateThings(dt: Float) {
        for (t in things) {
            if (t.gone) continue

            if (t.mover) {
                t.s += t.speed * t.dirSign * dt
                if (t.s < 0f) {
                    t.s = 0f
                    t.dirSign = 1f
                } else if (t.s > totalS) {
                    t.s = totalS
                    t.dirSign = -1f
                }
                val p = pointAt(t.s, t.lateral)
                t.x = p[0]
                t.y = p[1]
                if (abs(t.s - routeS) > 600f) {
                    retire(t)
                    continue
                }
            } else if (t.s < routeS - 300f) {
                retire(t)
                continue
            }

            val d = distanceTo(t.x, t.y)
            t.callTimer -= dt

            when (t.type) {
                Type.COW -> {
                    if (t.callTimer <= 0f && d < 90f) {
                        playAt("cow_moo", t.x, t.y, 90f, 1.0f, 1.0f)
                        t.callTimer = 4f + Random.nextFloat() * 3f
                    }
                }
                Type.DOG -> {
                    if (t.callTimer <= 0f && d < 70f) {
                        playAt("dog_bark", t.x, t.y, 70f, 1.0f, 1.0f)
                        t.callTimer = 2.5f + Random.nextFloat() * 2f
                    }
                }
                Type.CROWD -> {
                    t.stream = updateLoop(t.stream, "crowd_town_loop", t.x, t.y, 80f, 0.9f, 1.0f)
                }
                Type.BUMP -> {
                    if (!t.crossed) cueAhead(t, dt, d, 35f, 0.6f)
                }
                Type.AUTO -> {
                    t.stream = updateLoop(t.stream, "rickshaw_loop", t.x, t.y, 100f, 0.8f, 1.0f)
                    horn(t, d, "horn_auto", 45f)
                }
                Type.BUS -> {
                    t.stream = updateLoop(t.stream, "eng_idle", t.x, t.y, 100f, 0.8f, 0.7f)
                    horn(t, d, "horn_bus", 55f)
                }
                Type.TRUCK -> {
                    t.stream = updateLoop(t.stream, "eng_idle", t.x, t.y, 100f, 0.8f, 0.6f)
                    horn(t, d, "horn_truck", 55f)
                }
                Type.BIKE -> {
                    t.stream = updateLoop(t.stream, "eng_high", t.x, t.y, 90f, 0.6f, 1.25f)
                    if (t.callTimer <= 0f && d < 30f) {
                        playAt("moto_pass", t.x, t.y, 60f, 1.0f, 1.0f)
                        t.callTimer = 9f
                    }
                }
                Type.CYCLIST -> {
                    if (t.callTimer <= 0f && d < 45f) {
                        playAt("bicycle_bell", t.x, t.y, 60f, 1.0f, 1.0f)
                        t.callTimer = 4f
                    }
                }
                Type.DEER -> {
                    wildAnimal(t, d, dt, "deer_call")
                }
                Type.MONKEY -> {
                    wildAnimal(t, d, dt, "monkey_call")
                }
                Type.ELEPHANT -> {
                    wildAnimal(t, d, dt, "elephant_call")
                }
                Type.TREE, Type.ROCK -> {
                    if (!t.heard && d < 200f) {
                        // the crash of the fall is heard as it comes into range, once
                        t.heard = true
                        playAt("tree_fall", t.x, t.y, 260f, 0.9f, if (t.type == Type.ROCK) 0.75f else 1.0f)
                    }
                    cueAhead(t, dt, d, 45f, 1.0f)
                }
                Type.POTHOLE -> {
                    cueAhead(t, dt, d, 30f, 0.6f)
                }
            }
            if (t.gone) continue

            when (t.type) {
                Type.BUMP -> {
                    if (d < 3f && abs(speed) > 0.5f && !t.crossed) {
                        t.crossed = true
                        sound.playSpatial("bump_thud", pan = 0f, volume = 1.0f)
                        if (abs(speed) > 6f) {
                            sound.vibrate(100)
                            speed *= 0.5f
                        }
                    }
                }
                Type.POTHOLE -> {
                    if (d < radiusOf(t.type) && abs(speed) > 0.5f) {
                        t.gone = true
                        sound.playSpatial("pothole_thud", pan = 0f, volume = 1.0f)
                        sound.vibrate(120)
                        if (abs(speed) > 14f) {
                            loseLife("A tyre burst. You hit a pothole too fast.", "collision_hit", false)
                        } else {
                            speed *= 0.6f
                        }
                        if (isOver) return
                    }
                }
                else -> {
                    val radius = radiusOf(t.type)
                    if (radius > 0f && d < radius && crashCooldown <= 0f && (abs(speed) > 0.5f || t.speed > 0f)) {
                        if (!t.mover) {
                            t.gone = true
                            sound.stopStream(t.stream)
                            t.stream = 0
                        }
                        val big = t.type == Type.BUS || t.type == Type.TRUCK || t.type == Type.TREE || t.type == Type.ROCK
                        loseLife("You hit a ${nameOf(t.type)}.", "collision_hit", big)
                        if (isOver) return
                    }
                }
            }
        }
        things.removeAll { it.gone }
    }

    private fun retire(t: Thing) {
        t.gone = true
        sound.stopStream(t.stream)
        t.stream = 0
    }

    private fun horn(t: Thing, d: Float, tag: String, range: Float) {
        if (t.callTimer <= 0f && d < range) {
            playAt(tag, t.x, t.y, range + 30f, 1.0f, 1.0f)
            t.callTimer = 5f + Random.nextFloat() * 4f
        }
    }

    private fun wildAnimal(t: Thing, d: Float, dt: Float, tag: String) {
        t.leaveTimer -= dt
        if (t.leaveTimer <= 0f) {
            // it wanders off: one last, quieter call as it goes
            playAt(tag, t.x, t.y, 130f, 0.4f, 0.8f)
            retire(t)
            return
        }
        if (t.callTimer <= 0f && d < 130f) {
            playAt(tag, t.x, t.y, 130f, 1.0f, 1.0f)
            t.callTimer = 2.5f + Random.nextFloat() * 1.5f
        }
    }

    /** Beeps when something is straight ahead: faster and higher as it nears. Low pitch = road damage. */
    private fun cueAhead(t: Thing, dt: Float, d: Float, range: Float, basePitch: Float) {
        val rel = relAngle(t.x, t.y)
        if (d < range && abs(rel) < 25f && speed > 1f) {
            t.beepTimer -= dt
            if (t.beepTimer <= 0f) {
                val closeness = (1f - d / range).coerceIn(0f, 1f)
                sound.playSpatial("warn_beep", pan = 0f, volume = 0.45f + 0.4f * closeness, rate = basePitch + 0.5f * closeness)
                t.beepTimer = 0.12f + 0.4f * (1f - closeness)
            }
        }
    }

    // ---------------------------------------------------------------- traffic lights

    private fun updateLights(dt: Float) {
        for (l in lights) {
            l.timer += dt
            if (l.timer >= LIGHT_CYCLE) l.timer -= LIGHT_CYCLE
            val red = l.timer < LIGHT_RED_SECONDS
            if (red && !l.red) l.fined = false
            l.red = red

            val d = distanceTo(l.x, l.y)
            if (red && d < 130f) {
                l.beepTimer -= dt
                if (l.beepTimer <= 0f) {
                    playAt("ped_beep", l.x, l.y, 140f, 0.9f, 1.0f)
                    l.beepTimer = 0.55f
                }
            }
            if (red && !l.fined && d < ROAD_HALF + 4f && abs(speed) > 2.5f && crashCooldown <= 0f) {
                l.fined = true
                loseLife("You ran a red light.", "police_whistle", false)
                if (isOver) return
            }
        }
    }

    // ---------------------------------------------------------------- places, weather

    private fun updateAtmosphere(dt: Float) {
        val zone = zoneAt(routeS)

        val jungleTarget = when (zone) {
            1 -> 0.3f
            2 -> 0.2f
            3 -> 0.12f
            4 -> 0.1f
            else -> 0f
        }
        val townTarget = if (zone == 0 || zone == 5) 0.16f else 0f
        val riverTarget = when (zone) {
            2 -> 0.55f
            3 -> 0.3f
            4 -> 0.15f
            else -> 0f
        }
        val rainTarget = if (routeS >= 4800f) (if (zone == 5) 0.35f else 0.5f) else 0f
        ambient(jungleAmbient, jungleTarget, dt)
        ambient(townAmbient, townTarget, dt)
        ambient(riverAmbient, riverTarget, dt)
        ambient(rainAmbient, rainTarget, dt)

        for (s in sources) {
            s.stream = updateLoop(s.stream, s.tag, s.x, s.y, s.range, s.volume, 1.0f)
        }

        if (routeS >= 4800f) {
            thunderTimer -= dt
            if (thunderTimer <= 0f) {
                sound.playSpatial("thunder_roll", pan = (Random.nextFloat() - 0.5f) * 1.6f, volume = 0.7f)
                thunderTimer = 22f + Random.nextFloat() * 25f
            }
        }

        // the temple bell in Kalimpong
        if (zone == 5) {
            templeTimer -= dt
            if (templeTimer <= 0f) {
                val p = pointAt(10900f, 45f)
                playAt("temple_bell", p[0], p[1], 300f, 1.0f, 1.0f)
                templeTimer = 14f + Random.nextFloat() * 10f
            }
        }

        // the bridge creaks while you are on it
        var bridgeStart = -1f
        for (e in events) {
            if (e.kind == 5) bridgeStart = e.s
        }
        if (bridgeStart >= 0f && routeS >= bridgeStart && routeS <= bridgeStart + 200f && mainDistance < BRIDGE_HALF + 3f) {
            creakTimer -= dt
            if (creakTimer <= 0f) {
                sound.playSpatial("bridge_creak", pan = 0f, volume = 0.5f)
                creakTimer = 2.8f
            }
        }
    }

    private fun updateStages() {
        if (stageIndex < stageStarts.size && routeS >= stageStarts[stageIndex]) {
            MyScreenReader.speak(stageTexts[stageIndex], flush = false)
            // a rest stop: one life back at each new stretch of road (not for the rain)
            if (stageIndex != 3 && lives < MAX_LIVES) {
                lives += 1
                sound.playSpatial("ui_select", pan = 0f, volume = 0.6f)
            }
            stageIndex += 1
        }
        val realKm = routeS * SCALE / 1000f
        if (nextKmMark * 10 < 70 && realKm >= nextKmMark * 10) {
            val km = nextKmMark * 10
            MyScreenReader.speak("$km kilometres done. ${70 - km} to go.", flush = false)
            nextKmMark += 1
        }
    }

    // ---------------------------------------------------------------- GPS

    private fun distanceWords(along: Float): String {
        val km = along * SCALE / 1000f
        if (km < 1f) {
            val meters = Math.round(km * 10f) * 100
            return if (meters <= 0) "a few hundred meters" else "$meters meters"
        }
        val tenths = Math.round(km * 10f)
        return "${tenths / 10}.${tenths % 10} kilometres"
    }

    private fun updateGps(dt: Float) {
        while (eventIndex < events.size && routeS > events[eventIndex].s + 25f) {
            eventIndex += 1
        }
        if (eventIndex < events.size) {
            val e = events[eventIndex]
            val along = e.s - routeS
            when (e.kind) {
                1, 2 -> {
                    val side = if (e.kind == 1) "right" else "left"
                    if (!e.announced && along <= 260f) {
                        e.announced = true
                        MyScreenReader.speak("In ${distanceWords(along)}, turn $side at the junction.", flush = false)
                    }
                    if (!e.nowSpoken && along <= max(50f, speed * 2.5f) && e.announced) {
                        e.nowSpoken = true
                        MyScreenReader.speak("Turn $side now.", flush = false)
                    }
                }
                0 -> {
                    if (!e.announced && along <= 160f) {
                        e.announced = true
                        MyScreenReader.speak("Keep straight at the junction.", flush = false)
                    }
                }
                3, 4 -> {
                    if (!e.announced && along <= 140f) {
                        e.announced = true
                        val side = if (e.kind == 3) "right" else "left"
                        MyScreenReader.speak("Hairpin bend to the $side. Slow down.", flush = false)
                    }
                }
                else -> {
                }
            }
        }

        // off the route: a dead end, or the wrong way along the road
        val offRoute = mainDistance > ROAD_HALF + 16f
        offRouteTimer = if (offRoute) offRouteTimer + dt else 0f
        val headingRadians = Math.toRadians(heading.toDouble()).toFloat()
        val along = sin(headingRadians) * routeDx + cos(headingRadians) * routeDy
        wrongWayTimer = if (!offRoute && speed > 2f && along < -0.4f) wrongWayTimer + dt else 0f

        if (clock - lastWarnAt > 15f) {
            if (offRouteTimer > 3f) {
                lastWarnAt = clock
                MyScreenReader.speak("You left the route. This road is a dead end. Turn around and go back to the main road.", flush = false)
            } else if (wrongWayTimer > 4f) {
                lastWarnAt = clock
                MyScreenReader.speak("You are driving the wrong way. Turn around.", flush = false)
            }
        }
    }
}
