package com.blindarena

import kotlinx.coroutines.delay

// =========================================================================
// The sounds of a Hand Cricket ball, built only from the sound files that were already in the app.
//
//  - When YOU BAT the computer bowls first: you hear the bowler run in (footsteps that speed up), then the ball
//    flying at you (whooshes that get louder, higher and faster), then a short tone that means "your turn,
//    pick a number".
//  - When YOU BOWL you hear the batsman get ready (two taps of the bat), then you pick your number, then you
//    hear your own run-up and the ball flying away.
//  - The umpire's whistle means the innings (or the match) is over.
// =========================================================================

/** One sound at one moment of a sequence (atMs counts from the start of the sequence). */
class Cue(val atMs: Long, val tag: String, val pan: Float, val volume: Float, val rate: Float)

object CricketAudio {

    /** The computer bowls to you: run-up, ball in the air, then the "your turn" tone. */
    fun botDeliveryCues(): List<Cue> {
        val cues = ArrayList<Cue>()
        // run-up: five steps, quicker and louder as he gets to the crease
        val stepTimes = longArrayOf(0, 320, 600, 840, 1040)
        for (i in stepTimes.indices) {
            val f = i / 4f
            cues.add(Cue(stepTimes[i], "footstep", -0.3f + 0.3f * f, 0.35f + 0.45f * f, 1.0f + 0.25f * f))
        }
        // the ball: six whooshes, closer and closer together, louder and higher
        val flyTimes = longArrayOf(1300, 1470, 1620, 1750, 1860, 1950)
        val flyVolume = floatArrayOf(0.25f, 0.35f, 0.5f, 0.65f, 0.85f, 1.0f)
        val flyRate = floatArrayOf(0.8f, 0.9f, 1.0f, 1.1f, 1.3f, 1.5f)
        for (i in flyTimes.indices) {
            cues.add(Cue(flyTimes[i], "ball_whoosh", 0f, flyVolume[i], flyRate[i]))
        }
        cues.add(Cue(2300, "lock_tone", 0f, 0.8f, 1.2f))
        return cues
    }

    /** The batsman gets ready while you are about to bowl. */
    fun batsmanReadyCues(): List<Cue> {
        return listOf(
            Cue(0, "wall_thud", 0f, 0.5f, 1.5f),
            Cue(280, "wall_thud", 0f, 0.5f, 1.5f),
            Cue(720, "lock_tone", 0f, 0.8f, 0.9f)
        )
    }

    /** You bowl: your run-up, then the ball flying away from you. */
    fun playerDeliveryCues(): List<Cue> {
        val cues = ArrayList<Cue>()
        val stepTimes = longArrayOf(0, 250, 470, 670)
        for (i in stepTimes.indices) {
            cues.add(Cue(stepTimes[i], "footstep", 0f, 0.4f + 0.3f * (i / 3f), 1.0f + 0.2f * (i / 3f)))
        }
        val flyTimes = longArrayOf(900, 1020, 1160, 1330, 1540)
        val flyVolume = floatArrayOf(1.0f, 0.8f, 0.6f, 0.4f, 0.25f)
        val flyRate = floatArrayOf(1.4f, 1.25f, 1.1f, 1.0f, 0.85f)
        for (i in flyTimes.indices) {
            cues.add(Cue(flyTimes[i], "ball_whoosh", 0f, flyVolume[i], flyRate[i]))
        }
        return cues
    }

    /** Length of a sequence in milliseconds (the time of its last cue). */
    fun lengthOf(cues: List<Cue>): Long {
        var last = 0L
        for (c in cues) {
            if (c.atMs > last) last = c.atMs
        }
        return last
    }

    /** Plays a sequence and returns when its last cue has been played. */
    suspend fun play(sound: SoundManager, cues: List<Cue>) {
        var now = 0L
        for (cue in cues.sortedBy { it.atMs }) {
            if (cue.atMs > now) {
                delay(cue.atMs - now)
                now = cue.atMs
            }
            sound.playSpatial(cue.tag, pan = cue.pan, volume = cue.volume, rate = cue.rate)
        }
    }

    /** What the bat does with the ball, and what the crowd says. */
    fun playOutcome(sound: SoundManager, out: Boolean, scored: Int, playerBatting: Boolean) {
        if (out) {
            sound.playSpatial("stumps_hit", pan = 0f, volume = 1.0f)
            if (playerBatting) {
                sound.playSpatial("crowd_groan", pan = 0f, volume = 0.8f)
            } else {
                sound.playSpatial("crowd_cheer_short", pan = 0f, volume = 0.8f)
            }
        } else if (scored == 6) {
            sound.playSpatial("bat_hard", pan = 0f, volume = 1.0f)
            sound.playSpatial("crowd_roar", pan = 0f, volume = 0.9f)
        } else if (scored >= 4) {
            sound.playSpatial("bat_hard", pan = 0f, volume = 1.0f)
            sound.playSpatial("crowd_cheer", pan = 0f, volume = 0.8f)
        } else {
            sound.playSpatial("bat_soft", pan = 0f, volume = 0.9f)
        }
    }

    /** The umpire's whistle and a short cheer: the innings is over. */
    fun playInningsOver(sound: SoundManager) {
        sound.playSpatial("police_whistle", pan = 0f, volume = 1.0f)
    }

    /** The match is over: whistle, then the crowd reacts to the result. */
    fun playMatchOver(sound: SoundManager, playerWon: Boolean, tied: Boolean) {
        sound.playSpatial("police_whistle", pan = 0f, volume = 1.0f)
        if (playerWon) {
            sound.playSpatial("crowd_applause", pan = 0f, volume = 0.9f)
            sound.playSpatial("crowd_roar", pan = 0f, volume = 0.8f)
        } else if (tied) {
            sound.playSpatial("crowd_cheer_short", pan = 0f, volume = 0.8f)
        } else {
            sound.playSpatial("crowd_groan", pan = 0f, volume = 0.9f)
        }
    }
}
