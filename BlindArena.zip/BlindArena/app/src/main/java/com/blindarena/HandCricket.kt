package com.blindarena

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// =========================================================================
// MODE 2: HAND CRICKET
// Both sides secretly pick a number from 1 to 6 every ball.
//  - If the numbers match, the batter is OUT.
//  - Otherwise the batter scores their own number as runs.
// Overs and wickets are chosen before the match. Toss = odd or even.
// =========================================================================

/** What happened on one ball. All numbers are taken BEFORE an innings change resets the score. */
class BallOutcome(
    val out: Boolean,
    val scored: Int,
    val batterNumber: Int,
    val runsAfter: Int,
    val wicketsAfter: Int,
    val ballsAfter: Int,
    val inningsEnded: Boolean,
    val matchEnded: Boolean
)

/** Pure match rules, no UI and no sound, so the logic is easy to check. */
class HandCricketMatch(val overs: Int, val maxWickets: Int, val playerBatsFirst: Boolean) {

    val maxBalls: Int
        get() = overs * 6

    var innings: Int = 1
        private set
    var playerBatting: Boolean = playerBatsFirst
        private set
    var runs: Int = 0
        private set
    var wickets: Int = 0
        private set
    var balls: Int = 0
        private set
    var firstInningsRuns: Int = 0
        private set
    var matchOver: Boolean = false
        private set
    var playerRuns: Int = 0
        private set
    var computerRuns: Int = 0
        private set
    var playerWon: Boolean = false
        private set
    var resultText: String = ""
        private set

    /** Runs the chasing side needs to win (only meaningful in the second innings). */
    val target: Int
        get() = firstInningsRuns + 1

    fun chaseNeed(): Int = target - runs

    fun ballsLeft(): Int = maxBalls - balls

    fun playBall(playerNumber: Int, computerNumber: Int): BallOutcome {
        val out = playerNumber == computerNumber
        val batterNumber = if (playerBatting) playerNumber else computerNumber
        val scored = if (out) 0 else batterNumber

        balls += 1
        if (out) wickets += 1 else runs += scored

        val runsAfter = runs
        val wicketsAfter = wickets
        val ballsAfter = balls

        var inningsEnded = wickets >= maxWickets || balls >= maxBalls
        if (innings == 2 && runs >= target) inningsEnded = true

        var matchEnded = false
        if (inningsEnded) {
            if (innings == 1) {
                firstInningsRuns = runs
                innings = 2
                playerBatting = !playerBatting
                runs = 0
                wickets = 0
                balls = 0
            } else {
                matchEnded = true
                matchOver = true
                finishMatch()
            }
        }

        return BallOutcome(out, scored, batterNumber, runsAfter, wicketsAfter, ballsAfter, inningsEnded, matchEnded)
    }

    private fun finishMatch() {
        val chaseRuns = runs
        val defendRuns = firstInningsRuns
        val playerChased = !playerBatsFirst

        playerRuns = if (playerChased) chaseRuns else defendRuns
        computerRuns = if (playerChased) defendRuns else chaseRuns

        if (chaseRuns > defendRuns) {
            val wicketsLeft = maxWickets - wickets
            val margin = "by $wicketsLeft ${if (wicketsLeft == 1) "wicket" else "wickets"}"
            playerWon = playerChased
            resultText = if (playerChased) "You win $margin!" else "Computer wins $margin."
        } else if (chaseRuns < defendRuns) {
            val diff = defendRuns - chaseRuns
            val margin = "by $diff ${if (diff == 1) "run" else "runs"}"
            playerWon = !playerChased
            resultText = if (playerChased) "Computer wins $margin." else "You win $margin!"
        } else {
            playerWon = false
            resultText = "The match is tied!"
        }
    }
}

/** Menus, speech, sounds and timing for the match. Uses the app's own screen reader for all choices. */
class HandCricketController(
    private val sound: SoundManager,
    private val scope: CoroutineScope,
    private val onExit: () -> Unit
) {
    var title by mutableStateOf("HAND CRICKET")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    private val oversChoices = listOf(1, 2, 3, 5, 10)
    private val wicketChoices = listOf(1, 2, 3, 5, 10)

    private var overs = 2
    private var maxWickets = 2
    private var tossCall = "odd"
    private var match: HandCricketMatch? = null
    private var busy = false
    private var lastNumber = 1

    fun begin() {
        showOvers()
    }

    // ---------------------------------------------------------------- helpers

    private fun say(text: String, help: String) {
        MyScreenReader.currentHelpContext = help
        MyScreenReader.speak(text)
    }

    private fun setItems(items: List<MyScreenReader.FocusItem>, startIndex: Int) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        if (items.isNotEmpty()) {
            MyScreenReader.currentFocusIndex.value = startIndex.coerceIn(0, items.size - 1)
        }
    }

    private fun numberItems(onPick: (Int) -> Unit): List<MyScreenReader.FocusItem> {
        val list = ArrayList<MyScreenReader.FocusItem>()
        for (n in 1..6) {
            list.add(MyScreenReader.FocusItem("num_$n", "$n", "number", "") { onPick(n) })
        }
        return list
    }

    private fun oversWord(n: Int): String = if (n == 1) "1 over" else "$n overs"

    private fun wicketsWord(n: Int): String = if (n == 1) "1 wicket" else "$n wickets"

    // ---------------------------------------------------------------- setup menus

    private fun showOvers() {
        busy = false
        match = null
        title = "HAND CRICKET"
        line1 = "Choose overs"
        line2 = "Swipe left or right, double tap to select"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (n in oversChoices) {
            items.add(MyScreenReader.FocusItem("overs_$n", oversWord(n), "button", "") { chooseOvers(n) })
        }
        setItems(items, 0)
        say(
            "Hand Cricket. Choose how many overs. Swipe right or left to hear the options, then double tap to select. " +
                "The back gesture returns to the menu.",
            "Swipe right or left to hear the options, then double tap to select."
        )
    }

    private fun chooseOvers(n: Int) {
        overs = n
        showWickets()
    }

    private fun showWickets() {
        line1 = "Choose wickets"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (n in wicketChoices) {
            items.add(MyScreenReader.FocusItem("wickets_$n", wicketsWord(n), "button", "") { chooseWickets(n) })
        }
        setItems(items, 0)
        say(
            "${oversWord(overs)} selected. Now choose how many wickets. Swipe to hear the options, then double tap.",
            "Swipe to hear the wicket options, then double tap to select."
        )
    }

    private fun chooseWickets(n: Int) {
        maxWickets = n
        showTossCall()
    }

    private fun showTossCall() {
        line1 = "Toss"
        line2 = "Call odd or even"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("toss_odd", "Odd", "button", "") { chooseTossCall("odd") })
        items.add(MyScreenReader.FocusItem("toss_even", "Even", "button", "") { chooseTossCall("even") })
        setItems(items, 0)
        say(
            "${wicketsWord(maxWickets)} selected. Time for the toss. Call odd or even.",
            "Swipe to choose odd or even, then double tap."
        )
    }

    private fun chooseTossCall(call: String) {
        tossCall = call
        line2 = "You called $call"
        setItems(numberItems { n -> resolveToss(n) }, lastNumber - 1)
        say(
            "You called $call. Now pick a number from 1 to 6 for the toss. Swipe to choose, double tap to confirm.",
            "Swipe to choose a number from 1 to 6, then double tap."
        )
    }

    private fun resolveToss(n: Int) {
        if (busy) return
        busy = true
        lastNumber = n
        scope.launch {
            sound.playSpatial("ball_whoosh", pan = 0f, volume = 0.8f)
            delay(500)
            val c = Random.nextInt(1, 7)
            val sum = n + c
            val parity = if (sum % 2 == 1) "odd" else "even"
            val tossText = "You showed $n, computer showed $c. Total $sum, $parity. "
            if (parity == tossCall) {
                showBatBowl(tossText + "You won the toss! Do you want to bat or bowl first?")
            } else {
                val computerBats = Random.nextBoolean()
                val choice = if (computerBats) "bat" else "bowl"
                startMatch(!computerBats, tossText + "Computer won the toss and chose to $choice first. ")
            }
            busy = false
        }
    }

    private fun showBatBowl(text: String) {
        line1 = "You won the toss"
        line2 = "Bat or bowl first?"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("bat_first", "Bat first", "button", "") { startMatch(true, "") })
        items.add(MyScreenReader.FocusItem("bowl_first", "Bowl first", "button", "") { startMatch(false, "") })
        setItems(items, 0)
        say(text, "Swipe to choose bat first or bowl first, then double tap.")
    }

    // ---------------------------------------------------------------- the match

    private fun startMatch(playerBatsFirst: Boolean, prefix: String) {
        match = HandCricketMatch(overs, maxWickets, playerBatsFirst)
        showBallInput(prefix + "Match set: ${oversWord(overs)}, ${wicketsWord(maxWickets)}. ")
    }

    private fun showBallInput(prefix: String) {
        val m = match ?: return
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.addAll(numberItems { n -> playBall(n) })
        items.add(MyScreenReader.FocusItem("score", "Score", "button", "") { speakScore() })
        setItems(items, lastNumber - 1)

        title = if (m.innings == 1) "FIRST INNINGS" else "SECOND INNINGS"
        updateDisplay()

        var text = prefix
        if (m.innings == 1) {
            text += if (m.playerBatting) "You bat first. " else "You bowl first. "
        } else {
            val chaser = if (m.playerBatting) "You need" else "Computer needs"
            text += "$chaser ${m.target} runs to win from ${m.maxBalls} balls. "
        }
        text += if (m.playerBatting) {
            "You are batting. Pick a number from 1 to 6. If it matches the computer's number you are out, otherwise you score your number. "
        } else {
            "You are bowling. Pick a number from 1 to 6. If it matches the computer's batting number, the batter is out, otherwise the computer scores its number. "
        }
        text += "Swipe to choose, double tap to play the ball."
        say(text, "Swipe to choose a number, double tap to play the ball. Choose Score to hear the score. Two finger double tap repeats the last message.")
    }

    private fun playBall(n: Int) {
        if (busy) return
        val m = match ?: return
        if (m.matchOver) return
        busy = true
        lastNumber = n

        scope.launch {
            sound.playSpatial("ball_whoosh", pan = 0f, volume = 0.9f)
            delay(600)

            val c = Random.nextInt(1, 7)
            val wasBatting = m.playerBatting
            val wasInnings = m.innings
            val outcome = m.playBall(n, c)

            // Sounds
            if (outcome.out) {
                sound.playStumpsOut()
            } else if (outcome.scored >= 4) {
                sound.playBatHit("perfect")
                sound.playSpatial("cheer", pan = 0f, volume = 0.8f)
            } else {
                sound.playBatHit("early")
            }

            // Words
            var text = "You $n. Computer $c. "
            if (outcome.out) {
                text += if (wasBatting) "Out! You are dismissed. " else "Out! You got the computer out. "
            } else {
                val runWord = if (outcome.scored == 1) "run" else "runs"
                text += if (wasBatting) "You score ${outcome.scored} $runWord. " else "Computer scores ${outcome.scored} $runWord. "
            }
            text += "Total ${outcome.runsAfter} for ${outcome.wicketsAfter}. "

            if (outcome.matchEnded) {
                text += "Match over. You scored ${m.playerRuns}, computer scored ${m.computerRuns}. ${m.resultText}"
                if (m.playerWon) sound.playSpatial("cheer", pan = 0f, volume = 1.0f)
                showEnd(text)
            } else if (outcome.inningsEnded) {
                val side = if (wasBatting) "You" else "Computer"
                text += "Innings over. $side scored ${outcome.runsAfter} for ${outcome.wicketsAfter}. "
                showBallInput(text)
            } else {
                if (outcome.ballsAfter % 6 == 0) {
                    text += "Over ${outcome.ballsAfter / 6} complete. "
                }
                if (wasInnings == 2) {
                    val chaser = if (m.playerBatting) "You need" else "Computer needs"
                    text += "$chaser ${m.chaseNeed()} from ${m.ballsLeft()} balls. "
                }
                updateDisplay()
                MyScreenReader.speak(text)
            }

            delay(700)
            busy = false
        }
    }

    private fun speakScore() {
        val m = match ?: return
        var text = "Score ${m.runs} for ${m.wickets}, after ${m.balls / 6} overs and ${m.balls % 6} balls, out of ${oversWord(m.overs)}. "
        if (m.innings == 2) {
            val chaser = if (m.playerBatting) "You need" else "Computer needs"
            text += "$chaser ${m.chaseNeed()} runs from ${m.ballsLeft()} balls."
        }
        MyScreenReader.speak(text)
    }

    private fun updateDisplay() {
        val m = match ?: return
        line1 = "${m.runs} / ${m.wickets}"
        val over = "${m.balls / 6}.${m.balls % 6}"
        line2 = if (m.innings == 2) "Overs $over of ${m.overs}  -  Target ${m.target}" else "Overs $over of ${m.overs}"
    }

    private fun showEnd(text: String) {
        val m = match
        title = "MATCH OVER"
        line1 = m?.resultText ?: ""
        line2 = if (m != null) "You ${m.playerRuns}  -  Computer ${m.computerRuns}" else ""
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("play_again", "Play again", "button", "") { showOvers() })
        items.add(MyScreenReader.FocusItem("main_menu", "Main menu", "button", "") { onExit() })
        setItems(items, 0)
        say("$text Swipe to choose Play again or Main menu.", "Swipe to choose Play again or Main menu, then double tap.")
    }
}

@Composable
fun HandCricketScreen(soundManager: SoundManager, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val game = remember { HandCricketController(soundManager, scope, onBack) }

    LaunchedEffect(Unit) {
        game.begin()
    }

    val spoken = MyScreenReader.currentSpokenTextState.value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .myScreenReaderGestures()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(game.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(game.line1, fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                Text(game.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
            }
            Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
            Text(
                "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture returns to the menu.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}
