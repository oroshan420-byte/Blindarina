package com.blindarena

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

// =========================================================================
// MODE 2: HAND CRICKET
// Both sides secretly pick a number from 1 to 6 every ball.
//  - If the numbers match, the batter is OUT.
//  - Otherwise the batter scores their own number as runs.
// Overs and wickets are chosen before the match. Toss = odd or even.
// Before every ball you HEAR the delivery (see CricketAudio.kt): the computer's run-up and the ball flying at you
// when you bat, the batsman getting ready when you bowl. An umpire's whistle and a spoken summary end every innings.
// =========================================================================

/** What happened on one ball. All numbers are taken BEFORE an innings change resets the score. */
class BallOutcome(
    val out: Boolean,
    val scored: Int,
    val batterNumber: Int,
    val runsAfter: Int,
    val wicketsAfter: Int,
    val ballsAfter: Int,
    val inningsEnded: Boolean,
    val matchEnded: Boolean
)

/** Pure match rules, no UI and no sound, so the logic is easy to check. */
class HandCricketMatch(val overs: Int, val maxWickets: Int, val playerBatsFirst: Boolean) {

    val maxBalls: Int
        get() = overs * 6

    var innings: Int = 1
        private set
    var playerBatting: Boolean = playerBatsFirst
        private set
    var runs: Int = 0
        private set
    var wickets: Int = 0
        private set
    var balls: Int = 0
        private set
    var firstInningsRuns: Int = 0
        private set
    var matchOver: Boolean = false
        private set
    var playerRuns: Int = 0
        private set
    var computerRuns: Int = 0
        private set
    var playerWon: Boolean = false
        private set
    var resultText: String = ""
        private set

    /** Runs the chasing side needs to win (only meaningful in the second innings). */
    val target: Int
        get() = firstInningsRuns + 1

    fun chaseNeed(): Int = target - runs

    fun ballsLeft(): Int = maxBalls - balls

    fun playBall(playerNumber: Int, computerNumber: Int): BallOutcome {
        val out = playerNumber == computerNumber
        val batterNumber = if (playerBatting) playerNumber else computerNumber
        val scored = if (out) 0 else batterNumber

        balls += 1
        if (out) wickets += 1 else runs += scored

        val runsAfter = runs
        val wicketsAfter = wickets
        val ballsAfter = balls

        var inningsEnded = wickets >= maxWickets || balls >= maxBalls
        if (innings == 2 && runs >= target) inningsEnded = true

        var matchEnded = false
        if (inningsEnded) {
            if (innings == 1) {
                firstInningsRuns = runs
                innings = 2
                playerBatting = !playerBatting
                runs = 0
                wickets = 0
                balls = 0
            } else {
                matchEnded = true
                matchOver = true
                finishMatch()
            }
        }

        return BallOutcome(out, scored, batterNumber, runsAfter, wicketsAfter, ballsAfter, inningsEnded, matchEnded)
    }

    private fun finishMatch() {
        val chaseRuns = runs
        val defendRuns = firstInningsRuns
        val playerChased = !playerBatsFirst

        playerRuns = if (playerChased) chaseRuns else defendRuns
        computerRuns = if (playerChased) defendRuns else chaseRuns

        if (chaseRuns > defendRuns) {
            val wicketsLeft = maxWickets - wickets
            val margin = "by $wicketsLeft ${if (wicketsLeft == 1) "wicket" else "wickets"}"
            playerWon = playerChased
            resultText = if (playerChased) "You win $margin!" else "Computer wins $margin."
        } else if (chaseRuns < defendRuns) {
            val diff = defendRuns - chaseRuns
            val margin = "by $diff ${if (diff == 1) "run" else "runs"}"
            playerWon = !playerChased
            resultText = if (playerChased) "Computer wins $margin." else "You win $margin!"
        } else {
            playerWon = false
            resultText = "The match is tied!"
        }
    }
}

fun ballsWord(n: Int): String = if (n == 1) "1 ball" else "$n balls"

/** "2 overs", "1 over and 3 balls", "4 balls". */
fun ballsToText(balls: Int): String {
    val overs = balls / 6
    val rest = balls % 6
    val parts = ArrayList<String>()
    if (overs > 0) parts.add(if (overs == 1) "1 over" else "$overs overs")
    if (rest > 0) parts.add(if (rest == 1) "1 ball" else "$rest balls")
    return if (parts.isEmpty()) "0 balls" else parts.joinToString(" and ")
}

/** What is said when the FIRST innings is over (the match is not over yet). */
fun inningsOverText(playerBatted: Boolean, runs: Int, wickets: Int, balls: Int, allOut: Boolean, rival: String = "The computer"): String {
    val reason = if (allOut) "All out." else "All the overs are done."
    val side = if (playerBatted) "You scored" else "$rival scored"
    return "Innings over! $reason $side $runs for $wickets in ${ballsToText(balls)}."
}

/** Short announcements before a ball: the last over, the last ball, the last wicket. Empty when there is nothing special. */
fun ballLeadIn(balls: Int, maxBalls: Int, wickets: Int, maxWickets: Int): String {
    val lead = StringBuilder()
    if (balls > 0 && balls % 6 == 0) {
        lead.append(if (balls == maxBalls - 6) "Last over. " else "Over ${balls / 6 + 1}. ")
    }
    if (maxBalls > 1 && balls == maxBalls - 1) lead.append("Last ball. ")
    if (maxWickets > 1 && wickets == maxWickets - 1) lead.append("Last wicket. ")
    return lead.toString().trim()
}

/** Menus, speech, sounds and timing for the match. Uses the app's own screen reader for all choices. */
class HandCricketController(
    private val sound: SoundManager,
    private val scope: CoroutineScope,
    private val onExit: () -> Unit,
    private val onTutorial: () -> Unit = {}
) {
    var title by mutableStateOf("HAND CRICKET")
    var line1 by mutableStateOf("")
    var line2 by mutableStateOf("")

    private val oversChoices = listOf(1, 2, 3, 5, 10)
    private val wicketChoices = listOf(1, 2, 3, 5, 10)

    private var overs = 2
    private var maxWickets = 2
    private var tossCall = "odd"
    private var match: HandCricketMatch? = null
    private var busy = false
    private var lastNumber = 1
    private var lastChangeMs = 0L

    // The computer's numbers come from here: a plain random player in a normal match, the star of the opposing team in the Premier League
    private var brain = BotBrain(CricketBots.random)
    private var season: Season? = null
    private var seasonOpp = -1
    private var seasonLabel = ""
    private var seasonRulesHeard = false
    private var savedSeason: Season? = null

    private var crowdStream = 0

    // How the other side is called in the words of a ball: "computer" in a normal match, the name of the team in the Premier League
    private fun rivalName(): String {
        if (season == null || seasonOpp < 0) return ""
        return SeasonTeams.all[seasonOpp].name
    }
    private fun rivalBare(): String = rivalName().ifEmpty { "computer" }
    private fun rivalThe(): String = rivalName().ifEmpty { "the computer" }
    private fun rivalCap(): String = rivalName().ifEmpty { "Computer" }
    private fun rivalTheCap(): String = rivalName().ifEmpty { "The computer" }
    private fun resultWords(m: HandCricketMatch): String = if (rivalName().isNotEmpty()) m.resultText.replace("Computer", rivalName()) else m.resultText

    fun begin() {
        ensureCrowd()
        showOvers()
    }

    // Big sound files may still be loading, so this is tried again at every ball until the crowd is playing
    private fun ensureCrowd() {
        if (crowdStream == 0) {
            crowdStream = sound.playLoop("crowd_loop", 0f, 0.1f, 1.0f)
        }
    }

    fun shutdown() {
        sound.stopStream(crowdStream)
        crowdStream = 0
    }

    // ---------------------------------------------------------------- helpers

    private fun say(text: String, help: String) {
        MyScreenReader.currentHelpContext = help
        MyScreenReader.speak(text)
    }

    // A fast double tap used to select an option on the screen that had only just appeared. Ignore taps right after a change.
    private fun tooSoon(): Boolean = Clock.now() - lastChangeMs < 800L

    private fun setItems(items: List<MyScreenReader.FocusItem>, startIndex: Int) {
        MyScreenReader.clearItems()
        for (item in items) {
            MyScreenReader.registerItem(item)
        }
        lastChangeMs = Clock.now()
        if (items.isEmpty()) return
        // -1 means nothing focused yet: the first swipe reads the first option and a stray double tap does nothing
        MyScreenReader.currentFocusIndex.value = if (startIndex < 0) -1 else startIndex.coerceAtMost(items.size - 1)
    }

    private fun numberItems(onPick: (Int) -> Unit): List<MyScreenReader.FocusItem> {
        val list = ArrayList<MyScreenReader.FocusItem>()
        for (n in 1..6) {
            list.add(MyScreenReader.FocusItem("num_$n", "$n", "number", "") { onPick(n) })
        }
        return list
    }

    private fun oversWord(n: Int): String = if (n == 1) "1 over" else "$n overs"

    private fun wicketsWord(n: Int): String = if (n == 1) "1 wicket" else "$n wickets"

    // ---------------------------------------------------------------- setup menus

    private fun showOvers() {
        busy = false
        match = null
        season = null
        seasonOpp = -1
        savedSeason = null
        brain = BotBrain(CricketBots.random)
        title = "HAND CRICKET"
        line1 = "Choose overs"
        line2 = "Swipe left or right, double tap to select"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (n in oversChoices) {
            items.add(MyScreenReader.FocusItem("overs_$n", oversWord(n), "button", "") { chooseOvers(n) })
        }
        items.add(MyScreenReader.FocusItem("premier", "Premier League", "a season with six teams and playoffs", "") { if (!tooSoon()) openPremier() })
        items.add(MyScreenReader.FocusItem("tutorial", "Tutorial", "how to play, the sounds and the gestures", "") { if (!tooSoon()) onTutorial() })
        setItems(items, -1)
        say(
            "Hand Cricket. " + Daily.hint(Daily.CRICKET_WIN, Daily.CRICKET_RUNS) +
                "Choose how many overs. Swipe right or left to hear the options, then double tap to select. " +
                "Or choose Premier League: a season with six teams and playoffs. " +
                "For the tutorial, choose the last option. The back gesture returns to the menu.",
            "Swipe right or left to hear the options, then double tap to select."
        )
    }

    private fun chooseOvers(n: Int) {
        if (tooSoon()) return
        overs = n
        showWickets()
    }

    private fun showWickets() {
        line1 = "Choose wickets"
        val items = ArrayList<MyScreenReader.FocusItem>()
        for (n in wicketChoices) {
            items.add(MyScreenReader.FocusItem("wickets_$n", wicketsWord(n), "button", "") { chooseWickets(n) })
        }
        setItems(items, -1)
        say(
            "${oversWord(overs)} selected. Now choose how many wickets. Swipe to hear the options, then double tap.",
            "Swipe to hear the wicket options, then double tap to select."
        )
    }

    private fun chooseWickets(n: Int) {
        if (tooSoon()) return
        maxWickets = n
        showTossCall()
    }

    private fun showTossCall() {
        line1 = "Toss"
        line2 = "Call odd or even"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("toss_odd", "Odd", "button", "") { chooseTossCall("odd") })
        items.add(MyScreenReader.FocusItem("toss_even", "Even", "button", "") { chooseTossCall("even") })
        setItems(items, -1)
        say(
            "${wicketsWord(maxWickets)} selected. Time for the toss. Call odd or even.",
            "Swipe to choose odd or even, then double tap."
        )
    }

    private fun chooseTossCall(call: String) {
        if (tooSoon()) return
        tossCall = call
        line2 = "You called $call"
        setItems(numberItems { n -> resolveToss(n) }, lastNumber - 1)
        say(
            "You called $call. Now pick a number from 1 to 6 for the toss. Swipe to choose, double tap to confirm. Current number $lastNumber.",
            "Swipe to choose a number from 1 to 6, then double tap."
        )
    }

    private fun resolveToss(n: Int) {
        if (busy || tooSoon()) return
        busy = true
        lastNumber = n
        scope.launch {
            sound.playSpatial("coin_toss", pan = 0f, volume = 0.9f)
            delay(1500)
            val c = Random.nextInt(1, 7)
            val sum = n + c
            val parity = if (sum % 2 == 1) "odd" else "even"
            val tossText = "You showed $n, computer showed $c. Total $sum, $parity. "
            busy = false
            if (parity == tossCall) {
                showBatBowl(tossText + "You won the toss! Do you want to bat or bowl first?")
            } else {
                val computerBats = Random.nextBoolean()
                val choice = if (computerBats) "bat" else "bowl"
                startMatch(!computerBats, tossText + "Computer won the toss and chose to $choice first. ")
            }
        }
    }

    private fun showBatBowl(text: String) {
        line1 = "You won the toss"
        line2 = "Bat or bowl first?"
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("bat_first", "Bat first", "button", "") { if (!tooSoon()) startMatch(true, "") })
        items.add(MyScreenReader.FocusItem("bowl_first", "Bowl first", "button", "") { if (!tooSoon()) startMatch(false, "") })
        setItems(items, -1)
        say(text, "Swipe to choose bat first or bowl first, then double tap.")
    }

    // ---------------------------------------------------------------- the Premier League (the rules are in Season.kt)

    /** The first screen: a new season, or the choice between the saved season and a new one. */
    private fun openPremier() {
        if (busy) return
        val saved = Season.load(Records.store)
        if (saved == null) {
            newSeason()
            return
        }
        savedSeason = saved
        title = "PREMIER LEAGUE"
        line1 = "Season saved"
        line2 = saved.describeProgress()
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("season_continue", "Continue season", "button", "") { if (!tooSoon()) continueSeason() })
        items.add(MyScreenReader.FocusItem("season_new", "New season", "button", "") { if (!tooSoon()) newSeason() })
        items.add(MyScreenReader.FocusItem("season_back", "Back", "button", "") { if (!tooSoon()) showOvers() })
        setItems(items, -1)
        say(
            "Premier League. You have a season in progress: ${saved.describeProgress()}. Swipe to choose Continue season, New season or Back.",
            "Swipe to choose Continue season, New season or Back, then double tap."
        )
    }

    private fun newSeason() {
        if (busy) return
        busy = true
        season = Season()
        savedSeason = null
        seasonRulesHeard = false
        overs = SEASON_OVERS
        maxWickets = SEASON_WICKETS
        MyScreenReader.clearItems()
        title = "PREMIER LEAGUE"
        line1 = "Six teams, one trophy"
        line2 = "Five league matches, then the playoffs"
        val intro = "Premier League! You and five computer teams play each other once, so you play five league matches. " +
            "A win is 2 points and a tie is 1 point. The top four teams go to the playoffs: Qualifier 1, the Eliminator, Qualifier 2 and the Final. " +
            "Each match is ${oversWord(overs)} with ${wicketsWord(maxWickets)}. Every team has a star with his own style, so listen to what they say about them. " +
            "Your season is saved after every match, so you can continue it later. A swipe skips this message."
        scope.launch {
            speakAndWait(intro, skippable = true)
            beginSeasonMatch()
        }
    }

    private fun continueSeason() {
        if (busy) return
        val saved = savedSeason ?: return
        busy = true
        season = saved
        savedSeason = null
        seasonRulesHeard = false
        overs = SEASON_OVERS
        maxWickets = SEASON_WICKETS
        MyScreenReader.clearItems()
        title = "PREMIER LEAGUE"
        line1 = "Continue season"
        line2 = saved.describeProgress()
        scope.launch {
            speakAndWait("Welcome back to the Premier League. ${saved.describeProgress().replaceFirstChar { it.uppercase() }}.", skippable = true)
            beginSeasonMatch()
        }
    }

    /** The next match of the season: names the team, says what its star is like, and starts the first innings. */
    private suspend fun beginSeasonMatch() {
        val s = season ?: return
        val f = s.nextFixture() ?: return
        val team = SeasonTeams.all[f.opponent]
        seasonOpp = f.opponent
        seasonLabel = f.label
        brain = BotBrain(team.bot ?: CricketBots.random)
        s.attempts += 1
        overs = SEASON_OVERS
        maxWickets = SEASON_WICKETS
        match = HandCricketMatch(overs, maxWickets, s.attempts % 2 == 1)
        var prefix = "${f.label}. "
        if (f.blurb.isNotEmpty()) prefix += f.blurb + " "
        prefix += "You play ${team.name}. ${team.intro} "
        if (s.stage == Season.STAGE_LEAGUE && s.round > 0) {
            prefix += "You are ${ordinalWord(s.position(0))} with ${pointsWord(s.points[0])}. "
        }
        beginInnings(prefix)
    }

    private fun seasonGo() {
        if (busy) return
        busy = true
        scope.launch { beginSeasonMatch() }
    }

    /** The match of the season is over: the points, the table, the next match, a rematch, the trophy or the end. */
    private fun seasonMatchEnded(text: String, m: HandCricketMatch, tied: Boolean) {
        val s = season
        if (s == null) {
            showEnd(text)
            return
        }
        val rep = s.report(m.playerWon, tied, m.playerRuns, m.computerRuns)
        var said = "$text ${rep.text}"
        if (rep.over) {
            Season.clearSaved(Records.store)
            val r = Records.seasonFinished(rep.finish)
            said += r.text
            if (rep.finish == FINISH_CHAMPION) {
                CricketAudio.playChampion(sound)
            } else {
                if (rep.finish != FINISH_RUNNER_UP) CricketAudio.playEliminated(sound)
                if (r.newRecord) Records.playNewRecord(sound)
            }
        } else {
            s.save(Records.store)
        }
        val primary = if (rep.over) "New season" else if (rep.replay) "Rematch" else "Next match"
        showSeasonEnd(said, s, rep, primary)
    }

    private fun showSeasonEnd(text: String, s: Season, rep: SeasonReport, primary: String) {
        val m = match
        title = "PREMIER LEAGUE"
        line1 = m?.resultText ?: ""
        line2 = if (rep.over) {
            "Season over"
        } else if (s.stage == Season.STAGE_LEAGUE) {
            "${ordinalWord(s.position(0)).replaceFirstChar { it.uppercase() }} with ${pointsWord(s.points[0])}  -  Match ${s.round + 1} of $SEASON_ROUNDS next"
        } else {
            "Next: ${s.nextFixture()?.label ?: ""}"
        }
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("season_next", primary, "button", "") {
            if (!tooSoon()) {
                if (rep.over) newSeason() else seasonGo()
            }
        })
        items.add(MyScreenReader.FocusItem("season_table", "Points table", "button", "") { MyScreenReader.speak(s.tableText()) })
        items.add(MyScreenReader.FocusItem("main_menu", "Main menu", "button", "") { if (!tooSoon()) onExit() })
        setItems(items, -1)
        say("$text Swipe to choose $primary, Points table or Main menu.", "Swipe to choose $primary, Points table or Main menu, then double tap.")
    }

    // ---------------------------------------------------------------- the match

    private fun startMatch(playerBatsFirst: Boolean, prefix: String) {
        match = HandCricketMatch(overs, maxWickets, playerBatsFirst)
        val intro = prefix + "Match set: ${oversWord(overs)}, ${wicketsWord(maxWickets)}. "
        scope.launch { beginInnings(intro) }
    }

    /** Sets up the number buttons, tells the person whose innings it is, then the first ball is bowled. */
    private suspend fun beginInnings(prefix: String) {
        val m = match ?: return
        busy = true
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.addAll(numberItems { n -> playBall(n) })
        items.add(MyScreenReader.FocusItem("score", "Score", "button", "") { speakScore() })
        setItems(items, lastNumber - 1)

        val inSeason = season != null
        title = (if (inSeason) "${seasonLabel.uppercase()} - " else "") + (if (m.innings == 1) "FIRST INNINGS" else "SECOND INNINGS")
        updateDisplay()

        var text = prefix
        if (m.innings == 1) {
            // after the first match of a season the rules are not explained again
            val short = inSeason && seasonRulesHeard
            if (inSeason) seasonRulesHeard = true
            text += if (short) {
                if (m.playerBatting) "You bat first. Wait for the tone, then pick a number. " else "You bowl first. Wait for the tone, then pick a number to bowl. "
            } else if (m.playerBatting) {
                "You bat first. Listen: the computer runs in and bowls, then you hear a tone. After the tone, pick a number from 1 to 6. " +
                    "The same number as the computer means you are out, otherwise you score your number. "
            } else {
                "You bowl first. The batsman gets ready, then you hear a tone. After the tone, pick a number from 1 to 6 to bowl. " +
                    "The same number as the batsman means he is out, otherwise he scores his number. "
            }
            if (!short) text += "Swipe to choose, double tap to play. A swipe skips any long message."
        } else {
            text += "Innings break. Now the second innings. "
            text += if (m.playerBatting) "You bat and ${rivalThe()} bowls. " else "${rivalTheCap()} bats and you bowl. "
            val chaser = if (m.playerBatting) "You need" else "${rivalCap()} needs"
            text += "$chaser ${m.target} ${if (m.target == 1) "run" else "runs"} to win from ${ballsWord(m.maxBalls)}. "
            text += if (m.playerBatting) "Wait for the bowler, then pick a number." else "Wait for the batsman, then pick your bowling number."
        }
        MyScreenReader.currentHelpContext =
            "Swipe to choose a number, double tap to play the ball. Choose Score to hear the score. Two finger double tap repeats the last message."
        speakAndWait(text, skippable = true)
        prepareBall()
    }

    /** The delivery before a ball: the computer bowls to you, or the batsman gets ready for your bowling. */
    private suspend fun prepareBall() {
        val m = match ?: return
        busy = true
        ensureCrowd()
        val lead = ballLeadIn(m.balls, m.maxBalls, m.wickets, m.maxWickets)
        if (lead.isNotEmpty()) speakAndWait(lead, pauseAfterMs = 150L, skippable = true)
        if (m.playerBatting) {
            CricketAudio.play(sound, CricketAudio.botDeliveryCues())
            busy = false
            MyScreenReader.speak("Bowled. Pick your number.")
        } else {
            CricketAudio.play(sound, CricketAudio.batsmanReadyCues())
            busy = false
            MyScreenReader.speak("Batsman ready. Pick your bowling number.")
        }
    }

    private fun playBall(n: Int) {
        if (busy || tooSoon()) return
        val m = match ?: return
        if (m.matchOver) return
        busy = true
        lastNumber = n

        scope.launch {
            val wasBatting = m.playerBatting
            val wasInnings = m.innings
            if (!wasBatting) {
                // you bowl: your own run-up and the ball flying away from you
                CricketAudio.play(sound, CricketAudio.playerDeliveryCues())
            }
            delay(250)
            ensureCrowd()

            val c = brain.pick(wasBatting)
            val outcome = m.playBall(n, c)
            brain.observe(n, wasBatting)

            CricketAudio.playOutcome(sound, outcome.out, outcome.scored, wasBatting)

            // Records and the daily challenge
            var dailyDone = false
            if (wasBatting && m.overs >= 2 && Daily.report(Daily.CRICKET_RUNS, outcome.runsAfter)) dailyDone = true
            var recordText = ""
            var recordSound = false
            if (wasBatting && outcome.inningsEnded) {
                val r = Records.cricketInnings(m.overs, outcome.runsAfter)
                recordText = r.text
                recordSound = r.newRecord
            }

            // Words
            var text = "You $n, ${rivalBare()} $c. "
            if (outcome.out) {
                text += if (wasBatting) "Out! You are dismissed. " else "Out! You got ${rivalThe()} out. "
            } else {
                val runWord = if (outcome.scored == 1) "run" else "runs"
                text += if (wasBatting) "You score ${outcome.scored} $runWord. " else "${rivalCap()} scores ${outcome.scored} $runWord. "
            }
            text += "Total ${outcome.runsAfter} for ${outcome.wicketsAfter}. "
            if (dailyDone) text += Daily.completionText() + " "

            if (outcome.matchEnded) {
                // the result of the last ball, then the whistle, then the crowd and the final result
                speakBall(text.trim(), dailyDone)
                val tied = m.playerRuns == m.computerRuns
                CricketAudio.playMatchOver(sound, m.playerWon, tied)
                val stats = Records.matchFinished("cricket", "matches", m.playerWon, tied)
                val winDone = m.playerWon && Daily.report(Daily.CRICKET_WIN, 1)
                delay(1500)
                var endText = "Match over. You scored ${m.playerRuns}, ${rivalBare()} scored ${m.computerRuns}. ${resultWords(m)}" + stats.text + recordText
                if (winDone) endText += " " + Daily.completionText()
                if (recordSound || stats.newRecord) Records.playNewRecord(sound)
                if (winDone) Daily.playSound(sound)
                busy = false
                if (season != null) seasonMatchEnded(endText, m, tied) else showEnd(endText)
            } else if (outcome.inningsEnded) {
                // the result of the last ball, then the whistle, then the summary of the innings, then the second innings
                speakBall(text.trim(), dailyDone)
                CricketAudio.playInningsOver(sound)
                delay(1100)
                val allOut = outcome.wicketsAfter >= m.maxWickets
                speakAndWait(inningsOverText(wasBatting, outcome.runsAfter, outcome.wicketsAfter, outcome.ballsAfter, allOut, rivalTheCap()) + recordText, skippable = true)
                if (recordSound) {
                    Records.playNewRecord(sound)
                    delay(1200)
                }
                delay(400)
                beginInnings("")
            } else {
                if (outcome.ballsAfter % 6 == 0) {
                    text += "Over ${outcome.ballsAfter / 6} complete. "
                }
                if (wasInnings == 2) {
                    val chaser = if (m.playerBatting) "You need" else "${rivalCap()} needs"
                    text += "$chaser ${m.chaseNeed()} from ${ballsWord(m.ballsLeft())}. "
                }
                updateDisplay()
                speakBall(text.trim(), dailyDone)
                prepareBall()
            }
            busy = false
        }
    }

    /** Says the text of a ball; when that ball also completed the daily challenge, a short celebration sound follows. */
    private suspend fun speakBall(text: String, dailyDone: Boolean) {
        speakAndWait(text, skippable = true)
        if (dailyDone) {
            Daily.playSound(sound)
            delay(900)
        }
    }

    private fun speakScore() {
        val m = match ?: return
        var text = "Score ${m.runs} for ${m.wickets}, after ${m.balls / 6} overs and ${m.balls % 6} balls, out of ${oversWord(m.overs)}. "
        if (m.innings == 2) {
            val chaser = if (m.playerBatting) "You need" else "${rivalCap()} needs"
            text += "$chaser ${m.chaseNeed()} runs from ${ballsWord(m.ballsLeft())}."
        }
        MyScreenReader.speak(text)
    }

    private fun updateDisplay() {
        val m = match ?: return
        line1 = "${m.runs} / ${m.wickets}"
        val over = "${m.balls / 6}.${m.balls % 6}"
        line2 = if (m.innings == 2) "Overs $over of ${m.overs}  -  Target ${m.target}" else "Overs $over of ${m.overs}"
    }

    private fun showEnd(text: String) {
        val m = match
        title = "MATCH OVER"
        line1 = m?.resultText ?: ""
        line2 = if (m != null) "You ${m.playerRuns}  -  Computer ${m.computerRuns}" else ""
        val items = ArrayList<MyScreenReader.FocusItem>()
        items.add(MyScreenReader.FocusItem("play_again", "Play again", "button", "") { if (!tooSoon()) showOvers() })
        items.add(MyScreenReader.FocusItem("main_menu", "Main menu", "button", "") { if (!tooSoon()) onExit() })
        setItems(items, -1)
        say("$text Swipe to choose Play again or Main menu.", "Swipe to choose Play again or Main menu, then double tap.")
    }
}

@Composable
fun HandCricketScreen(soundManager: SoundManager, onBack: () -> Unit, onTutorial: () -> Unit = {}) {
    val scope = rememberCoroutineScope()
    val game = remember { HandCricketController(soundManager, scope, onBack, onTutorial) }

    LaunchedEffect(Unit) {
        game.begin()
    }

    DisposableEffect(Unit) {
        onDispose { game.shutdown() }
    }

    val spoken = MyScreenReader.currentSpokenTextState.value

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0F172A))
            .myScreenReaderGestures()
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text(game.title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(game.line1, fontSize = 38.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                Text(game.line2, fontSize = 18.sp, color = Color(0xFF94A3B8))
            }
            Text("Screen Reader: \"$spoken\"", fontSize = 14.sp, color = Color(0xFFFBBF24))
            Text(
                "Swipe left or right to choose, double tap to confirm. Two finger double tap repeats. Hold 1s for help. Back gesture returns to the menu.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}
