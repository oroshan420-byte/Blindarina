# Blind Arena

## Get the APK (free, no Android Studio needed)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or hit **Run workflow**).
3. When it's green, open the run and download the **BlindArena-debug-apk** artifact. Unzip it to get `app-debug.apk`, then install it on your phone.

## Or build locally
Open this folder in Android Studio and use Build > Build APK(s). From a terminal with Gradle 8.9+: `gradle assembleDebug`.

## Long drive to Kalimpong (Mode 1, replaces the old "Town" route)
A 70 kilometre drive from a busy city, over a highway, through a river valley with two bridges and up a twisting hill road,
to the **Mary Scott Home School for the Blind hostel in Kalimpong**. There are no buildings to crash into any more.

* **The road** is 20 metres wide, four lanes: you drive on the left half, oncoming traffic uses the right half. The road is
  drawn fresh every game (about 45 straight pieces, always exactly 70 km). Beside the road the car is slowed by the grass and
  the world's edge is soft: you slide along it and never lose a life for it.
* **GPS** speaks the whole way: "In 1000 metres, turn left", "In 400 metres...", "In 150 metres... slow down", "Turn left now",
  "Continue for 2.4 kilometres", kilometres left every 5 km, the zone you are entering, bridges, and warnings when you leave
  the road, go the wrong way or drift onto the oncoming side. Quick tap on the screen: the GPS tells you the next turn and the distance left.
* **One finger controls**
  * slide up: speed up (further up = faster); slide down: slow down; a long slide down: reverse
  * slide left or right: steer. A gentle lane assist straightens small drifts when you are not steering
  * lift the finger: the car keeps its speed (cruise), so a long drive is comfortable
  * quick tap: ask the GPS
* **Traffic** (all by sound): cows, dogs, crowds, speed bumps, autos, buses, trucks, bikes and cycles, some going your way,
  some coming at you. Vehicles slow down and honk if you are in their way. Parking-sensor beeps get faster as something gets close.
  A beeping pedestrian signal means a red light: stop. A light never turns red right under your wheels.
* **Lives**: 3. A slow touch (under about 18 km/h) is only a bump: the car stops, no life is lost. A life is given back at every 10 km checkpoint.
* The old Town route and its buildings were removed.

## Fixes in this version
* Android 11 and newer: the text-to-speech engine could not be found without a `<queries>` entry in the manifest. Added.
* Speech asked for while the voice engine was still starting up was lost. It is now kept and spoken as soon as the voice is ready.
* The 1 second hold for help now speaks while your finger is still resting, not only after you lift it.
* Gun Duel: the intro was cut off after 24 seconds; the wait is now 34 seconds.

## Sounds
All effects are in `app/src/main/res/raw/` (96 small .wav files, 22050 Hz mono). They were not changed, and no new sounds were added.
You can swap in your own using the same file names.

## Note
The game logic of the new drive was run through a long headless simulation (many random roads, a no-traffic driver, a careful
driver with traffic, a careless driver, coarse frame rates). The Android screens (Compose) could only be checked by reading the
code, so the first GitHub Actions build is the real compile check.
