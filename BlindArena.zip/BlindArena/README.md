# Blind Arena

## Get the APK (free, no Android Studio needed)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or hit **Run workflow**).
3. When it's green, open the run and download the **BlindArena-debug-apk** artifact. Unzip it to get `app-debug.apk`, then install it on your phone.

## Or build locally
Open this folder in Android Studio and use Build > Build APK(s). From a terminal with Gradle 8.9+: `gradle assembleDebug`.

## Long drive to Kalimpong (Mode 1, replaces the old "Town" route)
A 70 kilometre drive from a busy city, over a highway, through a river valley with two bridges and up a twisting hill road,
to the **Mary Scott Home School for the Blind hostel in Kalimpong**. There are no buildings to crash into any more.

* **The road** is 20 metres wide, four lanes: you drive on the left half, oncoming traffic uses the right half. The road is
  drawn fresh every game (about 45 straight pieces, always exactly 70 km). Beside the road the car is slowed by the grass and
  the world's edge is soft: you slide along it and never lose a life for it. A gravel rumble on one side warns you only at the very edge of the road, so driving in your lane stays quiet.
* **GPS** speaks the whole way: "In 1000 metres, turn left", "In 400 metres...", "In 150 metres... slow down", "Turn left now",
  "Continue for 2.4 kilometres", kilometres left every 5 km, the zone you are entering, bridges, and warnings when you leave
  the road, go the wrong way or drift onto the oncoming side. Quick tap on the screen: the GPS tells you the next turn and the distance left.
* **One finger controls** (the car goes while your finger is on the screen)
  * slide up: the further up you slide, the faster the car goes; slide down: reverse
  * lift the finger: the car slows down and stops
  * quick tap: ask the GPS
  * slide left or right: steer. **You only need to steer at the sharp turns** (the GPS says "turn left now") and to go around
    something. A small sideways drift of your thumb is ignored, so sliding straight up never turns the car by accident.
* **Easy driving, made for blind players**
  * The car **keeps to its own lane** and follows gentle bends by itself. While you do not steer it holds a straight line.
  * Before a sharp turn it **slows down by itself** (the GPS also says "slow down"), and speeds up again after the turn.
    At the turn slide sideways towards the way the GPS said; once you have turned about halfway the car finishes the turn.
  * If the car ever ends up beside the road it **heads back to the road by itself** (it is only slowed by the grass).
  * The moment you slide sideways, you are in full control again, so you can still swerve around a cow or a bus.
* **Traffic** (all by sound): cows, dogs, crowds, speed bumps, autos, buses, trucks, bikes and cycles, some going your way,
  some coming at you. Vehicles slow down and honk if you are in their way. Parking-sensor beeps get faster as something gets close.
  A beeping pedestrian signal means a red light: stop. A light never turns red right under your wheels.
* **Lives**: 3. A slow touch (under about 18 km/h) is only a bump: the car stops, no life is lost. A life is given back at every 10 km checkpoint.
* The old Town route and its buildings were removed.

## Arcade Rush (Mode 1, new route: "Arcade rush")
A fast dodging game made for listening, in the spirit of blindfold driving games.

* **The car drives by itself** and gets faster every 25 seconds (12 levels). You only choose the lane.
* **Controls**: touch the **left half** of the screen to move one lane left, the **right half** to move one lane right.
  Holding repeats the move. A touch during the spoken explanation skips it.
* Cars, trucks, autos and fast bikes come at you in three lanes. Their sound grows louder and sits left, middle or right
  of you: **move away from the side you hear them on.** Soft beeps and a horn mean a vehicle is coming in **your** lane.
* A **ringing bell** is a bonus: steer into it for points and a life back (never more than 3).
* **3 lives.** Later levels add roadside noises (dog, cow, cheering) from level 4 and rain from level 7 to confuse your ears.
* Every wave of traffic is planned so that there is always a free lane you can reach in time, so you are never hit unfairly.
* The game over text tells your score, and your best score since the app was opened.
* Uses only the existing sounds.

## Fixes in this version
* Android 11 and newer: the text-to-speech engine could not be found without a `<queries>` entry in the manifest. Added.
* Speech asked for while the voice engine was still starting up was lost. It is now kept and spoken as soon as the voice is ready.
* The 1 second hold for help now speaks while your finger is still resting, not only after you lift it.
* The drive was too hard to steer (the thumb drifted sideways and turned the car, and you had to correct all the time). Added the dead zone, the lane keeping, the slowing before sharp turns and the way back to the road.
* Engine and tyre sounds: the gravel rumble and the tyre squeal were playing far too often (they sounded like braking). They now only play at the very edge of the road and in real hard cornering.
* Traffic lights no longer turn red right under the car; buses and trucks no longer stop for you when you are correctly in your own lane.
* Gun Duel: the intro was cut off after 24 seconds; the wait is now 34 seconds.

## Sounds
All effects are in `app/src/main/res/raw/` (96 small .wav files, 22050 Hz mono). They were not changed, and no new sounds were added.
You can swap in your own using the same file names.

## Note
The game logic of the new drive and of Arcade Rush was run through long headless simulations (many random roads, a no-traffic driver, a careful
driver with traffic, a careless driver, coarse frame rates). The Android screens (Compose) could only be checked by reading the
code, so the first GitHub Actions build is the real compile check.
