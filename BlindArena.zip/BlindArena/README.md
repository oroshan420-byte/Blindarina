# Blind Arena

## Get the APK (free, no Android Studio needed)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or hit **Run workflow**).
3. When it's green, open the run and download the **BlindArena-debug-apk** artifact. Unzip it to get `app-debug.apk`, then install it on your phone.

## Or build locally
Open this folder in Android Studio and use Build > Build APK(s). From a terminal with Gradle 8.9+: `gradle assembleDebug`.

## Long drive to Kalimpong (Mode 1, replaces the old "Town" route)
A 70 kilometre drive from a busy city, over a highway, through a river valley with two bridges and up a twisting hill road,
to the **Mary Scott Home School for the Blind hostel in Kalimpong**. There are no buildings to crash into any more.

* **The road** is 20 metres wide, four lanes: you drive on the left half, oncoming traffic uses the right half. The road is
  drawn fresh every game (about 45 straight pieces, always exactly 70 km). Beside the road the car is slowed by the grass and
  the world's edge is soft: you slide along it and never lose a life for it. A gravel rumble on one side warns you only at the very edge of the road, so driving in your lane stays quiet.
* **GPS** speaks the whole way: "In 1000 metres, turn left", "In 400 metres...", "In 150 metres... slow down", "Turn left now",
  "Continue for 2.4 kilometres", kilometres left every 5 km, the zone you are entering, bridges, and warnings when you leave
  the road, go the wrong way or drift onto the oncoming side. Quick tap on the screen: the GPS tells you the next turn and the distance left.
* **One finger controls** (the car goes while your finger is on the screen)
  * slide up: the further up you slide, the faster the car goes; slide down: reverse
  * lift the finger: the car slows down and stops
  * quick tap: ask the GPS
  * slide left or right: steer. **You only need to steer at the sharp turns** (the GPS says "turn left now") and to go around
    something. A small sideways drift of your thumb is ignored, so sliding straight up never turns the car by accident.
* **Easy driving, made for blind players**
  * The car **keeps to its own lane** and follows gentle bends by itself. While you do not steer it holds a straight line.
  * Before a sharp turn it **slows down by itself** (the GPS also says "slow down"), and speeds up again after the turn.
    At the turn slide sideways towards the way the GPS said; once you have turned about halfway the car finishes the turn.
  * If the car ever ends up beside the road it **heads back to the road by itself** (it is only slowed by the grass).
  * The moment you slide sideways, you are in full control again, so you can still swerve around a cow or a bus.
* **Traffic** (all by sound): cows, dogs, crowds, speed bumps, autos, buses, trucks, bikes and cycles, some going your way,
  some coming at you. Vehicles slow down and honk if you are in their way. Parking-sensor beeps get faster as something gets close.
  A beeping pedestrian signal means a red light: stop. A light never turns red right under your wheels.
* **Lives**: 3. A slow touch (under about 18 km/h) is only a bump: the car stops, no life is lost. A life is given back at every 10 km checkpoint.
* The old Town route and its buildings were removed.

## Arcade Rush (Mode 1, new route: "Arcade rush")
A fast dodging game made for listening, in the spirit of blindfold driving games.

* **The car drives by itself** and gets faster every 25 seconds (12 levels). You only choose the lane.
* **Controls**: touch the **left half** of the screen to move one lane left, the **right half** to move one lane right.
  Holding repeats the move. A touch during the spoken explanation skips it.
* Cars, trucks, autos and fast bikes come at you in three lanes. Their sound grows louder and sits left, middle or right
  of you: **move away from the side you hear them on.** Soft beeps and a horn mean a vehicle is coming in **your** lane.
* A **ringing bell** is a bonus: steer into it for points and a life back (never more than 3).
* **3 lives.** Later levels add roadside noises (dog, cow, cheering) from level 4 and rain from level 7 to confuse your ears.
* Every wave of traffic is planned so that there is always a free lane you can reach in time, so you are never hit unfairly.
* The game over text tells your score, and your best score since the app was opened.
* Uses only the existing sounds.

## Hand Cricket: you can now hear the bowling (Mode 2)
Before this version the computer's bowling was a very short whoosh, so against the bot you could not tell if it had bowled, and
you could not tell when an innings was over. Now every ball is played in full, with the sounds that were already in the app:

* **When you bat, the computer bowls first.** You hear the bowler run in (five footsteps, quicker and louder), then the ball flying
  at you (six whooshes, louder and higher), then a short tone, then the voice says "Bowled. Pick your number." Only then do you choose your number.
* **When you bowl**, you hear the batsman get ready (two taps of the bat on the ground and a low tone) and the voice says
  "Batsman ready. Pick your bowling number." After you pick, you hear your own run-up and the ball flying away, then the hit or the stumps.
* **When an innings is over** you hear the umpire's whistle, then the voice says for example "Innings over! All out. You scored 14 for 2 in
  2 overs", then "Innings break. Now the second innings. The computer bats and you bowl. Computer needs 15 runs to win from 12 balls."
  The match ends with the whistle, the crowd (applause and roar, or a groan) and the result.
* The voice also says "Over 2", "Last over", "Last ball" and "Last wicket", so you know the end is near, and "needs 7 from 4 balls" in the chase.
* A swipe at any time skips the rest of a long message and goes on to the next ball.
* New first menu option **Tutorial** (see below).

## Tutorials (new Mode 4, and a "Tutorial" option in the first menu of every game)
Every game has a **gesture lesson** and a **sound lesson**. Open them from the main menu, Mode 4: Tutorials, or choose "Tutorial"
(the last option) in the first menu of Road Drive, Hand Cricket or Gun Fight.

* **Gesture lessons** ask for one gesture at a time and listen for it. They use the very same touch code and sounds as the real games.
  If you do not do it, the request is repeated twice and then the lesson goes on, so nobody gets stuck. The back gesture leaves a lesson.
  * Menu gestures: swipe right and left, double tap, two finger double tap, hold for one second (help), the back gesture.
  * Long drive to Kalimpong: one finger up and down (the engine follows your finger), lift to stop, a long slide down for reverse
    (you hear the reverse beeper), slide left and right (indicator tick), a quick tap for the GPS.
  * Arcade Rush: touch the left and right half, hear the lane beeps, dodge a pretend car, catch a pretend bonus bell.
  * Highway and jungle road: top edge tap for a higher gear, bottom edge tap for a lower gear, two quick taps to brake, hold left or right half for lanes.
  * Hand Cricket: two practice balls with the real sounds, one batting and one bowling, and the whistle at the end of an innings.
  * Gun Fight: swipe to walk and turn (with the turning clicks), tap to fire, tap the bottom edge to reload, tap the top edge for status.
* **Sound lessons** are lists of sounds: swipe to a sound and double tap to hear it and to hear what it means. The first option, "Play all sounds",
  plays them one after another (a swipe stops it). Hold one finger for one second to hear the explanation again.
  Kalimpong drive 27 sounds, Arcade Rush 15, Highway and jungle 18, Hand Cricket 15, Gun Fight 21 (the last two of every list are the new record and daily challenge sounds).

## Records and daily challenge (new Mode 5, and inside every game)
Your results are now saved in the phone, so they are still there tomorrow.

* **Best results.** Every game says your best when it starts ("Your best score is 1450") and says **"New record!"** with the crowd applauding when you beat it.
  Saved: Arcade Rush best score, Highway and Jungle road furthest distance (and how often you reached the village), Long drive to Kalimpong furthest distance,
  how often you arrived and your fastest time, Hand Cricket matches won, winning streak, best innings for each number of overs and your Premier League seasons, titles and best finish, Gun Fight duels won (also by difficulty) and winning streak.
  If you leave a drive with the back gesture, the distance or score so far is kept too.
* **Daily challenge.** One small goal per day, the same all day, a new one at midnight (the phone's own time). For example "In Arcade Rush, reach level 4",
  "Win a Hand Cricket match", "On the Highway, drive 1000 meters", "Win a Gun Fight duel on Medium or Hard". Nine challenges come round one after another.
  The game you play mentions today's challenge when it starts (until it is done). When you reach it you hear a cheer and a bell and the voice says
  "Daily challenge complete!", and how many days in a row you did it. The main menu mentions it once when the app opens.
* **Mode 5: Records and daily challenge** on the main menu: swipe to hear today's challenge and your best result in every game, double tap repeats one.
* Only sounds that were already in the app are used: the applause is the crowd applause, the daily challenge is the cheer and the temple bell.
  Both have a card at the end of every sound list in the tutorials.

## Hand Cricket Premier League (IPL style season, new in the first menu of Hand Cricket)
In the first menu of Hand Cricket choose **Premier League** (just before "Tutorial"). It is a whole season against the computer:

* **Six teams:** your team and five computer teams. Every match is 2 overs with 2 wickets. The computer teams are named after cities and each has a **star with his own style**:
  Kalimpong (Roshan, a beginner who picks at random), Kolkata (Pranit, a copycat who often repeats the number you showed last),
  Bengaluru (Virat Kohli, steady, likes 1 to 4), Hyderabad (Travis Head and Abhishek Sharma, attacking hitters who love 4, 5 and 6),
  Mumbai (Jasprit Bumrah, a clever bowler who remembers your favourite numbers). Before every match the voice tells you who you play and what he is like.
  The computer never looks at the number you pick for the ball that is being played; it only remembers earlier balls, so a player who picks at random cannot be read by anyone.
* **League stage:** you play every team once (5 matches). A win is 2 points, a tie 1 point each. The other matches of the round are played by the computer at once, with the same rules and the same habits.
  After every match the voice tells your points and position. The table is sorted by points, then by runs scored minus runs given away.
  The item **Points table** (on the screen after every match) reads the whole table.
* **Playoffs for the top four:** Qualifier 1 (1st against 2nd, the winner goes straight to the Final, the loser gets a second chance), the Eliminator (3rd against 4th, the loser is out),
  Qualifier 2 (the loser of Qualifier 1 against the winner of the Eliminator, the loser is out) and the Final. A tied playoff match is played again. If you are not in the top four the computer plays the playoffs and tells you who won.
* **Saved:** the season is saved after every match. When you choose Premier League again you can **Continue season** or start a **New season**.
* **Records:** seasons played, titles won and your best finish (league stage, playoffs, runner-up, champion) are in Records. A better finish than ever gives "New record!", the trophy gives the victory fanfare and the cheering crowd.
* Only existing sounds are used (victory, crowd cheer, game over, applause, the normal cricket sounds).
* **Names:** the team names are only city names and the stars carry the names of well-known cricketers, as asked. They are fine for your own use and for school.
  If you publish the game (for example on the Play Store), change them: they are all in one list at the top of `Season.kt` (`SeasonTeams`), and the habits of each star are in the same list.

## Fixes in this version
* Android 11 and newer: the text-to-speech engine could not be found without a `<queries>` entry in the manifest. Added.
* Speech asked for while the voice engine was still starting up was lost. It is now kept and spoken as soon as the voice is ready.
* The 1 second hold for help now speaks while your finger is still resting, not only after you lift it.
* The drive was too hard to steer (the thumb drifted sideways and turned the car, and you had to correct all the time). Added the dead zone, the lane keeping, the slowing before sharp turns and the way back to the road.
* Engine and tyre sounds: the gravel rumble and the tyre squeal were playing far too often (they sounded like braking). They now only play at the very edge of the road and in real hard cornering.
* Traffic lights no longer turn red right under the car; buses and trucks no longer stop for you when you are correctly in your own lane.
* Gun Duel: the intro was cut off after 24 seconds; the wait is now 34 seconds.
* Hand Cricket: the bowling was almost silent and the end of an innings was not announced (see above).

## Sounds
All effects are in `app/src/main/res/raw/` (96 small .wav files, 22050 Hz mono). They were not changed, and no new sounds were added.
You can swap in your own using the same file names.

## Note
The game logic of the drives, Arcade Rush, Hand Cricket and the tutorials was run through long headless simulations on a virtual clock
(a fake voice that takes time to speak, a bot that plays whole matches and follows every tutorial lesson, a user who does nothing,
random taps and swipes, leaving a lesson half way, every sound demo played and cancelled, every sound name checked against the 96 files).
The records were checked with a bot that plays Arcade Rush, many Hand Cricket matches, a simulated change of day, a missed day and the India midnight.
The Premier League was checked with 400 simulated seasons (points, table, playoffs, ties, every way a season can end), the saving and loading (also of damaged saves), the habits of every star, and 21 whole seasons played through the screens, including leaving and continuing.
What could not be tried here: saving to the phone's real settings file (it is the normal Android SharedPreferences) and the new records screen on a real phone.
The Android screens (Compose) could only be checked by reading the code, so the first GitHub Actions build is the real compile check.
