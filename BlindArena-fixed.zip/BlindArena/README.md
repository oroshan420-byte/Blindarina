# Blind Arena

## Get the APK (free, no Android Studio needed)
1. Create a GitHub repo and upload everything in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or hit **Run workflow**).
3. When it's green, open the run and download the **BlindArena-debug-apk** artifact. Unzip it to get `app-debug.apk`, then install it on your phone.

## Or build locally
Open this folder in Android Studio and use Build > Build APK(s). From a terminal with Gradle 8.9+: `gradle assembleDebug`.

## Sounds
All effects are in `app/src/main/res/raw/` (8 small .wav files). They're generated placeholders, so you can swap in your own using the same file names:
engine_loop (seamless loop), beep, ball_whoosh, bat_crack, stumps_clatter, footstep, lock_tone, gunshot.
