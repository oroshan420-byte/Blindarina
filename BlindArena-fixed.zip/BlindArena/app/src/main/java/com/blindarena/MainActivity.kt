package com.blindarena

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs

// =========================================================================
// 1. AUTONOMOUS SCREEN READER SYSTEM (MyScreenReader)
// =========================================================================
object MyScreenReader : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var isInitialized = false

    var speechRate: Float = 1.0f
        private set

    var lastSpokenText: String = "Welcome to Blind Arena"
        private set

    var currentHelpContext: String = "Use swipe right to explore, double tap to activate"

    /** When speak() was last called (ms). Lets background hints avoid cutting off important messages. */
    var lastSpeakTime: Long = 0L
        private set

    // Newest message requested before the speech engine finished starting; spoken as soon as it is ready
    private var pendingText: String? = null

    data class FocusItem(
        val id: String,
        val label: String,
        val role: String = "button",
        val hint: String = "",
        val onAction: () -> Unit
    )

    private val focusRegistry = mutableListOf<FocusItem>()
    val currentFocusIndex = mutableStateOf(-1)
    val currentSpokenTextState = mutableStateOf("")

    fun init(context: Context) {
        if (tts == null) {
            tts = TextToSpeech(context.applicationContext, this)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts?.let { engine ->
                engine.setLanguage(Locale.US)
                engine.setSpeechRate(speechRate)
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {}
                    override fun onError(utteranceId: String?) {}
                })
                isInitialized = true
                // The first screen asked to speak before the engine was ready: say that, not a generic line
                val pending = pendingText
                pendingText = null
                speak(pending ?: "Blind Arena screen reader initialized. Swipe right to explore.")
            }
        }
    }

    fun speak(text: String, flush: Boolean = true) {
        if (text.isBlank()) return
        lastSpokenText = text
        currentSpokenTextState.value = text
        lastSpeakTime = System.currentTimeMillis()

        if (!isInitialized || tts == null) {
            pendingText = text
            return
        }

        val queueMode = if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val utteranceId = System.currentTimeMillis().toString()
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }
        tts?.speak(text, queueMode, params, utteranceId)
    }

    fun setRate(rate: Float) {
        val clamped = rate.coerceIn(0.5f, 2.0f)
        speechRate = clamped
        tts?.setSpeechRate(clamped)
        speak("Speech speed set to ${String.format(Locale.US, "%.1f", clamped)}x")
    }

    fun onScreenChanged(screenTitle: String, instructions: String) {
        currentHelpContext = instructions
        speak("$screenTitle. $instructions", flush = true)
    }

    fun registerItem(item: FocusItem) {
        val existing = focusRegistry.indexOfFirst { it.id == item.id }
        if (existing >= 0) {
            focusRegistry[existing] = item
        } else {
            focusRegistry.add(item)
        }
        if (currentFocusIndex.value == -1 && focusRegistry.isNotEmpty()) {
            currentFocusIndex.value = 0
        }
    }

    fun clearItems() {
        focusRegistry.clear()
        currentFocusIndex.value = -1
    }

    fun focusNext() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = (currentFocusIndex.value + 1) % focusRegistry.size
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun focusPrevious() {
        if (focusRegistry.isEmpty()) return
        currentFocusIndex.value = if (currentFocusIndex.value < 0) {
            focusRegistry.size - 1
        } else {
            (currentFocusIndex.value - 1 + focusRegistry.size) % focusRegistry.size
        }
        val item = focusRegistry[currentFocusIndex.value]
        speak("${item.label}, ${item.role}")
    }

    fun onTouchItem(id: String) {
        val index = focusRegistry.indexOfFirst { it.id == id }
        if (index >= 0) {
            currentFocusIndex.value = index
            val item = focusRegistry[index]
            speak("${item.label}, ${item.role}. Double tap to activate.")
        }
    }

    fun activateFocusedItem() {
        val index = currentFocusIndex.value
        if (index in focusRegistry.indices) {
            val item = focusRegistry[index]
            speak("Activating ${item.label}")
            item.onAction()
        }
    }

    fun repeatLastSpeech() {
        speak("Repeating: $lastSpokenText")
    }

    fun speakHelp() {
        val focused = if (currentFocusIndex.value in focusRegistry.indices) {
            focusRegistry[currentFocusIndex.value]
        } else null

        val focusedHint = if (focused != null && focused.hint.isNotBlank()) {
            " Current selection is ${focused.label}. ${focused.hint}"
        } else ""

        speak("Help. $currentHelpContext$focusedHint", flush = true)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isInitialized = false
        pendingText = null
    }
}

// =========================================================================
// 2. GESTURE DETECTOR (Captures touches before TalkBack)
// =========================================================================
private const val LONG_PRESS_MS = 1000L

fun Modifier.myScreenReaderGestures(
    onDirectDoubleTap: (() -> Unit)? = null
): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        coroutineScope {
            var lastTapTime = 0L
            var lastTapPointerCount = 1

            awaitEachGesture {
                val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                val downTime = System.currentTimeMillis()
                val startPos = down.position
                var lastPos = startPos
                var pointersCount = 1
                var movedTooFar = false

                while (true) {
                    // Wait for the next touch event, but only until the 1 second help hold is reached.
                    // A finger held perfectly still sends no events at all, so this needs a timeout.
                    val remaining = LONG_PRESS_MS - (System.currentTimeMillis() - downTime)
                    val event = when {
                        movedTooFar -> awaitPointerEvent(pass = PointerEventPass.Initial)
                        remaining > 0L -> withTimeoutOrNull(remaining) { awaitPointerEvent(pass = PointerEventPass.Initial) }
                        else -> null
                    }

                    // 1 Second Long Press (finger still, not moved) -> Help
                    if (event == null) {
                        MyScreenReader.speakHelp()
                        break
                    }

                    pointersCount = maxOf(pointersCount, event.changes.size)
                    val change = event.changes.firstOrNull()
                    if (change != null) {
                        lastPos = change.position
                        if ((lastPos - startPos).getDistance() > 40f) movedTooFar = true
                    }

                    if (event.changes.all { !it.pressed }) {
                        val upTime = System.currentTimeMillis()
                        val duration = upTime - downTime
                        val dx = lastPos.x - startPos.x
                        val dy = lastPos.y - startPos.y

                        // Swipes
                        if (abs(dx) > 120f && abs(dx) > abs(dy) * 1.5f && duration < 500) {
                            if (dx > 0) MyScreenReader.focusNext()
                            else MyScreenReader.focusPrevious()
                        } else if (abs(dx) < 60f && abs(dy) < 60f && duration < 350) {
                            // Double Tap
                            val timeSinceLast = upTime - lastTapTime
                            if (timeSinceLast < 350L) {
                                if (pointersCount >= 2 || lastTapPointerCount >= 2) {
                                    MyScreenReader.repeatLastSpeech()
                                } else {
                                    if (onDirectDoubleTap != null) onDirectDoubleTap()
                                    else MyScreenReader.activateFocusedItem()
                                }
                                lastTapTime = 0L
                            } else {
                                lastTapTime = upTime
                                lastTapPointerCount = pointersCount
                            }
                        }
                        break
                    }
                }
            }
        }
    }

// =========================================================================
// 3. 3D SPATIAL AUDIO & SOUNDPOOL ENGINE (SoundManager)
// =========================================================================
class SoundManager(private val context: Context) {
    private val soundPool: SoundPool
    private val soundMap = mutableMapOf<String, Int>()
    private var engineStreamId: Int = 0

    init {
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(16)
            .setAudioAttributes(audioAttributes)
            .build()

        loadAll()
    }

    fun loadSound(tag: String, resId: Int) {
        val id = soundPool.load(context, resId, 1)
        soundMap[tag] = id
    }

    // Loads every sound effect from res/raw. Swap the .wav files there to change the sounds.
    private fun loadAll() {
        loadSound("engine_loop", R.raw.engine_loop)
        loadSound("beep", R.raw.beep)
        loadSound("ball_whoosh", R.raw.ball_whoosh)
        loadSound("bat_crack", R.raw.bat_crack)
        loadSound("stumps_clatter", R.raw.stumps_clatter)
        loadSound("footstep", R.raw.footstep)
        loadSound("lock_tone", R.raw.lock_tone)
        loadSound("gunshot", R.raw.gunshot)
        loadSound("car_hum", R.raw.car_hum)
        loadSound("car_pass", R.raw.car_pass)
        loadSound("horn", R.raw.horn)
        loadSound("crash", R.raw.crash)
        loadSound("cheer", R.raw.cheer)
        loadSound("tire_screech", R.raw.tire_screech)
        loadSound("road_ambience", R.raw.road_ambience)
        loadSound("siren", R.raw.siren)
    }

    fun playSpatial(tag: String, pan: Float = 0f, volume: Float = 1.0f, rate: Float = 1.0f): Int {
        val soundId = soundMap[tag] ?: return 0
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = volume * ((1.0f - clampedPan) / 2.0f + if (clampedPan <= 0f) 0.5f else 0f).coerceIn(0f, 1f)
        val rightVol = volume * ((1.0f + clampedPan) / 2.0f + if (clampedPan >= 0f) 0.5f else 0f).coerceIn(0f, 1f)
        return soundPool.play(soundId, leftVol, rightVol, 1, 0, rate)
    }

    // Looping stream whose pan, volume and pitch can be changed while it plays (used for approaching cars)
    fun playLoop(tag: String, pan: Float, volume: Float, rate: Float): Int {
        val soundId = soundMap[tag] ?: return 0
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = (volume * (if (clampedPan > 0f) 1.0f - clampedPan else 1.0f)).coerceIn(0f, 1f)
        val rightVol = (volume * (if (clampedPan < 0f) 1.0f + clampedPan else 1.0f)).coerceIn(0f, 1f)
        // Priority 2: when the pool is full, short one-shot sounds (priority 1) are dropped before a loop is
        return soundPool.play(soundId, leftVol, rightVol, 2, -1, rate.coerceIn(0.5f, 2.0f))
    }

    fun updateStream(streamId: Int, pan: Float, volume: Float, rate: Float) {
        if (streamId == 0) return
        val clampedPan = pan.coerceIn(-1.0f, 1.0f)
        val leftVol = (volume * (if (clampedPan > 0f) 1.0f - clampedPan else 1.0f)).coerceIn(0f, 1f)
        val rightVol = (volume * (if (clampedPan < 0f) 1.0f + clampedPan else 1.0f)).coerceIn(0f, 1f)
        soundPool.setVolume(streamId, leftVol, rightVol)
        soundPool.setRate(streamId, rate.coerceIn(0.5f, 2.0f))
    }

    fun stopStream(streamId: Int) {
        if (streamId != 0) soundPool.stop(streamId)
    }

    fun setEngineRate(rate: Float) {
        if (engineStreamId != 0) soundPool.setRate(engineStreamId, rate.coerceIn(0.5f, 2.0f))
    }

    fun pauseAll() {
        soundPool.autoPause()
    }

    fun resumeAll() {
        soundPool.autoResume()
    }

    fun startEngineLoop(tag: String) {
        val soundId = soundMap[tag] ?: return
        if (engineStreamId == 0) {
            engineStreamId = soundPool.play(soundId, 0.4f, 0.4f, 2, -1, 1.0f)
        }
    }

    fun stopEngine() {
        if (engineStreamId != 0) {
            soundPool.stop(engineStreamId)
            engineStreamId = 0
        }
    }

    fun playOffTrackBeep(direction: String) {
        val pan = if (direction == "left") -0.95f else 0.95f
        playSpatial("beep", pan = pan, volume = 0.8f, rate = 1.2f)
        vibrate(60)
    }

    fun playBallApproach(progress: Float) {
        val rate = 0.8f + (progress * 0.7f)
        val vol = 0.2f + (progress * 0.8f)
        playSpatial("ball_whoosh", pan = 0f, volume = vol, rate = rate)
    }

    fun playBatHit(quality: String) {
        val rate = if (quality == "perfect") 1.2f else 1.0f
        playSpatial("bat_crack", pan = 0f, volume = 1.0f, rate = rate)
        vibrate(100)
    }

    fun playStumpsOut() {
        playSpatial("stumps_clatter", pan = 0f, volume = 1.0f)
        vibrate(250)
    }

    fun playFootsteps(pan: Float, distance: Float) {
        val volume = (1.0f - (distance / 12f)).coerceIn(0.1f, 1.0f)
        playSpatial("footstep", pan = pan, volume = volume)
    }

    fun playTargetLockTone() {
        playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.5f)
        vibrate(40)
    }

    fun playGunshot(hit: Boolean) {
        playSpatial("gunshot", pan = 0f, volume = 1.0f)
        if (hit) vibrate(150)
    }

    fun vibrate(durationMs: Long) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator?.vibrate(
                    VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.vibrate(durationMs)
            }
        } catch (_: Exception) {}
    }

    fun release() {
        stopEngine()
        soundPool.release()
    }
}

// =========================================================================
// 4. MAIN ACTIVITY
// =========================================================================
class MainActivity : ComponentActivity(), SensorEventListener {
    lateinit var soundManager: SoundManager
    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private var rotationSensor: Sensor? = null

    val tiltX = mutableStateOf(0f)
    val phoneAzimuth = mutableStateOf(0f)
    val currentScreen = mutableStateOf("MENU")
    val isPaused = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.decorView.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
        // Games are played without touching the screen, so never let it sleep
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        MyScreenReader.init(this)
        soundManager = SoundManager(this)

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        rotationSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)

        setContent {
            val screen = currentScreen.value

            // System back (or back gesture) returns to the menu from any game
            BackHandler(enabled = screen != "MENU") { currentScreen.value = "MENU" }

            // Gestures are attached per screen (not here) so a game's double tap
            // never also triggers a stale menu item.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF0F172A))
            ) {
                when (screen) {
                    "MENU" -> MainMenuScreen(onNavigate = { currentScreen.value = it })
                    "RACING" -> CarDriveScreen(soundManager, isPaused.value)
                    "CRICKET" -> HandCricketScreen(soundManager, onBack = { currentScreen.value = "MENU" })
                    "GUNFIGHT" -> GunFightScreen(soundManager, phoneAzimuth.value, isPaused.value, onBack = { currentScreen.value = "MENU" })
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        isPaused.value = false
        if (::soundManager.isInitialized) soundManager.resumeAll()
        accelerometer?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        rotationSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        super.onPause()
        isPaused.value = true
        if (::soundManager.isInitialized) soundManager.pauseAll()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        MyScreenReader.shutdown()
        soundManager.release()
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> tiltX.value = event.values[0]
            Sensor.TYPE_ROTATION_VECTOR -> {
                val rotationMatrix = FloatArray(9)
                SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
                val orientation = FloatArray(3)
                SensorManager.getOrientation(rotationMatrix, orientation)
                phoneAzimuth.value = Math.toDegrees(orientation[0].toDouble()).toFloat()
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

// =========================================================================
// 5. MAIN MENU SCREEN
// =========================================================================
@Composable
fun MainMenuScreen(onNavigate: (String) -> Unit) {
    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_racing", "Mode 1: Highway Drive", "button", "Touch and hold left or right side of the screen to steer.") { onNavigate("RACING") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_cricket", "Mode 2: Hand Cricket", "button", "Pick numbers against the computer. Choose overs and wickets.") { onNavigate("CRICKET") })
        MyScreenReader.registerItem(MyScreenReader.FocusItem("mode_gunfight", "Mode 3: 3D Gun Fight", "button", "Rotate phone to aim.") { onNavigate("GUNFIGHT") })
        // Nothing focused yet: the first swipe right reads Mode 1, and a stray double tap does nothing
        MyScreenReader.currentFocusIndex.value = -1
        MyScreenReader.onScreenChanged("Blind Arena Main Menu", "Three audio games available. Swipe right to explore modes. Double tap to select.")
    }

    val focusedIndex = MyScreenReader.currentFocusIndex.value
    val spokenText = MyScreenReader.currentSpokenTextState.value

    Column(
        modifier = Modifier.fillMaxSize().myScreenReaderGestures().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("BLIND ARENA", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text("Audio-First Gaming Engine with Autonomous Screen Reader", fontSize = 13.sp, color = Color(0xFF94A3B8))
        }

        Box(
            modifier = Modifier.fillMaxWidth().background(Color(0xFF1E293B), RoundedCornerShape(12.dp)).padding(16.dp)
        ) {
            Text("Screen Reader: \"$spokenText\"", color = Color(0xFF38BDF8), fontSize = 15.sp)
        }

        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val modes = listOf(
                "mode_racing" to "Mode 1: Highway Drive",
                "mode_cricket" to "Mode 2: Hand Cricket",
                "mode_gunfight" to "Mode 3: 3D Gun Fight"
            )
            modes.forEachIndexed { index, (id, label) ->
                val isSelected = focusedIndex == index
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(if (isSelected) Color(0xFF2563EB) else Color(0xFF1E293B), RoundedCornerShape(10.dp))
                        .border(if (isSelected) 3.dp else 1.dp, if (isSelected) Color.White else Color(0xFF334155), RoundedCornerShape(10.dp))
                        .clickable { MyScreenReader.onTouchItem(id) }
                        .padding(18.dp)
                ) {
                    Text(label, color = Color.White, fontSize = 18.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium)
                }
            }
        }
        Text("Gestures: Swipe Left/Right · Double Tap Select · Hold 1s Help", color = Color(0xFF64748B), fontSize = 12.sp)
    }
}

// =========================================================================
// 6. MODE 1: HIGHWAY DRIVE (see CarDrive.kt)
// =========================================================================
// =========================================================================
// 7. MODE 2: HAND CRICKET (see HandCricket.kt)
// =========================================================================
// =========================================================================
// 8. MODE 3: 3D GUN FIGHT SCREEN
// =========================================================================
@Composable
fun GunFightScreen(soundManager: SoundManager, playerAzimuth: Float, paused: Boolean, onBack: () -> Unit) {
    var score by remember { mutableStateOf(0) }
    var enemyAngle by remember { mutableStateOf(90f) }
    var isTargetLocked by remember { mutableStateOf(false) }
    var lastWhisperTime by remember { mutableStateOf(0L) }

    // Always hold the latest compass heading / pause state, without restarting the loop on every change
    val azimuth by rememberUpdatedState(playerAzimuth)
    val isPaused by rememberUpdatedState(paused)

    // Where the enemy is compared to where the phone points: -180..180, negative = left, positive = right
    fun angleToEnemy(): Float {
        var rel = (enemyAngle - azimuth) % 360f
        if (rel > 180f) rel -= 360f
        if (rel < -180f) rel += 360f
        return rel
    }

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        MyScreenReader.onScreenChanged("Gun Fight Arena", "Enemies walk around you in 360 degrees. Rotate phone to aim. Double tap anywhere to shoot.")
    }

    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            // App in the background: stay silent
            if (isPaused) continue

            val now = System.currentTimeMillis()
            val rel = angleToEnemy()

            val pan = (rel / 90f).coerceIn(-1.0f, 1.0f)
            soundManager.playFootsteps(pan = pan, distance = 4f)

            // Direction hint, but never talk over a recent message such as "Enemy eliminated" or "Missed"
            val spokeRecently = now - MyScreenReader.lastSpeakTime < 1500L
            if (now - lastWhisperTime > 2500L && !spokeRecently) {
                val hint = when {
                    abs(rel) > 135f -> "Enemy behind"
                    rel < -45f -> "Enemy left"
                    rel > 45f -> "Enemy right"
                    else -> null
                }
                if (hint != null) {
                    MyScreenReader.speak(hint)
                    lastWhisperTime = now
                }
            }

            if (abs(rel) <= 12f) {
                if (!isTargetLocked) {
                    isTargetLocked = true
                    soundManager.playTargetLockTone()
                    MyScreenReader.speak("Target locked")
                }
            } else {
                isTargetLocked = false
            }
        }
    }

    fun shoot() {
        if (isPaused) return
        // Judge the aim at the moment of the shot, not by the last 200 ms check
        val hit = abs(angleToEnemy()) <= 12f
        soundManager.playGunshot(hit = hit)
        if (hit) {
            score++
            MyScreenReader.speak("Enemy eliminated! Score: $score")
            // Next enemy appears at least 30 degrees away, so it is never already under the crosshair
            val side = if ((0..1).random() == 0) -1 else 1
            val offset = (30..120).random() * side
            enemyAngle = ((azimuth + offset) % 360f + 360f) % 360f
            isTargetLocked = false
        } else {
            MyScreenReader.speak("Missed!")
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(Color(0xFF030712)).myScreenReaderGestures(onDirectDoubleTap = { shoot() }).padding(24.dp)) {
        Column(modifier = Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.SpaceBetween) {
            Text("3D GUN FIGHT", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = if (isTargetLocked) "🎯 TARGET LOCKED!" else "🎧 TRACKING FOOTSTEPS...",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isTargetLocked) Color(0xFFEF4444) else Color(0xFF38BDF8)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text("Enemies Eliminated: $score", fontSize = 18.sp, color = Color.White)
            }
            Text("Rotate phone to track 3D footsteps. Double tap to fire when locked. Back gesture returns to menu.", fontSize = 13.sp, color = Color(0xFF64748B))
        }
    }
}
