package com.blindarena

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

// =========================================================================
// MODE 1: HIGHWAY DRIVE
// You drive against traffic on a 3-lane road. Cars come towards you; their
// sound moves from far/quiet to near/loud and sits left, centre or right
// depending on their lane. A horn means a car is in YOUR lane.
// Touch and hold the left half of the screen to move left, the right half to
// move right. Tap = one lane. Hold = keeps moving.
// =========================================================================

/** Finger state, written by the touch handler and read by the game loop. */
class CarControls {
    var leftHeld = false
    var rightHeld = false
    var leftPressQueued = false
    var rightPressQueued = false
    private var tapQueued = false

    fun queueTap() {
        tapQueued = true
    }

    fun consumeTap(): Boolean {
        val queued = tapQueued
        tapQueued = false
        return queued
    }
}

/** All game rules live here, with no UI code, so bugs are easy to find. */
class CarGame(private val sound: SoundManager) {

    companion object {
        const val LANES = 3
        const val SPAWN_DISTANCE = 120f
        const val HIT_DISTANCE = 3f
        const val HORN_DISTANCE = 45f
        const val HOLD_REPEAT_SECONDS = 0.45f
        const val FIRST_INTRO_SECONDS = 9f
        const val RETRY_INTRO_SECONDS = 2.5f
        const val GAME_OVER_LOCK_SECONDS = 2.5f
        const val START_LIVES = 3
        const val LEVEL_LENGTH_M = 600f
        const val MAX_CARS = 4
        const val MAX_LEVEL = 10
        const val AMBIENCE_VOLUME = 0.18f
    }

    private class Car(val lane: Int, var distance: Float) {
        var streamId: Int = 0
        var horned: Boolean = false
    }

    var lane: Int = 1
        private set
    var lives: Int = START_LIVES
        private set
    var level: Int = 1
        private set
    var distance: Float = 0f
        private set
    var isGameOver: Boolean = false
        private set

    private val cars = mutableListOf<Car>()
    private var spawnTimer = 0f
    private var holdTimer = 0f
    private var introLeft = 0f
    private var gameOverLock = 0f
    private var ambienceStream = 0

    // ---------------------------------------------------------------- start / stop

    fun start() {
        reset()
        introLeft = FIRST_INTRO_SECONDS
        sound.startEngineLoop("engine_loop")
        sound.setEngineRate(1.0f)
        MyScreenReader.onScreenChanged(
            "Highway Drive",
            "Touch and hold the left side of the screen to move left, and the right side to move right. " +
                "A horn means a car is in your lane. Use the back gesture to return to the menu."
        )
    }

    fun tryRestart() {
        if (!isGameOver || gameOverLock > 0f) return
        reset()
        introLeft = RETRY_INTRO_SECONDS
        sound.startEngineLoop("engine_loop")
        sound.setEngineRate(1.0f)
        MyScreenReader.speak("Get ready.")
    }

    fun shutdown() {
        clearCars()
        stopAmbience()
        sound.stopEngine()
    }

    private fun ensureAmbience() {
        if (ambienceStream == 0) {
            ambienceStream = sound.playLoop("road_ambience", 0f, AMBIENCE_VOLUME, 1.0f)
        }
    }

    private fun stopAmbience() {
        sound.stopStream(ambienceStream)
        ambienceStream = 0
    }

    private fun reset() {
        clearCars()
        lane = 1
        lives = START_LIVES
        level = 1
        distance = 0f
        isGameOver = false
        spawnTimer = 0.5f
        holdTimer = 0f
        gameOverLock = 0f
    }

    private fun clearCars() {
        for (car in cars) {
            sound.stopStream(car.streamId)
        }
        cars.clear()
    }

    // ---------------------------------------------------------------- game loop

    fun tick(dt: Float, controls: CarControls) {
        if (isGameOver) {
            if (gameOverLock > 0f) gameOverLock -= dt
            return
        }

        // Big sound files may still be loading when the game starts, so keep trying until the loops play
        sound.startEngineLoop("engine_loop")
        ensureAmbience()

        handleSteering(dt, controls)

        if (introLeft > 0f) {
            introLeft -= dt
            if (introLeft <= 0f) MyScreenReader.speak("Go!")
            return
        }

        val speed = closingSpeed()
        distance += speed * dt
        updateLevel()

        spawnTimer -= dt
        if (spawnTimer <= 0f) {
            trySpawn(speed)
            spawnTimer = (2.4f - 0.14f * level).coerceAtLeast(1.0f) * (0.8f + Random.nextFloat() * 0.4f)
        }

        updateCars(dt, speed)
    }

    private fun closingSpeed(): Float {
        return (24f + 3f * level).coerceAtMost(51f)
    }

    private fun updateLevel() {
        val newLevel = (1 + (distance / LEVEL_LENGTH_M).toInt()).coerceAtMost(MAX_LEVEL)
        if (newLevel > level) {
            level = newLevel
            sound.playSpatial("lock_tone", pan = 0f, volume = 0.9f, rate = 1.2f)
            sound.setEngineRate((0.95f + 0.05f * level).coerceAtMost(1.4f))
            if (level >= MAX_LEVEL) {
                MyScreenReader.speak("Level $level. Maximum speed.", flush = false)
            } else {
                MyScreenReader.speak("Level $level. Traffic is getting faster.", flush = false)
            }
        }
    }

    // ---------------------------------------------------------------- steering

    private fun handleSteering(dt: Float, controls: CarControls) {
        if (holdTimer > 0f) holdTimer -= dt

        val freshLeft = controls.leftPressQueued
        val freshRight = controls.rightPressQueued
        controls.leftPressQueued = false
        controls.rightPressQueued = false

        var dir = 0
        if (freshLeft != freshRight) {
            // A new tap always moves one lane straight away
            dir = if (freshLeft) -1 else 1
        } else if (holdTimer <= 0f && controls.leftHeld != controls.rightHeld) {
            // Holding repeats the move
            dir = if (controls.leftHeld) -1 else 1
        }
        if (dir == 0) return

        holdTimer = HOLD_REPEAT_SECONDS
        moveLane(dir)
    }

    private fun moveLane(dir: Int) {
        val target = lane + dir
        if (target < 0 || target >= LANES) {
            // Road edge: low bump on that side
            sound.playSpatial("tire_screech", pan = dir * 0.9f, volume = 0.6f)
            sound.vibrate(30)
            return
        }
        lane = target
        val rate = when (lane) {
            0 -> 0.8f
            1 -> 1.0f
            else -> 1.25f
        }
        // Lane tone: low and left, middle and centre, high and right
        sound.playSpatial("beep", pan = (lane - 1) * 0.8f, volume = 0.7f, rate = rate)
    }

    // ---------------------------------------------------------------- traffic

    private fun trySpawn(speed: Float) {
        if (cars.size >= MAX_CARS) return

        // Never let two recently-spawned cars block two lanes AND a third arrive: always leave one lane free
        val recentLimit = SPAWN_DISTANCE - speed * 1.2f
        val blockedLanes = HashSet<Int>()
        for (car in cars) {
            if (car.distance > recentLimit) blockedLanes.add(car.lane)
        }
        if (blockedLanes.size >= LANES - 1) return

        cars.add(Car(Random.nextInt(LANES), SPAWN_DISTANCE))
    }

    private fun updateCars(dt: Float, speed: Float) {
        var crashed = false
        val iterator = cars.iterator()
        while (iterator.hasNext()) {
            val car = iterator.next()
            car.distance -= speed * dt

            if (car.distance <= HIT_DISTANCE) {
                sound.stopStream(car.streamId)
                iterator.remove()
                if (car.lane == lane) {
                    crashed = true
                } else {
                    val pan = ((car.lane - lane) * 0.9f).coerceIn(-1f, 1f)
                    sound.playSpatial("car_pass", pan = pan, volume = 1.0f)
                }
            } else {
                if (!car.horned && car.lane == lane && car.distance < HORN_DISTANCE) {
                    car.horned = true
                    sound.playSpatial("horn", pan = 0f, volume = 1.0f)
                }
                updateCarAudio(car)
            }
        }
        if (crashed) onCrash()
    }

    private fun updateCarAudio(car: Car) {
        val closeness = (1f - car.distance / SPAWN_DISTANCE).coerceIn(0f, 1f)
        val volume = 0.08f + 0.92f * closeness * closeness
        val rate = 0.85f + 0.55f * closeness
        val pan = ((car.lane - lane) * 0.85f).coerceIn(-1f, 1f)
        if (car.streamId == 0) {
            car.streamId = sound.playLoop("car_hum", pan, volume, rate)
        } else {
            sound.updateStream(car.streamId, pan, volume, rate)
        }
    }

    // ---------------------------------------------------------------- crash / game over

    private fun onCrash() {
        sound.playSpatial("crash", pan = 0f, volume = 1.0f)
        sound.vibrate(300)
        lives -= 1
        clearCars()
        spawnTimer = 3f
        if (lives <= 0) {
            endGame()
        } else {
            val word = if (lives == 1) "life" else "lives"
            MyScreenReader.speak("Crash! $lives $word left.")
        }
    }

    private fun endGame() {
        isGameOver = true
        gameOverLock = GAME_OVER_LOCK_SECONDS
        sound.stopEngine()
        stopAmbience()
        // Police arrive after the last crash (the recording starts faint and grows by itself)
        sound.playSpatial("siren", pan = 0f, volume = 0.35f)
        MyScreenReader.speak(
            "Game over. You drove ${distance.toInt()} meters and reached level $level. " +
                "Tap the screen to play again, or use the back gesture to return to the menu."
        )
    }
}

/** Finger-down tracking for the left and right halves of the screen. */
private fun Modifier.carTouchControls(controls: CarControls): Modifier = this
    .clearAndSetSemantics { }
    .pointerInput(Unit) {
        awaitPointerEventScope {
            var prevLeft = false
            var prevRight = false
            var prevAny = false
            while (true) {
                val event = awaitPointerEvent(PointerEventPass.Initial)
                val middle = size.width / 2f
                var left = false
                var right = false
                for (change in event.changes) {
                    if (change.pressed) {
                        if (change.position.x < middle) left = true else right = true
                    }
                }
                val any = left || right
                if (left && !prevLeft) controls.leftPressQueued = true
                if (right && !prevRight) controls.rightPressQueued = true
                if (any && !prevAny) controls.queueTap()
                controls.leftHeld = left
                controls.rightHeld = right
                prevLeft = left
                prevRight = right
                prevAny = any
            }
        }
    }

@Composable
fun CarDriveScreen(soundManager: SoundManager, paused: Boolean) {
    val game = remember { CarGame(soundManager) }
    val controls = remember { CarControls() }
    var uiTick by remember { mutableStateOf(0) }
    val isPaused by rememberUpdatedState(paused)

    LaunchedEffect(Unit) {
        MyScreenReader.clearItems()
        game.start()
    }

    DisposableEffect(Unit) {
        onDispose { game.shutdown() }
    }

    LaunchedEffect(Unit) {
        var last = System.nanoTime()
        var counter = 0
        while (true) {
            delay(30)
            val now = System.nanoTime()
            val dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.1f)
            last = now
            if (isPaused) continue

            if (game.isGameOver) {
                if (controls.consumeTap()) game.tryRestart()
            } else {
                controls.consumeTap()
            }
            game.tick(dt, controls)

            counter++
            if (counter % 5 == 0) uiTick++
        }
    }

    val refresh = uiTick
    val laneName = when (game.lane) {
        0 -> "LEFT LANE"
        1 -> "CENTER LANE"
        else -> "RIGHT LANE"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020617))
            .carTouchControls(controls)
            .padding(24.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Text("HIGHWAY DRIVE", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                if (game.isGameOver) {
                    Text("GAME OVER - tap to play again", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFFEF4444))
                } else {
                    Text(laneName, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color(0xFF38BDF8))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Text("Level ${game.level}  -  Lives ${game.lives}", fontSize = 18.sp, color = Color.White)
                Text("Distance: ${game.distance.toInt()} m", fontSize = 18.sp, color = Color(0xFF94A3B8))
            }
            Text(
                "Touch and hold left or right half to steer. Horn = car in your lane. Back gesture returns to the menu.",
                fontSize = 13.sp,
                color = Color(0xFF64748B)
            )
        }
    }
}
